﻿Public Class Utilities
    Public Shared Function GetDB2LibraryListAsString(ByVal LibraryList As String) As String
        Dim s() As String = LibraryList.Split(",")
        Dim _S As String = ""
        For Each x As String In s
            x = "'" + x.Trim() + "'"
            _S = _S + x + ","
        Next
        If _S.EndsWith(",") = True Then
            _S = _S.Substring(0, _S.Length - 1)
        End If
        Return _S

    End Function
    Public Shared Function DBTypeGetDefaultValue(ByVal DBType As String) As String

        Dim s As String = ""
        Dim a As String = Chr(34)
        Select Case DBType

            Case Is = "DbType.AnsiString", "DbType.AnsiStringFixedLength", "DbType.String", "DbType.StringFixedLength"
                s = a & a
            Case Is = "DbType.Byte"
                s = "0"
            Case Is = "DbType.Boolean"
                s = "false"
            Case Is = "DbType.Currency", "DbType.Decimal", "DbType.VarNumeric"
                s = "0"
            Case Is = "DbType.Single"
                s = "0"
            Case Is = "DbType.Date", "DbType.DateTime"
                s = "null"
            Case Is = "DbType.Time"
                s = "00:00:00"
            Case Is = "DbType.Double"
                s = "0"
            Case Is = "DbType.Guid"
                s = ""
            Case Is = "DbType.SByte"
                s = "0"
            Case Is = "DbType.Int16"
                s = "0"
            Case Is = "DbType.Int32"
                s = "0"
            Case Is = "DbType.Int64"
                s = "0"
            Case Is = "DbType.UInt16"
                s = "0"
            Case Is = "DbType.UInt32"
                s = "0"
            Case Is = "DbType.UInt64"
                s = "0"
            Case Else
                s = """"
        End Select

        Return (s)
    End Function

    Public Shared Function GetDbParamenterInfo(ByVal DbProvider As DbProviders, ByVal DataRow As DataRow, ByRef ParamenterName As String, ByRef ParameterDbType As DbType, ByRef ParamaterDirection As ParameterDirection) As Boolean
        ParamaterDirection = Utilities.GetDbParameterDirection(DbProvider, DataRow)

    End Function
    Public Shared Function GetDbParameterDirection(ByVal DBProvider As DbProviders, SchemaDataRow As DataRow) As ParameterDirection

        Select Case DBProvider
            Case DbProviders.SQLSERVER
                If SchemaDataRow("IS_RESULT").ToString().ToUpper = "YES" Then
                    Return ParameterDirection.ReturnValue
                End If
                Select Case SchemaDataRow("PARAMETER_MODE").ToString().ToUpper
                    Case "IN"
                        Return ParameterDirection.Input
                    Case "OUT"
                        Return ParameterDirection.Output
                    Case "INOUT"
                        Return ParameterDirection.InputOutput
                End Select
            Case DbProviders.ORACLE
                If SchemaDataRow("IS_RESULT").ToString().ToUpper = "YES" Then
                    Return ParameterDirection.ReturnValue
                End If
                Select Case SchemaDataRow("PARAMETER_MODE").ToString().ToUpper
                    Case "IN"
                        Return ParameterDirection.Input
                    Case "OUT"
                        Return ParameterDirection.Output
                    Case "INOUT"
                        Return ParameterDirection.InputOutput
                End Select
            Case DBProviders.OLEDB
            Case DBProviders.OLEDBDB2
            Case DBProviders.ODBC
            Case DBProviders.ODBCDB2
            Case DbProviders.MYSQL
                If SchemaDataRow("PARAMETER_NAME") = "RETURN_VALUE" Then
                    Return ParameterDirection.ReturnValue
                End If
                Select Case SchemaDataRow("PARAMETER_MODE").ToString().ToUpper
                    Case "IN"
                        Return ParameterDirection.Input
                    Case "OUT"
                        Return ParameterDirection.Output
                    Case "INOUT"
                        Return ParameterDirection.InputOutput
                End Select
            Case DbProviders.DB2ISERIES
                If SchemaDataRow("PARAMETER_NAME") Is DBNull.Value And SchemaDataRow("PARAMETER_MODE") = "OUT" Then
                    Return ParameterDirection.ReturnValue
                End If
                Select Case SchemaDataRow("PARAMETER_MODE").ToString().ToUpper
                    Case "IN"
                        Return ParameterDirection.Input
                    Case "OUT"
                        Return ParameterDirection.Output
                    Case "INOUT"
                        Return ParameterDirection.InputOutput
                End Select
            Case Else

        End Select

        Return Nothing

    End Function
    Public Shared Function GetParameterName(ByVal DbProvider As DbProviders, ByVal SchemaDataRow As DataRow) As String
        Select Case DbProvider
            Case DbProviders.SQLSERVER
                Return SchemaDataRow("PARAMETER_NAME")

            Case DbProviders.ORACLE
                Return SchemaDataRow("PARAMETER_NAME")
            Case DbProviders.OLEDB
            Case DbProviders.OLEDBDB2
            Case DbProviders.ODBC
            Case DbProviders.ODBCDB2
            Case DbProviders.MYSQL
                Return SchemaDataRow("PARAMETER_NAME")
            Case DbProviders.DB2ISERIES
                If SchemaDataRow("PARAMETER_NAME") Is DBNull.Value Then
                    Return ""
                Else
                    Return SchemaDataRow("PARAMETER_NAME")
                End If

            Case Else

        End Select

        Return Nothing
    End Function

    Public Shared Function GetDbTypeFromDatabaseType(ByVal DBProvider As DbProviders, ByVal SchemaDataRow As DataRow)

        Dim s As String = ""
        If SchemaDataRow("PARAMETER_NAME") Is DBNull.Value Then
            s = ""
        Else
            s = SchemaDataRow("PARAMETER_NAME")
        End If
        Return GetDbTypeFromDatabaseType(DBProvider, s)
    End Function

    Public Shared Function GetDbTypeFromDatabaseType(ByVal DBProvider As DbProviders, ByVal Type As String)

        Dim t As DbType = DbType.String

        Select Case DBProvider
            Case DbProviders.SQLSERVER
                Select Case Type.ToLower().Trim
                    Case "bigint" : t = DbType.Int64
                    Case "binary" : t = DbType.Binary
                    Case "bit" : t = DbType.Boolean
                    Case "char" : t = DbType.String
                    Case "date" : t = DbType.Date
                    Case "datetime" : t = DbType.DateTime
                    Case "datetime2" : t = DbType.DateTime2
                    Case "dattimeoffset" : t = DbType.DateTimeOffset
                    Case "decimal" : t = DbType.Decimal
                    Case "float" : t = DbType.Double
                    Case "image" : t = DbType.Object
                    Case "int" : t = DbType.Int32
                    Case "money" : t = DbType.Int32
                    Case "nchar" : t = DbType.String
                    Case "nvarchar" : t = DbType.String
                    Case "real" : t = DbType.Double
                    Case "smalldatetime" : t = DbType.DateTime
                    Case "smallint" : t = DbType.Int16
                    Case "smallmoney" : t = DbType.Decimal
                    Case "time" : t = DbType.Time
                    Case "tinyint" : t = DbType.Int16
                    Case "uniqueidentifier" : t = DbType.Guid
                    Case "varbinary" : t = DbType.Object
                    Case "varchar" : t = DbType.String
                    Case "xml" : t = DbType.Xml
                End Select

            Case DbProviders.ORACLE
            Case DbProviders.OLEDB
            Case DbProviders.OLEDBDB2
            Case DbProviders.ODBC
            Case DbProviders.ODBCDB2
            Case DbProviders.MYSQL
            Case DbProviders.DB2ISERIES
            Case Else

        End Select

        Return Nothing


        Return t


    End Function

    Public Shared Function DBTypeToSystemType(ByVal DbType As String) As String
        Dim x As Object
        Select Case DbType


            Case Is = "AnsiString", "AnsiStringFixedLength", "String", "StringFixedLength"
                x = New System.String("")
            Case Is = "Byte"

                x = New System.Byte()

            Case Is = "Boolean"

                x = New System.Boolean

            Case Is = "Currency", "Decimal", "VarNumeric"
                x = New System.Decimal

            Case Is = "Single"
                x = New System.Single


            Case Is = "Date", "DateTime"
                x = New System.DateTime

            Case Is = "Time"
                x = New System.TimeSpan

            Case Is = "Double"
                x = New System.Double

            Case Is = "Guid"

                x = New System.Guid


            Case Is = "SByte"
                x = New System.SByte


            Case Is = "Int16"
                x = New System.Int16


            Case Is = "Int32"
                x = New System.Int32


            Case Is = "Int64"
                x = New System.Int64


            Case Is = "UInt16"

                x = New System.UInt16


            Case Is = "UInt32"
                x = New System.UInt32


            Case Is = "UInt64"
                x = New System.UInt64

            Case Else
                x = New System.String("")
        End Select

        Return x.GetType().ToString()

    End Function
    Public Shared Function GetDbProviderBrackets(ByVal DbProvider As DbProviders, ByRef LeftBracket As String, ByRef RightBracket As String) As Boolean

        LeftBracket = ""
        RightBracket = ""
        Dim s As Boolean = False
        Select Case DbProvider
            Case DbProviders.MYSQL
                s = True
                LeftBracket = "`"
                RightBracket = "`"

            Case DbProviders.DB2ISERIES
                s = True
                LeftBracket = Chr(34)
                RightBracket = Chr(34)
            Case DbProviders.ODBC
            Case DbProviders.ODBCDB2
            Case DbProviders.OLEDB
            Case DbProviders.OLEDBDB2
            Case DbProviders.ORACLE
                s = True
                LeftBracket = "["
                RightBracket = "]"

            Case DbProviders.SQLSERVER
                s = True
                LeftBracket = "["
                RightBracket = "]"

            Case Else
        End Select

        Return s

    End Function


    Public Shared Function GetSQLCLientConnectionString(ByVal ConnectionString As String, ByVal SQLClientAuthenticationMode As Boolean, ByVal SQLClientDatabase As String, ByVal SQLCLientServer As String, ByVal SQLCLientUserName As String, ByVal SQLCLientPassword As String) As String
        Dim BaseConnectionString As String = "Data Source=@SERVERNAME@; Initial Catalog=@DBNAME@; User ID=@USERNAME@; Password=@PASSWORD@;"
        Dim x As String = ""
        Dim SSPI As String = "Integrated Security=SSPI".ToLower()
        If (ConnectionString.Trim() = "") Then
            x = BaseConnectionString
        Else
            x = ConnectionString
        End If

        If SQLClientAuthenticationMode = False Then
            If (x.Contains(SSPI)) Then
                x.Replace(SSPI, "")
            End If
        Else
            If (x.Contains(SSPI) = False) Then
                x = x + ";" + SSPI + ";"
            End If
        End If

        x = Replace(x, "@DBNAME@", SQLClientDatabase)
        x = Replace(x, "@SERVERNAME@", SQLCLientServer)
        x = Replace(x, "@USERNAME@", SQLCLientUserName)
        x = Replace(x, "@PASSWORD@", SQLCLientPassword)
        Return x

    End Function

    Public Shared Function GetMySQLCLientConnectionString(ByVal MySQLConnectionString As String, ByVal MySQLServer As String, ByVal MySQLDatabase As String, ByVal MySQLPort As String, ByVal MySQLUserName As String, ByVal MySQLPassword As String) As String
        Dim ConnectionStringBase1 = "server=@SERVERNAME@;  database=@DATABASE@; port=@PORT@; user id=@USERNAME@; password=@PASSWORD@;"
        Dim x As String = MySQLConnectionString.Trim()
        If x = "" Then
            x = ConnectionStringBase1
        End If
        x = Replace(x, "@DATABASE@", MySQLDatabase)
        x = Replace(x, "@SERVERNAME@", MySQLServer)
        x = Replace(x, "@USERNAME@", MySQLUserName)
        x = Replace(x, "@PASSWORD@", MySQLPassword)
        x = Replace(x, "@PORT@", MySQLPort)
        Return x
    End Function

    Public Shared Function GetDBType(ByVal DataType As System.Type) As String

        Return "DbType." & DataType.Name

    End Function

    Public Shared Function GetOLEDBDB2ConnectionString(ByVal ConnectionString As String, ByVal DB2iSeriesServerName As String, ByVal DB2iSeriesUserName As String, DB2iSeriesPassword As String, DB2iSeriesInitialCatalog As String, DB2iSeriesLibraryList As String) As String

        Dim ConnectionStringBase = "Provider=IBMDA400.DataSource.1;Data Source=@SERVERNAME@;Initial Catalog=@INITIALCATALOG@;Library List=@LIBRARYLIST@;User ID=@USERNAME@;Password=@PASSWORD@;Persist Security Info=True;"

        Dim x As String = ConnectionString.Trim()
        If x = "" Then
            x = ConnectionStringBase
        End If

        x = Replace(x, "@SERVERNAME@", DB2iSeriesServerName)
        x = Replace(x, "@USERNAME@", DB2iSeriesUserName)
        x = Replace(x, "@PASSWORD@", DB2iSeriesPassword)
        x = Replace(x, "@LIBRARYLIST@", DB2iSeriesLibraryList)
        x = Replace(x, "@INITIALCATALOG@", DB2iSeriesInitialCatalog)


        Return x

    End Function
    Public Shared Function GetDB2iSeriesConnectionString(ByVal ConnectionString As String, ByVal DB2iSeriesServerName As String, ByVal DB2iSeriesUserName As String, DB2iSeriesPassword As String, DB2iSeriesLibraryList As String) As String

        Dim ConnectionStringBase = "DataSource=@SERVERNAME@;Naming=System;librarylist=@DB2ISERIESLIBRARYLIST@;UserID=@USERNAME@;Password=@PASSWORD@;"


        Dim x As String = ConnectionString
        If x = "" Then
            x = ConnectionStringBase
        End If

        x = Replace(x, "@SERVERNAME@", DB2iSeriesServerName)
        x = Replace(x, "@USERNAME@", DB2iSeriesUserName)
        x = Replace(x, "@PASSWORD@", DB2iSeriesPassword)
        x = Replace(x, "@DB2ISERIESLIBRARYLIST@", DB2iSeriesLibraryList)


        Return x

    End Function

    Public Shared Function GetOracleConnectionString(ByVal OracleServerName As String, ByVal OracleUsername As String, ByVal OraclePassword As String, ByVal OracleDedicatedServer As Boolean, ByVal OracleUseSID As Boolean, ByVal OracleServiceName As String, ByVal OraclePort As String) As String

        Dim ConnectionString As String = ""
        Dim ConnectionStringBAse1 As String = "User Id=@USERNAME@;Password=@PASSWORD@;Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=@SERVERNAME@)(PORT=@PORT@))(CONNECT_DATA=@SERVERDEDICATED@(SID=@SERVICENAME@)));"
        Dim ConnectionStringBAse2 As String = "User Id=@USERNAME@;Password=@PASSWORD@;Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=@SERVERNAME@)(PORT=@PORT@))(CONNECT_DATA=@SERVERDEDICATED@(SERVICE_NAME=@SERVICENAME@)));"
        Dim x As String = ""

        If OracleUseSID = True Then
            x = ConnectionStringBAse1
        Else
            x = ConnectionStringBAse2
        End If

        x = Replace(x, "@SERVERNAME@", OracleServerName)
        x = Replace(x, "@USERNAME@", OracleUsername)
        x = Replace(x, "@PASSWORD@", OraclePassword)
        x = Replace(x, "@SERVICENAME@", OracleServiceName)
        x = Replace(x, "@PORT@", OraclePort)

        If OracleDedicatedServer = True Then
            x = Replace(x, "@SERVERDEDICATED@", "(SERVER=DEDICATED)")
        Else
            x = Replace(x, "@SERVERDEDICATED@", "")
        End If

        ConnectionString = x

        Return ConnectionString

    End Function


End Class
