<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SQLClientResult = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SQLCLientServer = New System.Windows.Forms.TextBox()
        Me.SQLClientDatabase = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SQLClientUserName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SQLClientPassword = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SQLClientAuthenticationMode = New System.Windows.Forms.CheckBox()
        Me.SQLCLientCommandText = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TabDBProvider = New System.Windows.Forms.TabControl()
        Me.TabSQLServer = New System.Windows.Forms.TabPage()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.SQLClientParameterStyle = New System.Windows.Forms.ComboBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.SQLClientSchemaSeparator = New System.Windows.Forms.TextBox()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.SQLClientParameterPrefix = New System.Windows.Forms.TextBox()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.SQLClientConnectionString = New System.Windows.Forms.TextBox()
        Me.btnSQLServerSchema = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.SQLDBObjectType = New System.Windows.Forms.ComboBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.SQLClientObjectName = New System.Windows.Forms.TextBox()
        Me.TabOLEDB = New System.Windows.Forms.TabPage()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.btnOLEDB_Schema = New System.Windows.Forms.Button()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.OLEDBDBObjectType = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.OLEDB_CommandText = New System.Windows.Forms.TextBox()
        Me.OLEDBBuild = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.OLEDB_ObjectName = New System.Windows.Forms.TextBox()
        Me.OLEDBResult = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.OLEDBConnectionString = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.OLEDBPassword = New System.Windows.Forms.TextBox()
        Me.OLEDBUserName = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TabOLEDBDB2 = New System.Windows.Forms.TabPage()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.OLEDBDB2LibraryList = New System.Windows.Forms.TextBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.OLEDBDB2InitialCatalog = New System.Windows.Forms.TextBox()
        Me.OLEDBDB2ServerName = New System.Windows.Forms.TextBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.btn_OLEDBDB2_Schema = New System.Windows.Forms.Button()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.OLEDBDB2DbObjectType = New System.Windows.Forms.ComboBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.OLEDBDB2_CommandText = New System.Windows.Forms.TextBox()
        Me.OLEDBDB2Build = New System.Windows.Forms.Button()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.OLEDBDB2_ObjectName = New System.Windows.Forms.TextBox()
        Me.OLEDBDB2Result = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.OLEDBDB2ConnectionString = New System.Windows.Forms.TextBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.OLEDBDB2Password = New System.Windows.Forms.TextBox()
        Me.OLEDBDB2UserName = New System.Windows.Forms.TextBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.TabODBC = New System.Windows.Forms.TabPage()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.ODBCDBObjectType = New System.Windows.Forms.ComboBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.ODBCObjectName = New System.Windows.Forms.TextBox()
        Me.ODBCBuild = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ODBCTableName = New System.Windows.Forms.TextBox()
        Me.ODBCResult = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.ODBCDSNName = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.ODBCPassword = New System.Windows.Forms.TextBox()
        Me.ODBCUserName = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TabORACLE = New System.Windows.Forms.TabPage()
        Me.btnOracle_Schema = New System.Windows.Forms.Button()
        Me.btnOracleSQLCreateTable = New System.Windows.Forms.Button()
        Me.chkORACLEDEDICATEDSERVER = New System.Windows.Forms.CheckBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.OraclePort = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.OracleServiceName = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.OracleDBObjectType = New System.Windows.Forms.ComboBox()
        Me.OracleIntegratedAuth = New System.Windows.Forms.CheckBox()
        Me.OracleShowConnectionString = New System.Windows.Forms.Button()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.OracleObjectName = New System.Windows.Forms.TextBox()
        Me.OracleBuild = New System.Windows.Forms.Button()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.OracleCommandText = New System.Windows.Forms.TextBox()
        Me.OracleResult = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.OracleServerName = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.OraclePassword = New System.Windows.Forms.TextBox()
        Me.OracleUsername = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.chkORACLEUSESID = New System.Windows.Forms.CheckBox()
        Me.TabMySQL = New System.Windows.Forms.TabPage()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.cmb_MySQLParameterStyle = New System.Windows.Forms.ComboBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.txt_MySQLSchemaSeparator = New System.Windows.Forms.TextBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.txt_MySQLParameterPrefix = New System.Windows.Forms.TextBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.txt_MySQLConnectionString = New System.Windows.Forms.TextBox()
        Me.btn_MySQLSchema = New System.Windows.Forms.Button()
        Me.btn_MySQLCreateTableSQL = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txt_MySQLPort = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txt_MySQLDataBaseName = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.MySQLDBObjectType = New System.Windows.Forms.ComboBox()
        Me.btn_MySQLConnectionString = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txt_MySQLObjectName = New System.Windows.Forms.TextBox()
        Me.btm_MySQLBuild = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txt_MySQLCommandText = New System.Windows.Forms.TextBox()
        Me.txt_MySQLObjectCode = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txt_MySQLServerName = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txt_MySQLPassword = New System.Windows.Forms.TextBox()
        Me.txt_MySQLUserName = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TabDB2ISERIES = New System.Windows.Forms.TabPage()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.cmb_DB2iSeries_ParameterStyle = New System.Windows.Forms.ComboBox()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.txt_DB2iSeries_SchemaSeparator = New System.Windows.Forms.TextBox()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.txt_DB2iSeries_ParameterPrefix = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txt_DB2ISeries_ConnectionString = New System.Windows.Forms.TextBox()
        Me.btn_IBMISERIESSchema = New System.Windows.Forms.Button()
        Me.bnt_CreateTable = New System.Windows.Forms.Button()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txt_DB2ISeries_LibraryList = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.cmd_DB2ISeries_DbObjectType = New System.Windows.Forms.ComboBox()
        Me.bnt_DB2ISeries_ShowConnectionString = New System.Windows.Forms.Button()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.txt_DB2ISeries_ObjecName = New System.Windows.Forms.TextBox()
        Me.btn_DB2ISeries_Build = New System.Windows.Forms.Button()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.txt_DB2ISeries_CommandText = New System.Windows.Forms.TextBox()
        Me.txt_DB2ISeries_ObjectCode = New System.Windows.Forms.TextBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.txt_DB2ISeries_ServerName = New System.Windows.Forms.TextBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.txt_DB2ISeries_Password = New System.Windows.Forms.TextBox()
        Me.txt_DB2ISeries_UserName = New System.Windows.Forms.TextBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.cmbLanguage = New System.Windows.Forms.ComboBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.cmbBuildOption = New System.Windows.Forms.ComboBox()
        Me.TabDBProvider.SuspendLayout()
        Me.TabSQLServer.SuspendLayout()
        Me.TabOLEDB.SuspendLayout()
        Me.TabOLEDBDB2.SuspendLayout()
        Me.TabODBC.SuspendLayout()
        Me.TabORACLE.SuspendLayout()
        Me.TabMySQL.SuspendLayout()
        Me.TabDB2ISERIES.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Location = New System.Drawing.Point(507, 527)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(110, 25)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Build"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'SQLClientResult
        '
        Me.SQLClientResult.Location = New System.Drawing.Point(6, 393)
        Me.SQLClientResult.Multiline = True
        Me.SQLClientResult.Name = "SQLClientResult"
        Me.SQLClientResult.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.SQLClientResult.Size = New System.Drawing.Size(612, 129)
        Me.SQLClientResult.TabIndex = 1
        Me.SQLClientResult.WordWrap = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(209, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "SQLServer Instance (@SERVERNAME@)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'SQLCLientServer
        '
        Me.SQLCLientServer.Location = New System.Drawing.Point(6, 99)
        Me.SQLCLientServer.Name = "SQLCLientServer"
        Me.SQLCLientServer.Size = New System.Drawing.Size(220, 20)
        Me.SQLCLientServer.TabIndex = 3
        Me.SQLCLientServer.Text = "(local)"
        '
        'SQLClientDatabase
        '
        Me.SQLClientDatabase.Location = New System.Drawing.Point(232, 99)
        Me.SQLClientDatabase.Name = "SQLClientDatabase"
        Me.SQLClientDatabase.Size = New System.Drawing.Size(220, 20)
        Me.SQLClientDatabase.TabIndex = 5
        Me.SQLClientDatabase.Text = "testdb"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(229, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(131, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "DataBase (@DBNAME@)"
        '
        'SQLClientUserName
        '
        Me.SQLClientUserName.Location = New System.Drawing.Point(134, 136)
        Me.SQLClientUserName.Name = "SQLClientUserName"
        Me.SQLClientUserName.Size = New System.Drawing.Size(220, 20)
        Me.SQLClientUserName.TabIndex = 7
        Me.SQLClientUserName.Text = "sa"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(131, 121)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(149, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "UserName (@USERNAME@)"
        '
        'SQLClientPassword
        '
        Me.SQLClientPassword.Location = New System.Drawing.Point(360, 136)
        Me.SQLClientPassword.Name = "SQLClientPassword"
        Me.SQLClientPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.SQLClientPassword.Size = New System.Drawing.Size(220, 20)
        Me.SQLClientPassword.TabIndex = 9
        Me.SQLClientPassword.Text = "SQL1qaz@2wsx"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(357, 121)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(147, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Password (@PASSWORD@)"
        '
        'SQLClientAuthenticationMode
        '
        Me.SQLClientAuthenticationMode.AutoSize = True
        Me.SQLClientAuthenticationMode.Location = New System.Drawing.Point(6, 136)
        Me.SQLClientAuthenticationMode.Name = "SQLClientAuthenticationMode"
        Me.SQLClientAuthenticationMode.Size = New System.Drawing.Size(121, 17)
        Me.SQLClientAuthenticationMode.TabIndex = 12
        Me.SQLClientAuthenticationMode.Text = "SSPI Authentication"
        Me.SQLClientAuthenticationMode.UseVisualStyleBackColor = True
        '
        'SQLCLientCommandText
        '
        Me.SQLCLientCommandText.Location = New System.Drawing.Point(6, 260)
        Me.SQLCLientCommandText.Multiline = True
        Me.SQLCLientCommandText.Name = "SQLCLientCommandText"
        Me.SQLCLientCommandText.Size = New System.Drawing.Size(612, 113)
        Me.SQLCLientCommandText.TabIndex = 14
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(3, 244)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(96, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "SQLCommandText"
        '
        'TabDBProvider
        '
        Me.TabDBProvider.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TabDBProvider.Controls.Add(Me.TabSQLServer)
        Me.TabDBProvider.Controls.Add(Me.TabOLEDB)
        Me.TabDBProvider.Controls.Add(Me.TabOLEDBDB2)
        Me.TabDBProvider.Controls.Add(Me.TabODBC)
        Me.TabDBProvider.Controls.Add(Me.TabORACLE)
        Me.TabDBProvider.Controls.Add(Me.TabMySQL)
        Me.TabDBProvider.Controls.Add(Me.TabDB2ISERIES)
        Me.TabDBProvider.Location = New System.Drawing.Point(4, 47)
        Me.TabDBProvider.Name = "TabDBProvider"
        Me.TabDBProvider.SelectedIndex = 0
        Me.TabDBProvider.Size = New System.Drawing.Size(632, 582)
        Me.TabDBProvider.TabIndex = 16
        '
        'TabSQLServer
        '
        Me.TabSQLServer.BackColor = System.Drawing.SystemColors.Menu
        Me.TabSQLServer.Controls.Add(Me.Label65)
        Me.TabSQLServer.Controls.Add(Me.SQLClientParameterStyle)
        Me.TabSQLServer.Controls.Add(Me.Label64)
        Me.TabSQLServer.Controls.Add(Me.SQLClientSchemaSeparator)
        Me.TabSQLServer.Controls.Add(Me.Label63)
        Me.TabSQLServer.Controls.Add(Me.SQLClientParameterPrefix)
        Me.TabSQLServer.Controls.Add(Me.Label62)
        Me.TabSQLServer.Controls.Add(Me.SQLClientConnectionString)
        Me.TabSQLServer.Controls.Add(Me.btnSQLServerSchema)
        Me.TabSQLServer.Controls.Add(Me.Button4)
        Me.TabSQLServer.Controls.Add(Me.Label37)
        Me.TabSQLServer.Controls.Add(Me.SQLDBObjectType)
        Me.TabSQLServer.Controls.Add(Me.Button3)
        Me.TabSQLServer.Controls.Add(Me.Label22)
        Me.TabSQLServer.Controls.Add(Me.Label19)
        Me.TabSQLServer.Controls.Add(Me.SQLClientObjectName)
        Me.TabSQLServer.Controls.Add(Me.Label1)
        Me.TabSQLServer.Controls.Add(Me.Button1)
        Me.TabSQLServer.Controls.Add(Me.SQLCLientCommandText)
        Me.TabSQLServer.Controls.Add(Me.SQLClientResult)
        Me.TabSQLServer.Controls.Add(Me.Label6)
        Me.TabSQLServer.Controls.Add(Me.SQLCLientServer)
        Me.TabSQLServer.Controls.Add(Me.SQLClientAuthenticationMode)
        Me.TabSQLServer.Controls.Add(Me.Label2)
        Me.TabSQLServer.Controls.Add(Me.SQLClientDatabase)
        Me.TabSQLServer.Controls.Add(Me.Label3)
        Me.TabSQLServer.Controls.Add(Me.SQLClientPassword)
        Me.TabSQLServer.Controls.Add(Me.SQLClientUserName)
        Me.TabSQLServer.Controls.Add(Me.Label4)
        Me.TabSQLServer.Location = New System.Drawing.Point(4, 22)
        Me.TabSQLServer.Name = "TabSQLServer"
        Me.TabSQLServer.Padding = New System.Windows.Forms.Padding(3)
        Me.TabSQLServer.Size = New System.Drawing.Size(624, 556)
        Me.TabSQLServer.TabIndex = 0
        Me.TabSQLServer.Text = "SQLServer"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(89, 160)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(81, 13)
        Me.Label65.TabIndex = 79
        Me.Label65.Text = "Parameter Style"
        '
        'SQLClientParameterStyle
        '
        Me.SQLClientParameterStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SQLClientParameterStyle.FormattingEnabled = True
        Me.SQLClientParameterStyle.Items.AddRange(New Object() {"0 - Simple", "1 - Qualified"})
        Me.SQLClientParameterStyle.Location = New System.Drawing.Point(91, 174)
        Me.SQLClientParameterStyle.Name = "SQLClientParameterStyle"
        Me.SQLClientParameterStyle.Size = New System.Drawing.Size(111, 21)
        Me.SQLClientParameterStyle.TabIndex = 78
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(202, 160)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(71, 13)
        Me.Label64.TabIndex = 76
        Me.Label64.Text = "Schema Sep."
        '
        'SQLClientSchemaSeparator
        '
        Me.SQLClientSchemaSeparator.Location = New System.Drawing.Point(205, 174)
        Me.SQLClientSchemaSeparator.Name = "SQLClientSchemaSeparator"
        Me.SQLClientSchemaSeparator.Size = New System.Drawing.Size(68, 20)
        Me.SQLClientSchemaSeparator.TabIndex = 77
        Me.SQLClientSchemaSeparator.Text = "."
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(4, 160)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(84, 13)
        Me.Label63.TabIndex = 74
        Me.Label63.Text = "Parameter Prefix"
        '
        'SQLClientParameterPrefix
        '
        Me.SQLClientParameterPrefix.Location = New System.Drawing.Point(7, 174)
        Me.SQLClientParameterPrefix.Name = "SQLClientParameterPrefix"
        Me.SQLClientParameterPrefix.Size = New System.Drawing.Size(81, 20)
        Me.SQLClientParameterPrefix.TabIndex = 75
        Me.SQLClientParameterPrefix.Text = "@"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(3, 7)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(91, 13)
        Me.Label62.TabIndex = 72
        Me.Label62.Text = "Connection String"
        '
        'SQLClientConnectionString
        '
        Me.SQLClientConnectionString.Location = New System.Drawing.Point(6, 21)
        Me.SQLClientConnectionString.Multiline = True
        Me.SQLClientConnectionString.Name = "SQLClientConnectionString"
        Me.SQLClientConnectionString.Size = New System.Drawing.Size(611, 62)
        Me.SQLClientConnectionString.TabIndex = 73
        Me.SQLClientConnectionString.Text = "Data Source=@SERVERNAME@; Initial Catalog=@DBNAME@; User ID=@USERNAME@; Password=" &
    "@PASSWORD@;" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'btnSQLServerSchema
        '
        Me.btnSQLServerSchema.Location = New System.Drawing.Point(594, 219)
        Me.btnSQLServerSchema.Name = "btnSQLServerSchema"
        Me.btnSQLServerSchema.Size = New System.Drawing.Size(25, 23)
        Me.btnSQLServerSchema.TabIndex = 71
        Me.btnSQLServerSchema.Text = "..."
        Me.btnSQLServerSchema.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button4.Location = New System.Drawing.Point(4, 527)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(176, 25)
        Me.Button4.TabIndex = 70
        Me.Button4.Text = "SQL Create Table Statement"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(322, 206)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(83, 13)
        Me.Label37.TabIndex = 69
        Me.Label37.Text = "DB Object Type"
        '
        'SQLDBObjectType
        '
        Me.SQLDBObjectType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SQLDBObjectType.FormattingEnabled = True
        Me.SQLDBObjectType.Items.AddRange(New Object() {"0 - Table", "1 - View", "2 - SQL Statement", "3 - Stored Procedure", "4 - Table Function", "5 - Scalar Function"})
        Me.SQLDBObjectType.Location = New System.Drawing.Point(325, 220)
        Me.SQLDBObjectType.Name = "SQLDBObjectType"
        Me.SQLDBObjectType.Size = New System.Drawing.Size(267, 21)
        Me.SQLDBObjectType.TabIndex = 68
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.Location = New System.Drawing.Point(352, 527)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(149, 25)
        Me.Button3.TabIndex = 49
        Me.Button3.Text = "Show Connection String"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(3, 377)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(66, 13)
        Me.Label22.TabIndex = 18
        Me.Label22.Text = "Object Code"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(4, 206)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(69, 13)
        Me.Label19.TabIndex = 16
        Me.Label19.Text = "Object Name"
        '
        'SQLClientObjectName
        '
        Me.SQLClientObjectName.Location = New System.Drawing.Point(7, 220)
        Me.SQLClientObjectName.Name = "SQLClientObjectName"
        Me.SQLClientObjectName.Size = New System.Drawing.Size(315, 20)
        Me.SQLClientObjectName.TabIndex = 17
        '
        'TabOLEDB
        '
        Me.TabOLEDB.BackColor = System.Drawing.SystemColors.Menu
        Me.TabOLEDB.Controls.Add(Me.Label70)
        Me.TabOLEDB.Controls.Add(Me.ComboBox1)
        Me.TabOLEDB.Controls.Add(Me.Label71)
        Me.TabOLEDB.Controls.Add(Me.TextBox1)
        Me.TabOLEDB.Controls.Add(Me.Label72)
        Me.TabOLEDB.Controls.Add(Me.TextBox2)
        Me.TabOLEDB.Controls.Add(Me.Button5)
        Me.TabOLEDB.Controls.Add(Me.Button6)
        Me.TabOLEDB.Controls.Add(Me.btnOLEDB_Schema)
        Me.TabOLEDB.Controls.Add(Me.Label39)
        Me.TabOLEDB.Controls.Add(Me.OLEDBDBObjectType)
        Me.TabOLEDB.Controls.Add(Me.Label26)
        Me.TabOLEDB.Controls.Add(Me.Label25)
        Me.TabOLEDB.Controls.Add(Me.OLEDB_CommandText)
        Me.TabOLEDB.Controls.Add(Me.OLEDBBuild)
        Me.TabOLEDB.Controls.Add(Me.Label7)
        Me.TabOLEDB.Controls.Add(Me.OLEDB_ObjectName)
        Me.TabOLEDB.Controls.Add(Me.OLEDBResult)
        Me.TabOLEDB.Controls.Add(Me.Label8)
        Me.TabOLEDB.Controls.Add(Me.OLEDBConnectionString)
        Me.TabOLEDB.Controls.Add(Me.Label11)
        Me.TabOLEDB.Controls.Add(Me.OLEDBPassword)
        Me.TabOLEDB.Controls.Add(Me.OLEDBUserName)
        Me.TabOLEDB.Controls.Add(Me.Label12)
        Me.TabOLEDB.Location = New System.Drawing.Point(4, 22)
        Me.TabOLEDB.Name = "TabOLEDB"
        Me.TabOLEDB.Padding = New System.Windows.Forms.Padding(3)
        Me.TabOLEDB.Size = New System.Drawing.Size(624, 556)
        Me.TabOLEDB.TabIndex = 1
        Me.TabOLEDB.Text = "OLE-DB"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(88, 124)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(81, 13)
        Me.Label70.TabIndex = 85
        Me.Label70.Text = "Parameter Style"
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"0 - Simple", "1 - Qualified"})
        Me.ComboBox1.Location = New System.Drawing.Point(90, 138)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(111, 21)
        Me.ComboBox1.TabIndex = 84
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(201, 124)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(71, 13)
        Me.Label71.TabIndex = 82
        Me.Label71.Text = "Schema Sep."
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(204, 138)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(68, 20)
        Me.TextBox1.TabIndex = 83
        Me.TextBox1.Text = "."
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(3, 124)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(84, 13)
        Me.Label72.TabIndex = 80
        Me.Label72.Text = "Parameter Prefix"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(6, 138)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(81, 20)
        Me.TextBox2.TabIndex = 81
        Me.TextBox2.Text = "@"
        '
        'Button5
        '
        Me.Button5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button5.Location = New System.Drawing.Point(4, 527)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(176, 25)
        Me.Button5.TabIndex = 74
        Me.Button5.Text = "SQL Create Table Statement"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button6.Location = New System.Drawing.Point(351, 527)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(149, 25)
        Me.Button6.TabIndex = 73
        Me.Button6.Text = "Show Connection String"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'btnOLEDB_Schema
        '
        Me.btnOLEDB_Schema.Location = New System.Drawing.Point(592, 177)
        Me.btnOLEDB_Schema.Name = "btnOLEDB_Schema"
        Me.btnOLEDB_Schema.Size = New System.Drawing.Size(25, 23)
        Me.btnOLEDB_Schema.TabIndex = 72
        Me.btnOLEDB_Schema.Text = "..."
        Me.btnOLEDB_Schema.UseVisualStyleBackColor = True
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(325, 164)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(83, 13)
        Me.Label39.TabIndex = 71
        Me.Label39.Text = "DB Object Type"
        '
        'OLEDBDBObjectType
        '
        Me.OLEDBDBObjectType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OLEDBDBObjectType.FormattingEnabled = True
        Me.OLEDBDBObjectType.Items.AddRange(New Object() {"0 - Table", "1 - View", "2 - SQL statement"})
        Me.OLEDBDBObjectType.Location = New System.Drawing.Point(324, 178)
        Me.OLEDBDBObjectType.Name = "OLEDBDBObjectType"
        Me.OLEDBDBObjectType.Size = New System.Drawing.Size(267, 21)
        Me.OLEDBDBObjectType.TabIndex = 70
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(4, 312)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(66, 13)
        Me.Label26.TabIndex = 34
        Me.Label26.Text = "Object Code"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(1, 164)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(69, 13)
        Me.Label25.TabIndex = 32
        Me.Label25.Text = "Object Name"
        '
        'OLEDB_CommandText
        '
        Me.OLEDB_CommandText.Location = New System.Drawing.Point(5, 178)
        Me.OLEDB_CommandText.Name = "OLEDB_CommandText"
        Me.OLEDB_CommandText.Size = New System.Drawing.Size(316, 20)
        Me.OLEDB_CommandText.TabIndex = 33
        '
        'OLEDBBuild
        '
        Me.OLEDBBuild.Location = New System.Drawing.Point(506, 527)
        Me.OLEDBBuild.Name = "OLEDBBuild"
        Me.OLEDBBuild.Size = New System.Drawing.Size(110, 25)
        Me.OLEDBBuild.TabIndex = 31
        Me.OLEDBBuild.Text = "Build"
        Me.OLEDBBuild.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(2, 4)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(91, 13)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Connection String"
        '
        'OLEDB_ObjectName
        '
        Me.OLEDB_ObjectName.Location = New System.Drawing.Point(5, 217)
        Me.OLEDB_ObjectName.Multiline = True
        Me.OLEDB_ObjectName.Name = "OLEDB_ObjectName"
        Me.OLEDB_ObjectName.Size = New System.Drawing.Size(612, 92)
        Me.OLEDB_ObjectName.TabIndex = 29
        '
        'OLEDBResult
        '
        Me.OLEDBResult.Location = New System.Drawing.Point(5, 328)
        Me.OLEDBResult.Multiline = True
        Me.OLEDBResult.Name = "OLEDBResult"
        Me.OLEDBResult.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.OLEDBResult.Size = New System.Drawing.Size(612, 159)
        Me.OLEDBResult.TabIndex = 16
        Me.OLEDBResult.WordWrap = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(2, 201)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(96, 13)
        Me.Label8.TabIndex = 28
        Me.Label8.Text = "SQLCommandText"
        '
        'OLEDBConnectionString
        '
        Me.OLEDBConnectionString.Location = New System.Drawing.Point(5, 20)
        Me.OLEDBConnectionString.Multiline = True
        Me.OLEDBConnectionString.Name = "OLEDBConnectionString"
        Me.OLEDBConnectionString.Size = New System.Drawing.Size(611, 62)
        Me.OLEDBConnectionString.TabIndex = 18
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(2, 85)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(149, 13)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "UserName (@USERNAME@)"
        '
        'OLEDBPassword
        '
        Me.OLEDBPassword.Location = New System.Drawing.Point(231, 101)
        Me.OLEDBPassword.Name = "OLEDBPassword"
        Me.OLEDBPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.OLEDBPassword.Size = New System.Drawing.Size(220, 20)
        Me.OLEDBPassword.TabIndex = 24
        '
        'OLEDBUserName
        '
        Me.OLEDBUserName.Location = New System.Drawing.Point(5, 101)
        Me.OLEDBUserName.Name = "OLEDBUserName"
        Me.OLEDBUserName.Size = New System.Drawing.Size(220, 20)
        Me.OLEDBUserName.TabIndex = 22
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(228, 85)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(147, 13)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "Password (@PASSWORD@)"
        '
        'TabOLEDBDB2
        '
        Me.TabOLEDBDB2.BackColor = System.Drawing.SystemColors.Menu
        Me.TabOLEDBDB2.Controls.Add(Me.Label73)
        Me.TabOLEDBDB2.Controls.Add(Me.ComboBox2)
        Me.TabOLEDBDB2.Controls.Add(Me.Label74)
        Me.TabOLEDBDB2.Controls.Add(Me.TextBox3)
        Me.TabOLEDBDB2.Controls.Add(Me.Label75)
        Me.TabOLEDBDB2.Controls.Add(Me.TextBox4)
        Me.TabOLEDBDB2.Controls.Add(Me.OLEDBDB2LibraryList)
        Me.TabOLEDBDB2.Controls.Add(Me.Label61)
        Me.TabOLEDBDB2.Controls.Add(Me.Label59)
        Me.TabOLEDBDB2.Controls.Add(Me.OLEDBDB2InitialCatalog)
        Me.TabOLEDBDB2.Controls.Add(Me.OLEDBDB2ServerName)
        Me.TabOLEDBDB2.Controls.Add(Me.Label60)
        Me.TabOLEDBDB2.Controls.Add(Me.Button8)
        Me.TabOLEDBDB2.Controls.Add(Me.Button9)
        Me.TabOLEDBDB2.Controls.Add(Me.btn_OLEDBDB2_Schema)
        Me.TabOLEDBDB2.Controls.Add(Me.Label43)
        Me.TabOLEDBDB2.Controls.Add(Me.OLEDBDB2DbObjectType)
        Me.TabOLEDBDB2.Controls.Add(Me.Label44)
        Me.TabOLEDBDB2.Controls.Add(Me.Label45)
        Me.TabOLEDBDB2.Controls.Add(Me.OLEDBDB2_CommandText)
        Me.TabOLEDBDB2.Controls.Add(Me.OLEDBDB2Build)
        Me.TabOLEDBDB2.Controls.Add(Me.Label46)
        Me.TabOLEDBDB2.Controls.Add(Me.OLEDBDB2_ObjectName)
        Me.TabOLEDBDB2.Controls.Add(Me.OLEDBDB2Result)
        Me.TabOLEDBDB2.Controls.Add(Me.Label47)
        Me.TabOLEDBDB2.Controls.Add(Me.OLEDBDB2ConnectionString)
        Me.TabOLEDBDB2.Controls.Add(Me.Label49)
        Me.TabOLEDBDB2.Controls.Add(Me.OLEDBDB2Password)
        Me.TabOLEDBDB2.Controls.Add(Me.OLEDBDB2UserName)
        Me.TabOLEDBDB2.Controls.Add(Me.Label50)
        Me.TabOLEDBDB2.Location = New System.Drawing.Point(4, 22)
        Me.TabOLEDBDB2.Name = "TabOLEDBDB2"
        Me.TabOLEDBDB2.Size = New System.Drawing.Size(624, 556)
        Me.TabOLEDBDB2.TabIndex = 6
        Me.TabOLEDBDB2.Text = "OLE-DB DB2"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(88, 153)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(81, 13)
        Me.Label73.TabIndex = 103
        Me.Label73.Text = "Parameter Style"
        '
        'ComboBox2
        '
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"0 - Simple", "1 - Qualified"})
        Me.ComboBox2.Location = New System.Drawing.Point(90, 167)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(111, 21)
        Me.ComboBox2.TabIndex = 102
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(201, 153)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(71, 13)
        Me.Label74.TabIndex = 100
        Me.Label74.Text = "Schema Sep."
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(204, 167)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(68, 20)
        Me.TextBox3.TabIndex = 101
        Me.TextBox3.Text = "."
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(3, 153)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(84, 13)
        Me.Label75.TabIndex = 98
        Me.Label75.Text = "Parameter Prefix"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(6, 167)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(81, 20)
        Me.TextBox4.TabIndex = 99
        Me.TextBox4.Text = "@"
        '
        'OLEDBDB2LibraryList
        '
        Me.OLEDBDB2LibraryList.Location = New System.Drawing.Point(368, 91)
        Me.OLEDBDB2LibraryList.Name = "OLEDBDB2LibraryList"
        Me.OLEDBDB2LibraryList.Size = New System.Drawing.Size(249, 20)
        Me.OLEDBDB2LibraryList.TabIndex = 97
        Me.OLEDBDB2LibraryList.Text = "GDELGIO1"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(365, 75)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(157, 13)
        Me.Label61.TabIndex = 96
        Me.Label61.Text = "Library List (@LIBRARYLIST@)"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(4, 75)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(175, 13)
        Me.Label59.TabIndex = 92
        Me.Label59.Text = "Server Name (@SERVERNAME@)"
        '
        'OLEDBDB2InitialCatalog
        '
        Me.OLEDBDB2InitialCatalog.Location = New System.Drawing.Point(181, 91)
        Me.OLEDBDB2InitialCatalog.Name = "OLEDBDB2InitialCatalog"
        Me.OLEDBDB2InitialCatalog.Size = New System.Drawing.Size(185, 20)
        Me.OLEDBDB2InitialCatalog.TabIndex = 95
        Me.OLEDBDB2InitialCatalog.Text = "PUB400"
        '
        'OLEDBDB2ServerName
        '
        Me.OLEDBDB2ServerName.Location = New System.Drawing.Point(7, 91)
        Me.OLEDBDB2ServerName.Name = "OLEDBDB2ServerName"
        Me.OLEDBDB2ServerName.Size = New System.Drawing.Size(172, 20)
        Me.OLEDBDB2ServerName.TabIndex = 93
        Me.OLEDBDB2ServerName.Text = "PUB400.COM"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(178, 75)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(188, 13)
        Me.Label60.TabIndex = 94
        Me.Label60.Text = "Initial Catalog (@INITIALCATALOG@)"
        '
        'Button8
        '
        Me.Button8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button8.Location = New System.Drawing.Point(4, 528)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(176, 25)
        Me.Button8.TabIndex = 91
        Me.Button8.Text = "SQL Create Table Statement"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button9.Location = New System.Drawing.Point(350, 528)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(149, 25)
        Me.Button9.TabIndex = 90
        Me.Button9.Text = "Show Connection String"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'btn_OLEDBDB2_Schema
        '
        Me.btn_OLEDBDB2_Schema.Location = New System.Drawing.Point(592, 203)
        Me.btn_OLEDBDB2_Schema.Name = "btn_OLEDBDB2_Schema"
        Me.btn_OLEDBDB2_Schema.Size = New System.Drawing.Size(25, 23)
        Me.btn_OLEDBDB2_Schema.TabIndex = 89
        Me.btn_OLEDBDB2_Schema.Text = "..."
        Me.btn_OLEDBDB2_Schema.UseVisualStyleBackColor = True
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(326, 190)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(83, 13)
        Me.Label43.TabIndex = 88
        Me.Label43.Text = "DB Object Type"
        '
        'OLEDBDB2DbObjectType
        '
        Me.OLEDBDB2DbObjectType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OLEDBDB2DbObjectType.FormattingEnabled = True
        Me.OLEDBDB2DbObjectType.Items.AddRange(New Object() {"0 - Table", "1 - View", "2 - SQL statement"})
        Me.OLEDBDB2DbObjectType.Location = New System.Drawing.Point(327, 204)
        Me.OLEDBDB2DbObjectType.Name = "OLEDBDB2DbObjectType"
        Me.OLEDBDB2DbObjectType.Size = New System.Drawing.Size(263, 21)
        Me.OLEDBDB2DbObjectType.TabIndex = 87
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(4, 367)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(66, 13)
        Me.Label44.TabIndex = 86
        Me.Label44.Text = "Object Code"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(4, 190)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(69, 13)
        Me.Label45.TabIndex = 84
        Me.Label45.Text = "Object Name"
        '
        'OLEDBDB2_CommandText
        '
        Me.OLEDBDB2_CommandText.Location = New System.Drawing.Point(6, 204)
        Me.OLEDBDB2_CommandText.Name = "OLEDBDB2_CommandText"
        Me.OLEDBDB2_CommandText.Size = New System.Drawing.Size(317, 20)
        Me.OLEDBDB2_CommandText.TabIndex = 85
        '
        'OLEDBDB2Build
        '
        Me.OLEDBDB2Build.Location = New System.Drawing.Point(508, 528)
        Me.OLEDBDB2Build.Name = "OLEDBDB2Build"
        Me.OLEDBDB2Build.Size = New System.Drawing.Size(110, 25)
        Me.OLEDBDB2Build.TabIndex = 83
        Me.OLEDBDB2Build.Text = "Build"
        Me.OLEDBDB2Build.UseVisualStyleBackColor = True
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(5, 4)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(91, 13)
        Me.Label46.TabIndex = 73
        Me.Label46.Text = "Connection String"
        '
        'OLEDBDB2_ObjectName
        '
        Me.OLEDBDB2_ObjectName.Location = New System.Drawing.Point(6, 241)
        Me.OLEDBDB2_ObjectName.Multiline = True
        Me.OLEDBDB2_ObjectName.Name = "OLEDBDB2_ObjectName"
        Me.OLEDBDB2_ObjectName.Size = New System.Drawing.Size(612, 123)
        Me.OLEDBDB2_ObjectName.TabIndex = 82
        '
        'OLEDBDB2Result
        '
        Me.OLEDBDB2Result.Location = New System.Drawing.Point(6, 381)
        Me.OLEDBDB2Result.Multiline = True
        Me.OLEDBDB2Result.Name = "OLEDBDB2Result"
        Me.OLEDBDB2Result.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.OLEDBDB2Result.Size = New System.Drawing.Size(612, 138)
        Me.OLEDBDB2Result.TabIndex = 72
        Me.OLEDBDB2Result.WordWrap = False
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(3, 227)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(96, 13)
        Me.Label47.TabIndex = 81
        Me.Label47.Text = "SQLCommandText"
        '
        'OLEDBDB2ConnectionString
        '
        Me.OLEDBDB2ConnectionString.Location = New System.Drawing.Point(7, 18)
        Me.OLEDBDB2ConnectionString.Multiline = True
        Me.OLEDBDB2ConnectionString.Name = "OLEDBDB2ConnectionString"
        Me.OLEDBDB2ConnectionString.Size = New System.Drawing.Size(611, 54)
        Me.OLEDBDB2ConnectionString.TabIndex = 74
        Me.OLEDBDB2ConnectionString.Text = "Provider=IBMDA400.DataSource.1;Data Source=@SERVERNAME@;Initial Catalog=@INITIALC" &
    "ATALOG@;User ID=@USERNAME@;Password=@PASSWORD@;Persist Security Info=True;Librar" &
    "y List=@LIBRARYLIST@;"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(3, 114)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(149, 13)
        Me.Label49.TabIndex = 75
        Me.Label49.Text = "UserName (@USERNAME@)"
        '
        'OLEDBDB2Password
        '
        Me.OLEDBDB2Password.Location = New System.Drawing.Point(228, 130)
        Me.OLEDBDB2Password.Name = "OLEDBDB2Password"
        Me.OLEDBDB2Password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.OLEDBDB2Password.Size = New System.Drawing.Size(220, 20)
        Me.OLEDBDB2Password.TabIndex = 78
        Me.OLEDBDB2Password.Text = "GDG1qaz2wsx"
        '
        'OLEDBDB2UserName
        '
        Me.OLEDBDB2UserName.Location = New System.Drawing.Point(6, 130)
        Me.OLEDBDB2UserName.Name = "OLEDBDB2UserName"
        Me.OLEDBDB2UserName.Size = New System.Drawing.Size(220, 20)
        Me.OLEDBDB2UserName.TabIndex = 76
        Me.OLEDBDB2UserName.Text = "GDELGIO"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(225, 114)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(147, 13)
        Me.Label50.TabIndex = 77
        Me.Label50.Text = "Password (@PASSWORD@)"
        '
        'TabODBC
        '
        Me.TabODBC.BackColor = System.Drawing.SystemColors.Menu
        Me.TabODBC.Controls.Add(Me.Label76)
        Me.TabODBC.Controls.Add(Me.ComboBox3)
        Me.TabODBC.Controls.Add(Me.Label77)
        Me.TabODBC.Controls.Add(Me.TextBox5)
        Me.TabODBC.Controls.Add(Me.Label78)
        Me.TabODBC.Controls.Add(Me.TextBox6)
        Me.TabODBC.Controls.Add(Me.Button10)
        Me.TabODBC.Controls.Add(Me.Button7)
        Me.TabODBC.Controls.Add(Me.Label40)
        Me.TabODBC.Controls.Add(Me.ODBCDBObjectType)
        Me.TabODBC.Controls.Add(Me.Button2)
        Me.TabODBC.Controls.Add(Me.Label28)
        Me.TabODBC.Controls.Add(Me.Label27)
        Me.TabODBC.Controls.Add(Me.ODBCObjectName)
        Me.TabODBC.Controls.Add(Me.ODBCBuild)
        Me.TabODBC.Controls.Add(Me.Label9)
        Me.TabODBC.Controls.Add(Me.ODBCTableName)
        Me.TabODBC.Controls.Add(Me.ODBCResult)
        Me.TabODBC.Controls.Add(Me.Label13)
        Me.TabODBC.Controls.Add(Me.ODBCDSNName)
        Me.TabODBC.Controls.Add(Me.Label15)
        Me.TabODBC.Controls.Add(Me.ODBCPassword)
        Me.TabODBC.Controls.Add(Me.ODBCUserName)
        Me.TabODBC.Controls.Add(Me.Label16)
        Me.TabODBC.Location = New System.Drawing.Point(4, 22)
        Me.TabODBC.Name = "TabODBC"
        Me.TabODBC.Size = New System.Drawing.Size(624, 556)
        Me.TabODBC.TabIndex = 2
        Me.TabODBC.Text = "ODBC"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(87, 110)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(81, 13)
        Me.Label76.TabIndex = 85
        Me.Label76.Text = "Parameter Style"
        '
        'ComboBox3
        '
        Me.ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Items.AddRange(New Object() {"0 - Simple", "1 - Qualified"})
        Me.ComboBox3.Location = New System.Drawing.Point(89, 124)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(111, 21)
        Me.ComboBox3.TabIndex = 84
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(200, 110)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(71, 13)
        Me.Label77.TabIndex = 82
        Me.Label77.Text = "Schema Sep."
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(203, 124)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(68, 20)
        Me.TextBox5.TabIndex = 83
        Me.TextBox5.Text = "."
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(2, 110)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(84, 13)
        Me.Label78.TabIndex = 80
        Me.Label78.Text = "Parameter Prefix"
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(5, 124)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(81, 20)
        Me.TextBox6.TabIndex = 81
        Me.TextBox6.Text = "@"
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(4, 527)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(176, 25)
        Me.Button10.TabIndex = 75
        Me.Button10.Text = "SQL Create Table Statement"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(588, 160)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(25, 23)
        Me.Button7.TabIndex = 73
        Me.Button7.Text = "..."
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(323, 147)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(83, 13)
        Me.Label40.TabIndex = 71
        Me.Label40.Text = "DB Object Type"
        '
        'ODBCDBObjectType
        '
        Me.ODBCDBObjectType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ODBCDBObjectType.FormattingEnabled = True
        Me.ODBCDBObjectType.Items.AddRange(New Object() {"0 - Table", "1 - View", "2 - SQL statement"})
        Me.ODBCDBObjectType.Location = New System.Drawing.Point(325, 161)
        Me.ODBCDBObjectType.Name = "ODBCDBObjectType"
        Me.ODBCDBObjectType.Size = New System.Drawing.Size(262, 21)
        Me.ODBCDBObjectType.TabIndex = 70
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(351, 527)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(149, 25)
        Me.Button2.TabIndex = 48
        Me.Button2.Text = "Show Connection String"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(2, 299)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(66, 13)
        Me.Label28.TabIndex = 47
        Me.Label28.Text = "Object Code"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(1, 147)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(69, 13)
        Me.Label27.TabIndex = 45
        Me.Label27.Text = "Object Name"
        '
        'ODBCObjectName
        '
        Me.ODBCObjectName.Location = New System.Drawing.Point(4, 161)
        Me.ODBCObjectName.Name = "ODBCObjectName"
        Me.ODBCObjectName.Size = New System.Drawing.Size(318, 20)
        Me.ODBCObjectName.TabIndex = 46
        Me.ODBCObjectName.Text = "DBObjectName"
        '
        'ODBCBuild
        '
        Me.ODBCBuild.Location = New System.Drawing.Point(506, 527)
        Me.ODBCBuild.Name = "ODBCBuild"
        Me.ODBCBuild.Size = New System.Drawing.Size(110, 25)
        Me.ODBCBuild.TabIndex = 44
        Me.ODBCBuild.Text = "Build"
        Me.ODBCBuild.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(1, 39)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 13)
        Me.Label9.TabIndex = 33
        Me.Label9.Text = "DSN Name"
        '
        'ODBCTableName
        '
        Me.ODBCTableName.Location = New System.Drawing.Point(4, 197)
        Me.ODBCTableName.Multiline = True
        Me.ODBCTableName.Name = "ODBCTableName"
        Me.ODBCTableName.Size = New System.Drawing.Size(612, 99)
        Me.ODBCTableName.TabIndex = 42
        '
        'ODBCResult
        '
        Me.ODBCResult.Location = New System.Drawing.Point(4, 312)
        Me.ODBCResult.Multiline = True
        Me.ODBCResult.Name = "ODBCResult"
        Me.ODBCResult.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.ODBCResult.Size = New System.Drawing.Size(612, 198)
        Me.ODBCResult.TabIndex = 32
        Me.ODBCResult.WordWrap = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(1, 184)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(96, 13)
        Me.Label13.TabIndex = 41
        Me.Label13.Text = "SQLCommandText"
        '
        'ODBCDSNName
        '
        Me.ODBCDSNName.Location = New System.Drawing.Point(4, 52)
        Me.ODBCDSNName.Multiline = True
        Me.ODBCDSNName.Name = "ODBCDSNName"
        Me.ODBCDSNName.Size = New System.Drawing.Size(611, 20)
        Me.ODBCDSNName.TabIndex = 34
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(1, 75)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(57, 13)
        Me.Label15.TabIndex = 35
        Me.Label15.Text = "UserName"
        '
        'ODBCPassword
        '
        Me.ODBCPassword.Location = New System.Drawing.Point(226, 88)
        Me.ODBCPassword.Name = "ODBCPassword"
        Me.ODBCPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.ODBCPassword.Size = New System.Drawing.Size(220, 20)
        Me.ODBCPassword.TabIndex = 38
        '
        'ODBCUserName
        '
        Me.ODBCUserName.Location = New System.Drawing.Point(4, 88)
        Me.ODBCUserName.Name = "ODBCUserName"
        Me.ODBCUserName.Size = New System.Drawing.Size(220, 20)
        Me.ODBCUserName.TabIndex = 36
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(223, 75)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(53, 13)
        Me.Label16.TabIndex = 37
        Me.Label16.Text = "Password"
        '
        'TabORACLE
        '
        Me.TabORACLE.BackColor = System.Drawing.SystemColors.Menu
        Me.TabORACLE.Controls.Add(Me.btnOracle_Schema)
        Me.TabORACLE.Controls.Add(Me.btnOracleSQLCreateTable)
        Me.TabORACLE.Controls.Add(Me.chkORACLEDEDICATEDSERVER)
        Me.TabORACLE.Controls.Add(Me.Label42)
        Me.TabORACLE.Controls.Add(Me.OraclePort)
        Me.TabORACLE.Controls.Add(Me.Label41)
        Me.TabORACLE.Controls.Add(Me.OracleServiceName)
        Me.TabORACLE.Controls.Add(Me.Label36)
        Me.TabORACLE.Controls.Add(Me.OracleDBObjectType)
        Me.TabORACLE.Controls.Add(Me.OracleIntegratedAuth)
        Me.TabORACLE.Controls.Add(Me.OracleShowConnectionString)
        Me.TabORACLE.Controls.Add(Me.Label29)
        Me.TabORACLE.Controls.Add(Me.Label30)
        Me.TabORACLE.Controls.Add(Me.OracleObjectName)
        Me.TabORACLE.Controls.Add(Me.OracleBuild)
        Me.TabORACLE.Controls.Add(Me.Label31)
        Me.TabORACLE.Controls.Add(Me.OracleCommandText)
        Me.TabORACLE.Controls.Add(Me.OracleResult)
        Me.TabORACLE.Controls.Add(Me.Label32)
        Me.TabORACLE.Controls.Add(Me.OracleServerName)
        Me.TabORACLE.Controls.Add(Me.Label33)
        Me.TabORACLE.Controls.Add(Me.OraclePassword)
        Me.TabORACLE.Controls.Add(Me.OracleUsername)
        Me.TabORACLE.Controls.Add(Me.Label34)
        Me.TabORACLE.Controls.Add(Me.chkORACLEUSESID)
        Me.TabORACLE.Location = New System.Drawing.Point(4, 22)
        Me.TabORACLE.Name = "TabORACLE"
        Me.TabORACLE.Size = New System.Drawing.Size(624, 556)
        Me.TabORACLE.TabIndex = 3
        Me.TabORACLE.Text = "Oracle"
        '
        'btnOracle_Schema
        '
        Me.btnOracle_Schema.Location = New System.Drawing.Point(593, 165)
        Me.btnOracle_Schema.Name = "btnOracle_Schema"
        Me.btnOracle_Schema.Size = New System.Drawing.Size(25, 23)
        Me.btnOracle_Schema.TabIndex = 75
        Me.btnOracle_Schema.Text = "..."
        Me.btnOracle_Schema.UseVisualStyleBackColor = True
        '
        'btnOracleSQLCreateTable
        '
        Me.btnOracleSQLCreateTable.Location = New System.Drawing.Point(4, 524)
        Me.btnOracleSQLCreateTable.Name = "btnOracleSQLCreateTable"
        Me.btnOracleSQLCreateTable.Size = New System.Drawing.Size(176, 25)
        Me.btnOracleSQLCreateTable.TabIndex = 74
        Me.btnOracleSQLCreateTable.Text = "SQL Create Table Statement"
        Me.btnOracleSQLCreateTable.UseVisualStyleBackColor = True
        '
        'chkORACLEDEDICATEDSERVER
        '
        Me.chkORACLEDEDICATEDSERVER.AutoSize = True
        Me.chkORACLEDEDICATEDSERVER.Location = New System.Drawing.Point(7, 114)
        Me.chkORACLEDEDICATEDSERVER.Name = "chkORACLEDEDICATEDSERVER"
        Me.chkORACLEDEDICATEDSERVER.Size = New System.Drawing.Size(144, 17)
        Me.chkORACLEDEDICATEDSERVER.TabIndex = 73
        Me.chkORACLEDEDICATEDSERVER.Text = "SERVER = DEDICATED"
        Me.chkORACLEDEDICATEDSERVER.UseVisualStyleBackColor = True
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(271, 75)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(60, 13)
        Me.Label42.TabIndex = 70
        Me.Label42.Text = "Oracle Port"
        '
        'OraclePort
        '
        Me.OraclePort.Location = New System.Drawing.Point(274, 89)
        Me.OraclePort.Multiline = True
        Me.OraclePort.Name = "OraclePort"
        Me.OraclePort.Size = New System.Drawing.Size(66, 20)
        Me.OraclePort.TabIndex = 71
        Me.OraclePort.Text = "1521"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(341, 75)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(137, 13)
        Me.Label41.TabIndex = 68
        Me.Label41.Text = "Oracle Service Name / SID"
        '
        'OracleServiceName
        '
        Me.OracleServiceName.Location = New System.Drawing.Point(344, 89)
        Me.OracleServiceName.Multiline = True
        Me.OracleServiceName.Name = "OracleServiceName"
        Me.OracleServiceName.Size = New System.Drawing.Size(274, 20)
        Me.OracleServiceName.TabIndex = 69
        Me.OracleServiceName.Text = "TESTDB"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(329, 152)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(83, 13)
        Me.Label36.TabIndex = 67
        Me.Label36.Text = "DB Object Type"
        '
        'OracleDBObjectType
        '
        Me.OracleDBObjectType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OracleDBObjectType.FormattingEnabled = True
        Me.OracleDBObjectType.Items.AddRange(New Object() {"0 - Table", "1 - View", "2 - SQL Statement", "3 - Stored Procedure", "4 - Table Function", "5 - Scalar Function"})
        Me.OracleDBObjectType.Location = New System.Drawing.Point(328, 166)
        Me.OracleDBObjectType.Name = "OracleDBObjectType"
        Me.OracleDBObjectType.Size = New System.Drawing.Size(263, 21)
        Me.OracleDBObjectType.TabIndex = 66
        '
        'OracleIntegratedAuth
        '
        Me.OracleIntegratedAuth.AutoSize = True
        Me.OracleIntegratedAuth.Location = New System.Drawing.Point(7, 131)
        Me.OracleIntegratedAuth.Name = "OracleIntegratedAuth"
        Me.OracleIntegratedAuth.Size = New System.Drawing.Size(145, 17)
        Me.OracleIntegratedAuth.TabIndex = 65
        Me.OracleIntegratedAuth.Text = "Integrated Authentication"
        Me.OracleIntegratedAuth.UseVisualStyleBackColor = True
        '
        'OracleShowConnectionString
        '
        Me.OracleShowConnectionString.Location = New System.Drawing.Point(352, 524)
        Me.OracleShowConnectionString.Name = "OracleShowConnectionString"
        Me.OracleShowConnectionString.Size = New System.Drawing.Size(149, 25)
        Me.OracleShowConnectionString.TabIndex = 63
        Me.OracleShowConnectionString.Text = "Show Connection String"
        Me.OracleShowConnectionString.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(5, 322)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(66, 13)
        Me.Label29.TabIndex = 62
        Me.Label29.Text = "Object Code"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(2, 152)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(69, 13)
        Me.Label30.TabIndex = 60
        Me.Label30.Text = "Object Name"
        '
        'OracleObjectName
        '
        Me.OracleObjectName.Location = New System.Drawing.Point(6, 166)
        Me.OracleObjectName.Name = "OracleObjectName"
        Me.OracleObjectName.Size = New System.Drawing.Size(317, 20)
        Me.OracleObjectName.TabIndex = 61
        '
        'OracleBuild
        '
        Me.OracleBuild.Location = New System.Drawing.Point(507, 524)
        Me.OracleBuild.Name = "OracleBuild"
        Me.OracleBuild.Size = New System.Drawing.Size(110, 25)
        Me.OracleBuild.TabIndex = 59
        Me.OracleBuild.Text = "Build"
        Me.OracleBuild.UseVisualStyleBackColor = True
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(3, 75)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(103, 13)
        Me.Label31.TabIndex = 50
        Me.Label31.Text = "Oracle Server Name"
        '
        'OracleCommandText
        '
        Me.OracleCommandText.Location = New System.Drawing.Point(6, 203)
        Me.OracleCommandText.Multiline = True
        Me.OracleCommandText.Name = "OracleCommandText"
        Me.OracleCommandText.Size = New System.Drawing.Size(612, 116)
        Me.OracleCommandText.TabIndex = 58
        '
        'OracleResult
        '
        Me.OracleResult.Location = New System.Drawing.Point(6, 336)
        Me.OracleResult.Multiline = True
        Me.OracleResult.Name = "OracleResult"
        Me.OracleResult.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.OracleResult.Size = New System.Drawing.Size(612, 177)
        Me.OracleResult.TabIndex = 49
        Me.OracleResult.WordWrap = False
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(3, 189)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(96, 13)
        Me.Label32.TabIndex = 57
        Me.Label32.Text = "SQLCommandText"
        '
        'OracleServerName
        '
        Me.OracleServerName.Location = New System.Drawing.Point(6, 89)
        Me.OracleServerName.Multiline = True
        Me.OracleServerName.Name = "OracleServerName"
        Me.OracleServerName.Size = New System.Drawing.Size(264, 20)
        Me.OracleServerName.TabIndex = 51
        Me.OracleServerName.Text = "VM2019ORACLE"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(166, 115)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(57, 13)
        Me.Label33.TabIndex = 52
        Me.Label33.Text = "UserName"
        '
        'OraclePassword
        '
        Me.OraclePassword.Location = New System.Drawing.Point(395, 129)
        Me.OraclePassword.Name = "OraclePassword"
        Me.OraclePassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.OraclePassword.Size = New System.Drawing.Size(223, 20)
        Me.OraclePassword.TabIndex = 55
        Me.OraclePassword.Text = "orcl"
        '
        'OracleUsername
        '
        Me.OracleUsername.Location = New System.Drawing.Point(169, 129)
        Me.OracleUsername.Name = "OracleUsername"
        Me.OracleUsername.Size = New System.Drawing.Size(222, 20)
        Me.OracleUsername.TabIndex = 53
        Me.OracleUsername.Text = "sa"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(392, 115)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(53, 13)
        Me.Label34.TabIndex = 54
        Me.Label34.Text = "Password"
        '
        'chkORACLEUSESID
        '
        Me.chkORACLEUSESID.AutoSize = True
        Me.chkORACLEUSESID.Location = New System.Drawing.Point(485, 74)
        Me.chkORACLEUSESID.Name = "chkORACLEUSESID"
        Me.chkORACLEUSESID.Size = New System.Drawing.Size(66, 17)
        Me.chkORACLEUSESID.TabIndex = 72
        Me.chkORACLEUSESID.Text = "Use SID"
        Me.chkORACLEUSESID.UseVisualStyleBackColor = True
        '
        'TabMySQL
        '
        Me.TabMySQL.BackColor = System.Drawing.SystemColors.Menu
        Me.TabMySQL.Controls.Add(Me.Label79)
        Me.TabMySQL.Controls.Add(Me.cmb_MySQLParameterStyle)
        Me.TabMySQL.Controls.Add(Me.Label80)
        Me.TabMySQL.Controls.Add(Me.txt_MySQLSchemaSeparator)
        Me.TabMySQL.Controls.Add(Me.Label81)
        Me.TabMySQL.Controls.Add(Me.txt_MySQLParameterPrefix)
        Me.TabMySQL.Controls.Add(Me.Label66)
        Me.TabMySQL.Controls.Add(Me.txt_MySQLConnectionString)
        Me.TabMySQL.Controls.Add(Me.btn_MySQLSchema)
        Me.TabMySQL.Controls.Add(Me.btn_MySQLCreateTableSQL)
        Me.TabMySQL.Controls.Add(Me.Label5)
        Me.TabMySQL.Controls.Add(Me.txt_MySQLPort)
        Me.TabMySQL.Controls.Add(Me.Label10)
        Me.TabMySQL.Controls.Add(Me.txt_MySQLDataBaseName)
        Me.TabMySQL.Controls.Add(Me.Label14)
        Me.TabMySQL.Controls.Add(Me.MySQLDBObjectType)
        Me.TabMySQL.Controls.Add(Me.btn_MySQLConnectionString)
        Me.TabMySQL.Controls.Add(Me.Label17)
        Me.TabMySQL.Controls.Add(Me.Label18)
        Me.TabMySQL.Controls.Add(Me.txt_MySQLObjectName)
        Me.TabMySQL.Controls.Add(Me.btm_MySQLBuild)
        Me.TabMySQL.Controls.Add(Me.Label20)
        Me.TabMySQL.Controls.Add(Me.txt_MySQLCommandText)
        Me.TabMySQL.Controls.Add(Me.txt_MySQLObjectCode)
        Me.TabMySQL.Controls.Add(Me.Label21)
        Me.TabMySQL.Controls.Add(Me.txt_MySQLServerName)
        Me.TabMySQL.Controls.Add(Me.Label23)
        Me.TabMySQL.Controls.Add(Me.txt_MySQLPassword)
        Me.TabMySQL.Controls.Add(Me.txt_MySQLUserName)
        Me.TabMySQL.Controls.Add(Me.Label24)
        Me.TabMySQL.Location = New System.Drawing.Point(4, 22)
        Me.TabMySQL.Name = "TabMySQL"
        Me.TabMySQL.Padding = New System.Windows.Forms.Padding(3)
        Me.TabMySQL.Size = New System.Drawing.Size(624, 556)
        Me.TabMySQL.TabIndex = 7
        Me.TabMySQL.Text = "MySQL"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(92, 154)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(81, 13)
        Me.Label79.TabIndex = 108
        Me.Label79.Text = "Parameter Style"
        '
        'cmb_MySQLParameterStyle
        '
        Me.cmb_MySQLParameterStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_MySQLParameterStyle.FormattingEnabled = True
        Me.cmb_MySQLParameterStyle.Items.AddRange(New Object() {"0 - Simple", "1 - Qualified"})
        Me.cmb_MySQLParameterStyle.Location = New System.Drawing.Point(94, 168)
        Me.cmb_MySQLParameterStyle.Name = "cmb_MySQLParameterStyle"
        Me.cmb_MySQLParameterStyle.Size = New System.Drawing.Size(111, 21)
        Me.cmb_MySQLParameterStyle.TabIndex = 107
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(205, 154)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(71, 13)
        Me.Label80.TabIndex = 105
        Me.Label80.Text = "Schema Sep."
        '
        'txt_MySQLSchemaSeparator
        '
        Me.txt_MySQLSchemaSeparator.Location = New System.Drawing.Point(208, 168)
        Me.txt_MySQLSchemaSeparator.Name = "txt_MySQLSchemaSeparator"
        Me.txt_MySQLSchemaSeparator.Size = New System.Drawing.Size(68, 20)
        Me.txt_MySQLSchemaSeparator.TabIndex = 106
        Me.txt_MySQLSchemaSeparator.Text = "."
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(7, 154)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(84, 13)
        Me.Label81.TabIndex = 103
        Me.Label81.Text = "Parameter Prefix"
        '
        'txt_MySQLParameterPrefix
        '
        Me.txt_MySQLParameterPrefix.Location = New System.Drawing.Point(10, 168)
        Me.txt_MySQLParameterPrefix.Name = "txt_MySQLParameterPrefix"
        Me.txt_MySQLParameterPrefix.Size = New System.Drawing.Size(81, 20)
        Me.txt_MySQLParameterPrefix.TabIndex = 104
        Me.txt_MySQLParameterPrefix.Text = "@"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(6, 4)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(91, 13)
        Me.Label66.TabIndex = 101
        Me.Label66.Text = "Connection String"
        '
        'txt_MySQLConnectionString
        '
        Me.txt_MySQLConnectionString.Location = New System.Drawing.Point(9, 18)
        Me.txt_MySQLConnectionString.Multiline = True
        Me.txt_MySQLConnectionString.Name = "txt_MySQLConnectionString"
        Me.txt_MySQLConnectionString.Size = New System.Drawing.Size(611, 47)
        Me.txt_MySQLConnectionString.TabIndex = 102
        Me.txt_MySQLConnectionString.Text = "server=@SERVERNAME@;  database=@DATABASE@; port=@PORT@; user id=@USERNAME@; passw" &
    "ord=@PASSWORD@;"
        '
        'btn_MySQLSchema
        '
        Me.btn_MySQLSchema.Location = New System.Drawing.Point(594, 204)
        Me.btn_MySQLSchema.Name = "btn_MySQLSchema"
        Me.btn_MySQLSchema.Size = New System.Drawing.Size(25, 23)
        Me.btn_MySQLSchema.TabIndex = 100
        Me.btn_MySQLSchema.Text = "..."
        Me.btn_MySQLSchema.UseVisualStyleBackColor = True
        '
        'btn_MySQLCreateTableSQL
        '
        Me.btn_MySQLCreateTableSQL.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_MySQLCreateTableSQL.Location = New System.Drawing.Point(5, 517)
        Me.btn_MySQLCreateTableSQL.Name = "btn_MySQLCreateTableSQL"
        Me.btn_MySQLCreateTableSQL.Size = New System.Drawing.Size(176, 33)
        Me.btn_MySQLCreateTableSQL.TabIndex = 99
        Me.btn_MySQLCreateTableSQL.Text = "SQL Create Table Statement"
        Me.btn_MySQLCreateTableSQL.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(236, 73)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(87, 13)
        Me.Label5.TabIndex = 95
        Me.Label5.Text = "Port (@PORT@)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'txt_MySQLPort
        '
        Me.txt_MySQLPort.Location = New System.Drawing.Point(236, 89)
        Me.txt_MySQLPort.Multiline = True
        Me.txt_MySQLPort.Name = "txt_MySQLPort"
        Me.txt_MySQLPort.Size = New System.Drawing.Size(87, 20)
        Me.txt_MySQLPort.TabIndex = 96
        Me.txt_MySQLPort.Text = "3306"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(328, 73)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(173, 13)
        Me.Label10.TabIndex = 93
        Me.Label10.Text = "DataBase Name (@DATABASE@)"
        '
        'txt_MySQLDataBaseName
        '
        Me.txt_MySQLDataBaseName.Location = New System.Drawing.Point(329, 89)
        Me.txt_MySQLDataBaseName.Multiline = True
        Me.txt_MySQLDataBaseName.Name = "txt_MySQLDataBaseName"
        Me.txt_MySQLDataBaseName.Size = New System.Drawing.Size(274, 20)
        Me.txt_MySQLDataBaseName.TabIndex = 94
        Me.txt_MySQLDataBaseName.Text = "TESTDB"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(332, 191)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(83, 13)
        Me.Label14.TabIndex = 92
        Me.Label14.Text = "DB Object Type"
        '
        'MySQLDBObjectType
        '
        Me.MySQLDBObjectType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.MySQLDBObjectType.FormattingEnabled = True
        Me.MySQLDBObjectType.Items.AddRange(New Object() {"0 - Table", "1 - View", "2 - SQL Statement", "3 - Stored Procedure", "4 - Table Function", "5 - Scalar Function"})
        Me.MySQLDBObjectType.Location = New System.Drawing.Point(331, 205)
        Me.MySQLDBObjectType.Name = "MySQLDBObjectType"
        Me.MySQLDBObjectType.Size = New System.Drawing.Size(263, 21)
        Me.MySQLDBObjectType.TabIndex = 91
        '
        'btn_MySQLConnectionString
        '
        Me.btn_MySQLConnectionString.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_MySQLConnectionString.Location = New System.Drawing.Point(353, 517)
        Me.btn_MySQLConnectionString.Name = "btn_MySQLConnectionString"
        Me.btn_MySQLConnectionString.Size = New System.Drawing.Size(149, 33)
        Me.btn_MySQLConnectionString.TabIndex = 89
        Me.btn_MySQLConnectionString.Text = "Show Connection String"
        Me.btn_MySQLConnectionString.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(7, 368)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(66, 13)
        Me.Label17.TabIndex = 88
        Me.Label17.Text = "Object Code"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(5, 191)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(69, 13)
        Me.Label18.TabIndex = 86
        Me.Label18.Text = "Object Name"
        '
        'txt_MySQLObjectName
        '
        Me.txt_MySQLObjectName.Location = New System.Drawing.Point(9, 205)
        Me.txt_MySQLObjectName.Name = "txt_MySQLObjectName"
        Me.txt_MySQLObjectName.Size = New System.Drawing.Size(317, 20)
        Me.txt_MySQLObjectName.TabIndex = 87
        '
        'btm_MySQLBuild
        '
        Me.btm_MySQLBuild.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btm_MySQLBuild.Location = New System.Drawing.Point(508, 517)
        Me.btm_MySQLBuild.Name = "btm_MySQLBuild"
        Me.btm_MySQLBuild.Size = New System.Drawing.Size(110, 33)
        Me.btm_MySQLBuild.TabIndex = 85
        Me.btm_MySQLBuild.Text = "Build"
        Me.btm_MySQLBuild.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(6, 73)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(175, 13)
        Me.Label20.TabIndex = 77
        Me.Label20.Text = "Server Name (@SERVERNAME@)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'txt_MySQLCommandText
        '
        Me.txt_MySQLCommandText.Location = New System.Drawing.Point(9, 248)
        Me.txt_MySQLCommandText.Multiline = True
        Me.txt_MySQLCommandText.Name = "txt_MySQLCommandText"
        Me.txt_MySQLCommandText.Size = New System.Drawing.Size(612, 117)
        Me.txt_MySQLCommandText.TabIndex = 84
        '
        'txt_MySQLObjectCode
        '
        Me.txt_MySQLObjectCode.Location = New System.Drawing.Point(9, 383)
        Me.txt_MySQLObjectCode.Multiline = True
        Me.txt_MySQLObjectCode.Name = "txt_MySQLObjectCode"
        Me.txt_MySQLObjectCode.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txt_MySQLObjectCode.Size = New System.Drawing.Size(612, 129)
        Me.txt_MySQLObjectCode.TabIndex = 76
        Me.txt_MySQLObjectCode.WordWrap = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(6, 233)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(96, 13)
        Me.Label21.TabIndex = 83
        Me.Label21.Text = "SQLCommandText"
        '
        'txt_MySQLServerName
        '
        Me.txt_MySQLServerName.Location = New System.Drawing.Point(9, 89)
        Me.txt_MySQLServerName.Multiline = True
        Me.txt_MySQLServerName.Name = "txt_MySQLServerName"
        Me.txt_MySQLServerName.Size = New System.Drawing.Size(221, 20)
        Me.txt_MySQLServerName.TabIndex = 78
        Me.txt_MySQLServerName.Text = "WEBSERVERAPP"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(7, 114)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(149, 13)
        Me.Label23.TabIndex = 79
        Me.Label23.Text = "UserName (@USERNAME@)"
        '
        'txt_MySQLPassword
        '
        Me.txt_MySQLPassword.Location = New System.Drawing.Point(236, 130)
        Me.txt_MySQLPassword.Name = "txt_MySQLPassword"
        Me.txt_MySQLPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt_MySQLPassword.Size = New System.Drawing.Size(223, 20)
        Me.txt_MySQLPassword.TabIndex = 82
        Me.txt_MySQLPassword.Text = "MySQL1qaz@2wsx"
        '
        'txt_MySQLUserName
        '
        Me.txt_MySQLUserName.Location = New System.Drawing.Point(10, 130)
        Me.txt_MySQLUserName.Name = "txt_MySQLUserName"
        Me.txt_MySQLUserName.Size = New System.Drawing.Size(220, 20)
        Me.txt_MySQLUserName.TabIndex = 80
        Me.txt_MySQLUserName.Text = "ADMIN"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(233, 114)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(147, 13)
        Me.Label24.TabIndex = 81
        Me.Label24.Text = "Password (@PASSWORD@)"
        '
        'TabDB2ISERIES
        '
        Me.TabDB2ISERIES.BackColor = System.Drawing.SystemColors.Menu
        Me.TabDB2ISERIES.Controls.Add(Me.Label67)
        Me.TabDB2ISERIES.Controls.Add(Me.cmb_DB2iSeries_ParameterStyle)
        Me.TabDB2ISERIES.Controls.Add(Me.Label68)
        Me.TabDB2ISERIES.Controls.Add(Me.txt_DB2iSeries_SchemaSeparator)
        Me.TabDB2ISERIES.Controls.Add(Me.Label69)
        Me.TabDB2ISERIES.Controls.Add(Me.txt_DB2iSeries_ParameterPrefix)
        Me.TabDB2ISERIES.Controls.Add(Me.Label35)
        Me.TabDB2ISERIES.Controls.Add(Me.txt_DB2ISeries_ConnectionString)
        Me.TabDB2ISERIES.Controls.Add(Me.btn_IBMISERIESSchema)
        Me.TabDB2ISERIES.Controls.Add(Me.bnt_CreateTable)
        Me.TabDB2ISERIES.Controls.Add(Me.Label38)
        Me.TabDB2ISERIES.Controls.Add(Me.txt_DB2ISeries_LibraryList)
        Me.TabDB2ISERIES.Controls.Add(Me.Label48)
        Me.TabDB2ISERIES.Controls.Add(Me.cmd_DB2ISeries_DbObjectType)
        Me.TabDB2ISERIES.Controls.Add(Me.bnt_DB2ISeries_ShowConnectionString)
        Me.TabDB2ISERIES.Controls.Add(Me.Label51)
        Me.TabDB2ISERIES.Controls.Add(Me.Label54)
        Me.TabDB2ISERIES.Controls.Add(Me.txt_DB2ISeries_ObjecName)
        Me.TabDB2ISERIES.Controls.Add(Me.btn_DB2ISeries_Build)
        Me.TabDB2ISERIES.Controls.Add(Me.Label55)
        Me.TabDB2ISERIES.Controls.Add(Me.txt_DB2ISeries_CommandText)
        Me.TabDB2ISERIES.Controls.Add(Me.txt_DB2ISeries_ObjectCode)
        Me.TabDB2ISERIES.Controls.Add(Me.Label56)
        Me.TabDB2ISERIES.Controls.Add(Me.txt_DB2ISeries_ServerName)
        Me.TabDB2ISERIES.Controls.Add(Me.Label57)
        Me.TabDB2ISERIES.Controls.Add(Me.txt_DB2ISeries_Password)
        Me.TabDB2ISERIES.Controls.Add(Me.txt_DB2ISeries_UserName)
        Me.TabDB2ISERIES.Controls.Add(Me.Label58)
        Me.TabDB2ISERIES.Location = New System.Drawing.Point(4, 22)
        Me.TabDB2ISERIES.Name = "TabDB2ISERIES"
        Me.TabDB2ISERIES.Size = New System.Drawing.Size(624, 556)
        Me.TabDB2ISERIES.TabIndex = 8
        Me.TabDB2ISERIES.Text = "DB2 iSeries"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(87, 143)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(81, 13)
        Me.Label67.TabIndex = 133
        Me.Label67.Text = "Parameter Style"
        '
        'cmb_DB2iSeries_ParameterStyle
        '
        Me.cmb_DB2iSeries_ParameterStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_DB2iSeries_ParameterStyle.FormattingEnabled = True
        Me.cmb_DB2iSeries_ParameterStyle.Items.AddRange(New Object() {"0 - Simple", "1 - Qualified"})
        Me.cmb_DB2iSeries_ParameterStyle.Location = New System.Drawing.Point(89, 157)
        Me.cmb_DB2iSeries_ParameterStyle.Name = "cmb_DB2iSeries_ParameterStyle"
        Me.cmb_DB2iSeries_ParameterStyle.Size = New System.Drawing.Size(111, 21)
        Me.cmb_DB2iSeries_ParameterStyle.TabIndex = 132
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(200, 143)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(71, 13)
        Me.Label68.TabIndex = 130
        Me.Label68.Text = "Schema Sep."
        '
        'txt_DB2iSeries_SchemaSeparator
        '
        Me.txt_DB2iSeries_SchemaSeparator.Location = New System.Drawing.Point(203, 157)
        Me.txt_DB2iSeries_SchemaSeparator.Name = "txt_DB2iSeries_SchemaSeparator"
        Me.txt_DB2iSeries_SchemaSeparator.Size = New System.Drawing.Size(68, 20)
        Me.txt_DB2iSeries_SchemaSeparator.TabIndex = 131
        Me.txt_DB2iSeries_SchemaSeparator.Text = "."
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(2, 143)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(84, 13)
        Me.Label69.TabIndex = 128
        Me.Label69.Text = "Parameter Prefix"
        '
        'txt_DB2iSeries_ParameterPrefix
        '
        Me.txt_DB2iSeries_ParameterPrefix.Location = New System.Drawing.Point(5, 157)
        Me.txt_DB2iSeries_ParameterPrefix.Name = "txt_DB2iSeries_ParameterPrefix"
        Me.txt_DB2iSeries_ParameterPrefix.Size = New System.Drawing.Size(81, 20)
        Me.txt_DB2iSeries_ParameterPrefix.TabIndex = 129
        Me.txt_DB2iSeries_ParameterPrefix.Text = "@"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(2, 4)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(91, 13)
        Me.Label35.TabIndex = 127
        Me.Label35.Text = "Connection String"
        '
        'txt_DB2ISeries_ConnectionString
        '
        Me.txt_DB2ISeries_ConnectionString.AcceptsReturn = True
        Me.txt_DB2ISeries_ConnectionString.Location = New System.Drawing.Point(5, 17)
        Me.txt_DB2ISeries_ConnectionString.Multiline = True
        Me.txt_DB2ISeries_ConnectionString.Name = "txt_DB2ISeries_ConnectionString"
        Me.txt_DB2ISeries_ConnectionString.Size = New System.Drawing.Size(611, 51)
        Me.txt_DB2ISeries_ConnectionString.TabIndex = 126
        Me.txt_DB2ISeries_ConnectionString.Text = "DataSource=@SERVERNAME@; Naming=System; librarylist=@DB2ISERIESLIBRARYLIST@; User" &
    "ID=@USERNAME@; Password=@PASSWORD@;" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'btn_IBMISERIESSchema
        '
        Me.btn_IBMISERIESSchema.Location = New System.Drawing.Point(590, 197)
        Me.btn_IBMISERIESSchema.Name = "btn_IBMISERIESSchema"
        Me.btn_IBMISERIESSchema.Size = New System.Drawing.Size(25, 23)
        Me.btn_IBMISERIESSchema.TabIndex = 125
        Me.btn_IBMISERIESSchema.Text = "..."
        Me.btn_IBMISERIESSchema.UseVisualStyleBackColor = True
        '
        'bnt_CreateTable
        '
        Me.bnt_CreateTable.Location = New System.Drawing.Point(4, 526)
        Me.bnt_CreateTable.Name = "bnt_CreateTable"
        Me.bnt_CreateTable.Size = New System.Drawing.Size(176, 25)
        Me.bnt_CreateTable.TabIndex = 124
        Me.bnt_CreateTable.Text = "SQL Create Table Statement"
        Me.bnt_CreateTable.UseVisualStyleBackColor = True
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(270, 71)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(220, 13)
        Me.Label38.TabIndex = 118
        Me.Label38.Text = "Library List (@DB2ISERIESLIBRARYLIST@)"
        '
        'txt_DB2ISeries_LibraryList
        '
        Me.txt_DB2ISeries_LibraryList.Location = New System.Drawing.Point(273, 84)
        Me.txt_DB2ISeries_LibraryList.Multiline = True
        Me.txt_DB2ISeries_LibraryList.Name = "txt_DB2ISeries_LibraryList"
        Me.txt_DB2ISeries_LibraryList.Size = New System.Drawing.Size(344, 20)
        Me.txt_DB2ISeries_LibraryList.TabIndex = 119
        Me.txt_DB2ISeries_LibraryList.Text = "GDELGIO1"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(324, 184)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(83, 13)
        Me.Label48.TabIndex = 117
        Me.Label48.Text = "DB Object Type"
        '
        'cmd_DB2ISeries_DbObjectType
        '
        Me.cmd_DB2ISeries_DbObjectType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmd_DB2ISeries_DbObjectType.FormattingEnabled = True
        Me.cmd_DB2ISeries_DbObjectType.Items.AddRange(New Object() {"0 - Table", "1 - View", "2 - SQL Statement", "3 - Stored Procedure", "4 - Table Function", "5 - Scalar Function"})
        Me.cmd_DB2ISeries_DbObjectType.Location = New System.Drawing.Point(327, 198)
        Me.cmd_DB2ISeries_DbObjectType.Name = "cmd_DB2ISeries_DbObjectType"
        Me.cmd_DB2ISeries_DbObjectType.Size = New System.Drawing.Size(263, 21)
        Me.cmd_DB2ISeries_DbObjectType.TabIndex = 116
        '
        'bnt_DB2ISeries_ShowConnectionString
        '
        Me.bnt_DB2ISeries_ShowConnectionString.Location = New System.Drawing.Point(353, 526)
        Me.bnt_DB2ISeries_ShowConnectionString.Name = "bnt_DB2ISeries_ShowConnectionString"
        Me.bnt_DB2ISeries_ShowConnectionString.Size = New System.Drawing.Size(149, 25)
        Me.bnt_DB2ISeries_ShowConnectionString.TabIndex = 114
        Me.bnt_DB2ISeries_ShowConnectionString.Text = "Show Connection String"
        Me.bnt_DB2ISeries_ShowConnectionString.UseVisualStyleBackColor = True
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(3, 342)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(66, 13)
        Me.Label51.TabIndex = 113
        Me.Label51.Text = "Object Code"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(3, 184)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(69, 13)
        Me.Label54.TabIndex = 111
        Me.Label54.Text = "Object Name"
        '
        'txt_DB2ISeries_ObjecName
        '
        Me.txt_DB2ISeries_ObjecName.Location = New System.Drawing.Point(5, 198)
        Me.txt_DB2ISeries_ObjecName.Name = "txt_DB2ISeries_ObjecName"
        Me.txt_DB2ISeries_ObjecName.Size = New System.Drawing.Size(317, 20)
        Me.txt_DB2ISeries_ObjecName.TabIndex = 112
        '
        'btn_DB2ISeries_Build
        '
        Me.btn_DB2ISeries_Build.Location = New System.Drawing.Point(508, 526)
        Me.btn_DB2ISeries_Build.Name = "btn_DB2ISeries_Build"
        Me.btn_DB2ISeries_Build.Size = New System.Drawing.Size(110, 25)
        Me.btn_DB2ISeries_Build.TabIndex = 110
        Me.btn_DB2ISeries_Build.Text = "Build"
        Me.btn_DB2ISeries_Build.UseVisualStyleBackColor = True
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(3, 71)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(175, 13)
        Me.Label55.TabIndex = 102
        Me.Label55.Text = "Server Name (@SERVERNAME@)"
        '
        'txt_DB2ISeries_CommandText
        '
        Me.txt_DB2ISeries_CommandText.Location = New System.Drawing.Point(5, 235)
        Me.txt_DB2ISeries_CommandText.Multiline = True
        Me.txt_DB2ISeries_CommandText.Name = "txt_DB2ISeries_CommandText"
        Me.txt_DB2ISeries_CommandText.Size = New System.Drawing.Size(612, 104)
        Me.txt_DB2ISeries_CommandText.TabIndex = 109
        '
        'txt_DB2ISeries_ObjectCode
        '
        Me.txt_DB2ISeries_ObjectCode.Location = New System.Drawing.Point(6, 358)
        Me.txt_DB2ISeries_ObjectCode.Multiline = True
        Me.txt_DB2ISeries_ObjectCode.Name = "txt_DB2ISeries_ObjectCode"
        Me.txt_DB2ISeries_ObjectCode.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txt_DB2ISeries_ObjectCode.Size = New System.Drawing.Size(612, 155)
        Me.txt_DB2ISeries_ObjectCode.TabIndex = 101
        Me.txt_DB2ISeries_ObjectCode.WordWrap = False
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(2, 221)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(96, 13)
        Me.Label56.TabIndex = 108
        Me.Label56.Text = "SQLCommandText"
        '
        'txt_DB2ISeries_ServerName
        '
        Me.txt_DB2ISeries_ServerName.Location = New System.Drawing.Point(6, 84)
        Me.txt_DB2ISeries_ServerName.Multiline = True
        Me.txt_DB2ISeries_ServerName.Name = "txt_DB2ISeries_ServerName"
        Me.txt_DB2ISeries_ServerName.Size = New System.Drawing.Size(264, 20)
        Me.txt_DB2ISeries_ServerName.TabIndex = 103
        Me.txt_DB2ISeries_ServerName.Text = "PUB400.COM"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(3, 107)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(149, 13)
        Me.Label57.TabIndex = 104
        Me.Label57.Text = "UserName (@USERNAME@)"
        '
        'txt_DB2ISeries_Password
        '
        Me.txt_DB2ISeries_Password.Location = New System.Drawing.Point(231, 120)
        Me.txt_DB2ISeries_Password.Name = "txt_DB2ISeries_Password"
        Me.txt_DB2ISeries_Password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt_DB2ISeries_Password.Size = New System.Drawing.Size(223, 20)
        Me.txt_DB2ISeries_Password.TabIndex = 107
        Me.txt_DB2ISeries_Password.Text = "GDG1qaz2wsx"
        '
        'txt_DB2ISeries_UserName
        '
        Me.txt_DB2ISeries_UserName.Location = New System.Drawing.Point(5, 120)
        Me.txt_DB2ISeries_UserName.Name = "txt_DB2ISeries_UserName"
        Me.txt_DB2ISeries_UserName.Size = New System.Drawing.Size(220, 20)
        Me.txt_DB2ISeries_UserName.TabIndex = 105
        Me.txt_DB2ISeries_UserName.Text = "GDELGIO"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(228, 107)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(147, 13)
        Me.Label58.TabIndex = 106
        Me.Label58.Text = "Password (@PASSWORD@)"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(5, 7)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(55, 13)
        Me.Label52.TabIndex = 76
        Me.Label52.Text = "Language"
        '
        'cmbLanguage
        '
        Me.cmbLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbLanguage.FormattingEnabled = True
        Me.cmbLanguage.Items.AddRange(New Object() {"C#", "VB.NET"})
        Me.cmbLanguage.Location = New System.Drawing.Point(8, 22)
        Me.cmbLanguage.Name = "cmbLanguage"
        Me.cmbLanguage.Size = New System.Drawing.Size(115, 21)
        Me.cmbLanguage.TabIndex = 75
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(127, 7)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(64, 13)
        Me.Label53.TabIndex = 74
        Me.Label53.Text = "Build Option"
        '
        'cmbBuildOption
        '
        Me.cmbBuildOption.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbBuildOption.FormattingEnabled = True
        Me.cmbBuildOption.Items.AddRange(New Object() {"0 - Public DbColumns Fields", "1 - Private DbColumns Fields", "2 - Public DbColumns Properties Get - Set on Private DbColumns Fields", "3 - Public Properties Get - Set with private DbColumns Fields", "4 - POCO Class"})
        Me.cmbBuildOption.Location = New System.Drawing.Point(129, 22)
        Me.cmbBuildOption.Name = "cmbBuildOption"
        Me.cmbBuildOption.Size = New System.Drawing.Size(505, 21)
        Me.cmbBuildOption.TabIndex = 73
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(633, 632)
        Me.Controls.Add(Me.Label52)
        Me.Controls.Add(Me.cmbLanguage)
        Me.Controls.Add(Me.Label53)
        Me.Controls.Add(Me.cmbBuildOption)
        Me.Controls.Add(Me.TabDBProvider)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.Text = "BasicDAL DBObject Class Builder"
        Me.TabDBProvider.ResumeLayout(False)
        Me.TabSQLServer.ResumeLayout(False)
        Me.TabSQLServer.PerformLayout()
        Me.TabOLEDB.ResumeLayout(False)
        Me.TabOLEDB.PerformLayout()
        Me.TabOLEDBDB2.ResumeLayout(False)
        Me.TabOLEDBDB2.PerformLayout()
        Me.TabODBC.ResumeLayout(False)
        Me.TabODBC.PerformLayout()
        Me.TabORACLE.ResumeLayout(False)
        Me.TabORACLE.PerformLayout()
        Me.TabMySQL.ResumeLayout(False)
        Me.TabMySQL.PerformLayout()
        Me.TabDB2ISERIES.ResumeLayout(False)
        Me.TabDB2ISERIES.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents SQLClientResult As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents SQLCLientServer As System.Windows.Forms.TextBox
    Friend WithEvents SQLClientDatabase As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents SQLClientUserName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents SQLClientPassword As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents SQLClientAuthenticationMode As System.Windows.Forms.CheckBox
    Friend WithEvents SQLCLientCommandText As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TabDBProvider As System.Windows.Forms.TabControl
    Friend WithEvents TabSQLServer As System.Windows.Forms.TabPage
    Friend WithEvents TabOLEDB As System.Windows.Forms.TabPage
    Friend WithEvents TabODBC As System.Windows.Forms.TabPage
    Friend WithEvents TabORACLE As System.Windows.Forms.TabPage
    Friend WithEvents OLEDBBuild As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents OLEDB_ObjectName As System.Windows.Forms.TextBox
    Friend WithEvents OLEDBResult As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents OLEDBConnectionString As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents OLEDBPassword As System.Windows.Forms.TextBox
    Friend WithEvents OLEDBUserName As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents ODBCBuild As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ODBCTableName As System.Windows.Forms.TextBox
    Friend WithEvents ODBCResult As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents ODBCDSNName As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents ODBCPassword As System.Windows.Forms.TextBox
    Friend WithEvents ODBCUserName As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents SQLClientObjectName As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents OLEDB_CommandText As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents ODBCObjectName As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents OracleShowConnectionString As System.Windows.Forms.Button
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents OracleObjectName As System.Windows.Forms.TextBox
    Friend WithEvents OracleBuild As System.Windows.Forms.Button
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents OracleCommandText As System.Windows.Forms.TextBox
    Friend WithEvents OracleResult As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents OracleServerName As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents OraclePassword As System.Windows.Forms.TextBox
    Friend WithEvents OracleUsername As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents OracleIntegratedAuth As System.Windows.Forms.CheckBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents SQLDBObjectType As System.Windows.Forms.ComboBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents OracleDBObjectType As System.Windows.Forms.ComboBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents OLEDBDBObjectType As System.Windows.Forms.ComboBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents ODBCDBObjectType As System.Windows.Forms.ComboBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents OracleServiceName As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents OraclePort As System.Windows.Forms.TextBox
    Friend WithEvents chkORACLEDEDICATEDSERVER As System.Windows.Forms.CheckBox
    Friend WithEvents chkORACLEUSESID As System.Windows.Forms.CheckBox
    Friend WithEvents TabOLEDBDB2 As System.Windows.Forms.TabPage
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents OLEDBDB2DbObjectType As System.Windows.Forms.ComboBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents OLEDBDB2_CommandText As System.Windows.Forms.TextBox
    Friend WithEvents OLEDBDB2Build As System.Windows.Forms.Button
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents OLEDBDB2_ObjectName As System.Windows.Forms.TextBox
    Friend WithEvents OLEDBDB2Result As System.Windows.Forms.TextBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents OLEDBDB2ConnectionString As System.Windows.Forms.TextBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents OLEDBDB2Password As System.Windows.Forms.TextBox
    Friend WithEvents OLEDBDB2UserName As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents btnOracleSQLCreateTable As System.Windows.Forms.Button
    Friend WithEvents Label52 As Label
    Friend WithEvents cmbLanguage As ComboBox
    Friend WithEvents Label53 As Label
    Friend WithEvents cmbBuildOption As ComboBox
    Friend WithEvents btnSQLServerSchema As Button
    Friend WithEvents btnOLEDB_Schema As Button
    Friend WithEvents btn_OLEDBDB2_Schema As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents btnOracle_Schema As Button
    Friend WithEvents TabMySQL As TabPage
    Friend WithEvents btn_MySQLSchema As Button
    Friend WithEvents btn_MySQLCreateTableSQL As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents txt_MySQLPort As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txt_MySQLDataBaseName As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents MySQLDBObjectType As ComboBox
    Friend WithEvents btn_MySQLConnectionString As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txt_MySQLObjectName As TextBox
    Friend WithEvents btm_MySQLBuild As Button
    Friend WithEvents Label20 As Label
    Friend WithEvents txt_MySQLCommandText As TextBox
    Friend WithEvents txt_MySQLObjectCode As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents txt_MySQLServerName As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents txt_MySQLPassword As TextBox
    Friend WithEvents txt_MySQLUserName As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents TabDB2ISERIES As TabPage
    Friend WithEvents btn_IBMISERIESSchema As Button
    Friend WithEvents bnt_CreateTable As Button
    Friend WithEvents Label38 As Label
    Friend WithEvents txt_DB2ISeries_LibraryList As TextBox
    Friend WithEvents Label48 As Label
    Friend WithEvents cmd_DB2ISeries_DbObjectType As ComboBox
    Friend WithEvents bnt_DB2ISeries_ShowConnectionString As Button
    Friend WithEvents Label51 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents txt_DB2ISeries_ObjecName As TextBox
    Friend WithEvents btn_DB2ISeries_Build As Button
    Friend WithEvents Label55 As Label
    Friend WithEvents txt_DB2ISeries_CommandText As TextBox
    Friend WithEvents txt_DB2ISeries_ObjectCode As TextBox
    Friend WithEvents Label56 As Label
    Friend WithEvents txt_DB2ISeries_ServerName As TextBox
    Friend WithEvents Label57 As Label
    Friend WithEvents txt_DB2ISeries_Password As TextBox
    Friend WithEvents txt_DB2ISeries_UserName As TextBox
    Friend WithEvents Label58 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents txt_DB2ISeries_ConnectionString As TextBox
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Label59 As Label
    Friend WithEvents OLEDBDB2InitialCatalog As TextBox
    Friend WithEvents OLEDBDB2ServerName As TextBox
    Friend WithEvents Label60 As Label
    Friend WithEvents OLEDBDB2LibraryList As TextBox
    Friend WithEvents Label61 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents SQLClientParameterStyle As ComboBox
    Friend WithEvents Label64 As Label
    Friend WithEvents SQLClientSchemaSeparator As TextBox
    Friend WithEvents Label63 As Label
    Friend WithEvents SQLClientParameterPrefix As TextBox
    Friend WithEvents Label62 As Label
    Friend WithEvents SQLClientConnectionString As TextBox
    Friend WithEvents Label66 As Label
    Friend WithEvents txt_MySQLConnectionString As TextBox
    Friend WithEvents Label67 As Label
    Friend WithEvents cmb_DB2iSeries_ParameterStyle As ComboBox
    Friend WithEvents Label68 As Label
    Friend WithEvents txt_DB2iSeries_SchemaSeparator As TextBox
    Friend WithEvents Label69 As Label
    Friend WithEvents txt_DB2iSeries_ParameterPrefix As TextBox
    Friend WithEvents Label70 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label71 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label72 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label73 As Label
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents Label74 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label75 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label76 As Label
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents Label77 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label78 As Label
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label79 As Label
    Friend WithEvents cmb_MySQLParameterStyle As ComboBox
    Friend WithEvents Label80 As Label
    Friend WithEvents txt_MySQLSchemaSeparator As TextBox
    Friend WithEvents Label81 As Label
    Friend WithEvents txt_MySQLParameterPrefix As TextBox
End Class
