Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports IBM.Data.DB2.iSeries
Imports System.Resources
Imports System.Text.RegularExpressions
Imports System.Data.Common

Public Class frmMain

    Structure sSQLParameter
        Public Name As String
        Public DbType As String
        Public Value As Object
        Public Direction As String
        Public Size As Integer
    End Structure
    Dim CurrentDbProvider As DbProviders = DbProviders.SQLSERVER
    Public ConnectionString As String = ""
    Const VBNET = "VB.NET"
    Const CS = "C#"
    Dim mDBObjecTypeSQL As String = "BasicDAL.DbObjectTypeEnum.SQLQuery"
    Dim mDBObjecTypeTABLE As String = "BasicDAL.DbObjectTypeEnum.Table"
    Dim mDBObjecTypeVIEW As String = "BasicDAL.DbObjectTypeEnum.View"
    Dim mDBObjecTypeStoredProcedure As String = "BasicDAL.DbObjectTypeEnum.StoredProcedure"
    Dim mDBObjecTypeTableFunction As String = "BasicDAL.DbObjectTypeEnum.TableFunction"
    Dim mDBObjecTypeScalarFunction As String = "BasicDAL.DbObjectTypeEnum.ScalarFunction"

    Dim Language As String = "C#"

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        SQLClientBuildClass()

    End Sub


    Sub SQLClientBuildClass()

        Dim ConnectionString As String = Utilities.GetSQLCLientConnectionString(Me.SQLClientConnectionString.Text, Me.SQLClientAuthenticationMode.Checked, Me.SQLClientDatabase.Text, Me.SQLCLientServer.Text, Me.SQLClientUserName.Text, Me.SQLClientPassword.Text)
        CommonClientClassBuilder(DbProviders.SQLSERVER, ConnectionString, Me.SQLClientObjectName.Text, Me.SQLDBObjectType.SelectedIndex, Me.SQLCLientCommandText.Text, Me.SQLClientResult, Me.SQLClientParameterPrefix.Text)


    End Sub


    Sub OracleBuildClass()
        Me.ConnectionString = Utilities.GetOracleConnectionString(Me.OracleServerName.Text, Me.OracleUsername.Text, Me.OraclePassword.Text, Me.chkORACLEDEDICATEDSERVER.Checked, Me.chkORACLEUSESID.Checked, Me.OracleServiceName.Text, Me.OraclePort.Text)
        CommonClientClassBuilder(DbProviders.ORACLE, Me.ConnectionString, Me.OracleCommandText.Text, Me.OracleDBObjectType.SelectedIndex, Me.OracleCommandText.Text, Me.OracleResult, "@")
    End Sub

    Sub OLEDBBuildClass()

        OLEDBClassBuilder(Me.OLEDBConnectionString.Text, Me.OLEDBUserName.Text, Me.OLEDBPassword.Text, Me.OLEDB_ObjectName.Text)

    End Sub

    Sub DB2ISERIESBuildClass()

        Dim ConnectionString As String = Utilities.GetDB2iSeriesConnectionString(Me.txt_DB2ISeries_ConnectionString.Text, Me.txt_DB2ISeries_ServerName.Text, Me.txt_DB2ISeries_UserName.Text, Me.txt_DB2ISeries_Password.Text, Me.txt_DB2ISeries_LibraryList.Text)
        CommonClientClassBuilder(DbProviders.DB2ISERIES, ConnectionString, txt_DB2ISeries_ObjecName.Text, cmd_DB2ISeries_DbObjectType.SelectedIndex, txt_DB2ISeries_CommandText.Text, txt_DB2ISeries_ObjectCode, Me.txt_DB2iSeries_ParameterPrefix.Text)

    End Sub
    Sub MySQLBuildClass()
        Dim ConnectionString As String = Utilities.GetMySQLCLientConnectionString(Me.txt_MySQLConnectionString.Text, Me.txt_MySQLServerName.Text, Me.txt_MySQLDataBaseName.Text, Me.txt_MySQLPort.Text, Me.txt_MySQLUserName.Text, Me.txt_MySQLPassword.Text)
        CommonClientClassBuilder(DbProviders.MYSQL, ConnectionString, txt_MySQLObjectName.Text, MySQLDBObjectType.SelectedIndex, txt_MySQLCommandText.Text, txt_MySQLObjectCode, Me.txt_DB2iSeries_ParameterPrefix.Text)

    End Sub

    Sub OLEDBDB2BuildClass()


        OLEDBDB2ClassBuilder(Me.OLEDBDB2ConnectionString.Text, Me.OLEDBDB2UserName.Text, Me.OLEDBDB2Password.Text, Me.OLEDBDB2_ObjectName.Text)

    End Sub


    Public Sub OLEDBDB2ClassBuilder(ByVal ConnectionString As String, ByVal UserName As String, ByVal Password As String, ByVal DbObject As String)


        Dim mySQL As String = ""
        Dim DBEntityName As String = Me.OLEDBDB2_CommandText.Text

        Dim COmmandType As System.Data.CommandType = CommandType.Text

        Dim mDBObjectType As String = mDBObjecTypeSQL
        Dim mPrefix As String = ""
        Select Case Me.OLEDBDB2DbObjectType.SelectedIndex
            Case Is = 0
                mySQL = "SELECT * FROM " & DbObject ' & " FETCH FIRST 1 ROWS ONLY "
                mDBObjectType = mDBObjecTypeTABLE
            Case Is = 1
                mySQL = "SELECT * FROM " & DbObject '& " FETCH FIRST 1 ROWS ONLY "
                mDBObjectType = mDBObjecTypeVIEW
            Case Is = 2
                mySQL = DbObject
            Case Else
                mySQL = DbObject
        End Select


        Dim a As String = Chr(34)
        Dim s As String = ""
        Dim ss As String = ""
        Dim TableName As String = DbObject
        Dim isPKey As String = "false"
        Dim myConnection As OleDb.OleDbConnection
        Try
            myConnection = New OleDb.OleDbConnection(ConnectionString)
        Catch ex As Exception
            MsgBox("Error!" & vbCrLf & ex.Message, MsgBoxStyle.Critical, Me.Text)
            Exit Sub
        End Try

        Dim myDataset As New DataSet
        Dim MyDataAdapter As New OleDb.OleDbDataAdapter
        Dim myDataReader As OleDb.OleDbDataReader
        Dim myCommand As New OleDb.OleDbCommand
        Dim myDataTable As New DataTable
        Dim mySchemaTable As New DataTable

        With myCommand
            .Connection = myConnection
            .CommandText = mySQL & " FETCH FIRST 1 ROWS ONLY "
            .CommandType = COmmandType

        End With

        With MyDataAdapter
            .SelectCommand = myCommand
        End With

        Try
            myConnection.Open()
            Me.ConnectionString = myConnection.ConnectionString
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.ConnectionOpen" & vbCrLf & ex.Message)
            Exit Sub
        End Try


        Try
            MyDataAdapter.Fill(myDataset, DbObject)
            myDataTable = myDataset.Tables(DbObject)
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.GetDataTable" & vbCrLf & ex.Message)
            Exit Sub
        End Try


        Try
            myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly Or CommandBehavior.KeyInfo)
            myDataReader.Read()
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.ExecuteReader" & vbCrLf & ex.Message)
            Exit Sub
        End Try


        Try
            mySchemaTable = myDataReader.GetSchemaTable
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.GetSchemaTable" & vbCrLf & ex.Message)
            Exit Sub
        End Try
        Me.ConnectionString = myConnection.ConnectionString




        '0 - Public with properties in a single line
        '1 - Private with properties in a single line
        '2 - Public Properties Get - Set

        s = s & CommonClassBuilderHeader(DBEntityName, DbObject, Me.cmbBuildOption.SelectedIndex, mPrefix)
        s = s & CommonClassBuilderColumns2(DbProviders.OLEDBDB2, mySchemaTable, Me.cmbBuildOption.SelectedIndex, Me.OLEDBDB2DbObjectType.SelectedIndex, Me.OLEDBDB2_CommandText.Text)
        s = s & CommonClassBuilderConstructor(DBEntityName, DbObject, mDBObjectType, cmbBuildOption.SelectedIndex, mPrefix)



        Me.OLEDBDB2Result.Text = s
    End Sub
    Public Sub OLEDBClassBuilder(ByVal ConnectionString As String, ByVal UserName As String, ByVal Password As String, ByVal DbObject As String)


        Dim mySQL As String = ""
        Dim DBEntityName As String = Me.OLEDB_CommandText.Text

        Dim COmmandType As System.Data.CommandType = CommandType.Text

        Dim mDBObjectType As String = mDBObjecTypeSQL

        Select Case Me.OLEDBDBObjectType.SelectedIndex
            Case Is = 0
                mySQL = "SELECT * FROM " & DbObject & " WHERE 1<>1"
                mDBObjectType = mDBObjecTypeTABLE
            Case Is = 1
                mySQL = "SELECT * FROM " & DbObject
                mDBObjectType = mDBObjecTypeVIEW
            Case Is = 2
                mySQL = DbObject
            Case Else
                mySQL = DbObject
        End Select


        Dim a As String = Chr(34)
        Dim s As String = ""
        Dim ss As String = ""
        Dim TableName As String = DbObject
        Dim isPKey As String = "false"
        Dim myConnection As OleDb.OleDbConnection
        Try
            myConnection = New OleDb.OleDbConnection(ConnectionString)

        Catch ex As Exception
            MsgBox("Error!" & vbCrLf & ex.Message, MsgBoxStyle.Critical, Me.Text)
            Exit Sub
        End Try

        Dim myDataset As New DataSet
        Dim MyDataAdapter As New OleDb.OleDbDataAdapter
        Dim myDataReader As OleDb.OleDbDataReader
        Dim myCommand As New OleDb.OleDbCommand
        Dim myDataTable As New DataTable
        Dim mySchemaTable As New DataTable

        With myCommand
            .Connection = myConnection
            .CommandText = mySQL
            .CommandType = COmmandType

        End With

        With MyDataAdapter
            .SelectCommand = myCommand
        End With

        Try
            myConnection.Open()
            Me.ConnectionString = myConnection.ConnectionString
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.ConnectionOpen" & vbCrLf & ex.Message)
            Exit Sub
        End Try


        Try
            MyDataAdapter.Fill(myDataset, DbObject)
            myDataTable = myDataset.Tables(DbObject)
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.GetDataTable" & vbCrLf & ex.Message)
            Exit Sub
        End Try


        Try
            myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly Or CommandBehavior.KeyInfo)
            myDataReader.Read()
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.ExecuteReader" & vbCrLf & ex.Message)
            Exit Sub
        End Try


        Try
            mySchemaTable = myDataReader.GetSchemaTable
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.GetSchemaTable" & vbCrLf & ex.Message)
            Exit Sub
        End Try
        Me.ConnectionString = myConnection.ConnectionString

        s = s & CommonClassBuilderHeader(DBEntityName, DbObject, Me.cmbBuildOption.SelectedIndex, "")
        s = s & CommonClassBuilderColumns2(DbProviders.OLEDB, mySchemaTable, Me.cmbBuildOption.SelectedIndex, Me.OLEDBDBObjectType.SelectedIndex, Me.OLEDB_CommandText.Text)
        s = s & CommonClassBuilderConstructor(DBEntityName, DbObject, mDBObjectType, Me.cmbBuildOption.SelectedIndex, "")


        Me.OLEDBResult.Text = s
    End Sub
    Sub ODBCBuildClass()

        ODBCClassBuilder(Me.ODBCDSNName.Text, Me.ODBCUserName.Text, Me.ODBCPassword.Text, Me.ODBCTableName.Text)

    End Sub
    Public Sub ODBCClassBuilder(ByVal DSNName As String, ByVal UserName As String, ByVal Password As String, ByVal DbObject As String)


        Dim mySQL As String = ""
        Dim DBEntityName As String = ODBCObjectName.Text
        Dim COmmandType As System.Data.CommandType = CommandType.Text


        If DbObject.Trim = "" Then Exit Sub
        If ODBCDSNName.Text.Trim = "" Then Exit Sub


        mySQL = DbObject


        Dim a As String = Chr(34)
        Dim s As String = ""
        Dim ss As String = ""
        Dim TableName As String = DbObject
        Dim isPKey As String = "false"
        Dim myConnection As Odbc.OdbcConnection

        Dim ConnectionString As String = "DSN=" & DSNName & ";Username=" & UserName & ";Password=" & Password

        Try
            myConnection = New Odbc.OdbcConnection(ConnectionString)
            Me.ConnectionString = myConnection.ConnectionString
        Catch ex As Exception
            MsgBox("Error!" & vbCrLf & ex.Message, MsgBoxStyle.Critical, Me.Text)
            Exit Sub
        End Try

        Dim myDataset As New DataSet
        Dim MyDataAdapter As New Odbc.OdbcDataAdapter
        Dim myDataReader As Odbc.OdbcDataReader
        Dim myCommand As New Odbc.OdbcCommand
        Dim myDataTable As New DataTable
        Dim mySchemaTable As New DataTable



        Dim mDBObjectType As String = mDBObjecTypeSQL

        Select Case Me.ODBCDBObjectType.SelectedIndex
            Case Is = 0
                mySQL = "SELECT * FROM " & DbObject & " WHERE 1<>1"
                mDBObjectType = mDBObjecTypeTABLE
            Case Is = 1
                mySQL = "SELECT * FROM " & DbObject
                mDBObjectType = mDBObjecTypeVIEW
            Case Is = 2
                mySQL = DbObject
            Case Else
                mySQL = DbObject
        End Select


        With myCommand
            .Connection = myConnection
            .CommandText = mySQL
            .CommandType = Data.CommandType.Text
        End With

        With MyDataAdapter
            .SelectCommand = myCommand
        End With

        Try

            myConnection.Open()
            Me.ConnectionString = myConnection.ConnectionString
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.ConnectionOpen" & vbCrLf & ex.Message)
            Exit Sub
        End Try


        Try
            MyDataAdapter.Fill(myDataset, DbObject)
            myDataTable = myDataset.Tables(DbObject)
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.GetDataTable" & vbCrLf & ex.Message)
            Exit Sub
        End Try


        Try
            myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly Or CommandBehavior.KeyInfo)
            myDataReader.Read()
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.ExecuteReader" & vbCrLf & ex.Message)
            Exit Sub
        End Try


        Try
            mySchemaTable = myDataReader.GetSchemaTable

        Catch ex As Exception
            '            MsgBox("Error on ClassBuilder.GetSchemaTable" & vbCrLf & ex.Message)
            '  Exit Sub
        End Try

        Try
            mySchemaTable = myDataReader.GetSchemaTable
        Catch ex As Exception
            MsgBox("Error on ClassBuilder.GetSchemaTable" & vbCrLf & ex.Message)
            Exit Sub
        End Try

        Me.ConnectionString = myConnection.ConnectionString

        s = s + CommonClassBuilderHeader(DBEntityName, DbObject, Me.cmbBuildOption.SelectedIndex, "")

        '0 - Public with properties in a single line
        '1 - Public with properties in a "With" block
        '2 - Private with properties in a single line
        '3 - Private with properties in a "With" block
        '4 - Properties

        s = s & CommonClassBuilderHeader(DBEntityName, DbObject, Me.cmbBuildOption.SelectedIndex, "")
        s = s & CommonClassBuilderColumns(mySchemaTable, myDataTable, Me.cmbBuildOption.SelectedIndex)
        s = s & CommonClassBuilderConstructor(DBEntityName, DbObject, mDBObjectType, Me.cmbBuildOption.SelectedIndex, "")



        Me.ODBCResult.Text = s
    End Sub


    'Sub OracleClassBuilder(ByVal ConnectionString As String, ByVal DbObject As String)


    '    Dim mySQL As String = ""
    '    Dim DBEntityName As String = OracleObjectName.Text
    '    Dim CommandType As CommandType = CommandType.Text
    '    Dim mSQLCreateTable As String = ""

    '    mySQL = DbObject

    '    Dim a As String = Chr(34)
    '    Dim s As String = ""
    '    Dim ss As String = ""
    '    Dim TableName As String = DbObject
    '    Dim isPKey As String = "false"

    '    'Dim myConnection As OracleClient.OracleConnection
    '    'Dim MyDataAdapter As New OracleClient.OracleDataAdapter
    '    'Dim myDataReader As OracleClient.OracleDataReader
    '    'Dim myCommand As New OracleClient.OracleCommand

    '    Dim myConnection As Oracle.ManagedDataAccess.Client.OracleConnection
    '    Dim MyDataAdapter As New Oracle.ManagedDataAccess.Client.OracleDataAdapter
    '    Dim myDataReader As Oracle.ManagedDataAccess.Client.OracleDataReader
    '    Dim myCommand As New Oracle.ManagedDataAccess.Client.OracleCommand

    '    Dim myDataset As New DataSet
    '    Dim myDataTable As New DataTable
    '    Dim mySchemaTable As New DataTable
    '    Dim mPrefix As String = ""
    '    Dim mDBObjectType As String = mDBObjecTypeSQL

    '    Select Case Me.OracleDBObjectType.SelectedIndex
    '        Case Is = 0
    '            mySQL = "SELECT * FROM " & DbObject & " WHERE 0<>0"
    '            mDBObjectType = mDBObjecTypeTABLE
    '            mPrefix = "DbT_"
    '        Case Is = 1
    '            mySQL = "SELECT * FROM " & DbObject & " WHERE 0<>0"
    '            mDBObjectType = mDBObjecTypeVIEW
    '            mPrefix = "DbV_"

    '        Case Is = 2
    '            mySQL = DbObject
    '            mPrefix = "DbQ_"

    '        Case = 3
    '            mySQL = DbObject
    '            mPrefix = "DbP_"

    '    End Select


    '    Try
    '        'myConnection = New OracleClient.OracleConnection(ConnectionString)
    '        myConnection = New Oracle.ManagedDataAccess.Client.OracleConnection(ConnectionString)


    '    Catch ex As Exception
    '        MsgBox("Error on OracleCLientClassBuilder.NewOracleConnection" & vbCrLf & ex.Message)
    '        Exit Sub
    '    End Try

    '    With myCommand
    '        .Connection = myConnection
    '        .CommandText = mySQL
    '        .CommandType = CommandType
    '        .CommandTimeout = 0

    '    End With

    '    With MyDataAdapter
    '        .SelectCommand = myCommand
    '    End With

    '    Try
    '        myConnection.Open()
    '        Me.ConnectionString = myConnection.ConnectionString
    '    Catch ex As Exception
    '        MsgBox("Error on OracleClientClassBuilder.ConnectionOpen" & vbCrLf & ex.Message)
    '        Exit Sub
    '    End Try


    '    Try
    '        MyDataAdapter.Fill(myDataset, DbObject)
    '        myDataTable = myDataset.Tables(DbObject)
    '    Catch ex As Exception
    '        MsgBox("Error on OracleClientClassBuilder.GetDataTable" & vbCrLf & ex.Message)
    '        Exit Sub
    '    End Try


    '    Try
    '        myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly Or CommandBehavior.KeyInfo)
    '        myDataReader.Read()
    '    Catch ex As Exception
    '        MsgBox("Error on OracleClientClassBuilder.ExecuteReader" & vbCrLf & ex.Message)
    '        Exit Sub
    '    End Try


    '    Try
    '        mySchemaTable = myDataReader.GetSchemaTable
    '    Catch ex As Exception
    '        MsgBox("Error on OracleClientClassBuilder.GetSchemaTable" & vbCrLf & ex.Message)
    '        Exit Sub
    '    End Try

    '    Me.ConnectionString = myConnection.ConnectionString



    '    '0 - Public with properties in a single line
    '    '1 - Public with properties in a "With" block
    '    '2 - Private with properties in a single line
    '    '3 - Private with properties in a "With" block
    '    '4 - Properties
    '    s = s & CommonClassBuilderHeader(DBEntityName, DbObject, Me.cmbBuildOption.SelectedIndex, "")
    '    s = s & CommonClassBuilderColumns(mySchemaTable, myDataTable, Me.cmbBuildOption.SelectedIndex)
    '    s = s & CommonClassBuilderConstructor(DBEntityName, DbObject, mDBObjectType, Me.cmbBuildOption.SelectedIndex, "")


    '    Me.OracleResult.Text = s


    '    '   mSQLCreateTable = SQLCreateTable(mySchemaTable, myDataTable)


    'End Sub


    'Sub SQLClientClassBuilder(ByVal ConnectionString As String, ByVal DbObjectName As String, ByVal DbObjectType As Integer, ByVal SQLCommandText As String)


    '    Dim mySQL As String = ""

    '    Dim CommandType As CommandType = CommandType.Text

    '    If DbObjectName.Trim = "" Then Exit Sub
    '    If Me.SQLClientDatabase.Text.Trim = "" Then Exit Sub
    '    If Me.SQLCLientServer.Text.Trim = "" Then Exit Sub

    '    mySQL = SQLCommandText

    '    Dim a As String = Chr(34)
    '    Dim s As String = ""
    '    Dim ss As String = ""
    '    Dim TableName As String = SQLCommandText
    '    Dim isPKey As String = "false"

    '    Dim myConnection As SqlClient.SqlConnection
    '    Dim myDataset As New DataSet
    '    Dim MyDataAdapter As New SqlClient.SqlDataAdapter
    '    Dim myDataReader As SqlClient.SqlDataReader
    '    Dim myCommand As New SqlClient.SqlCommand
    '    Dim mySchemaTable As New DataTable

    '    Dim myParameters As System.Data.SqlClient.SqlParameterCollection = Nothing
    '    Dim _myParameter As sSQLParameter = New sSQLParameter


    '    Dim mDBObjectType As String = mDBObjecTypeSQL
    '    Dim mPrefix As String = "DbT_"
    '    Select Case DbObjectType
    '        Case Is = 0
    '            mySQL = "SELECT TOP 1 * FROM " & SQLCommandText
    '            mPrefix = "DbT_"
    '            mDBObjectType = mDBObjecTypeTABLE
    '        Case Is = 1
    '            mySQL = "SELECT TOP 1 * FROM " & SQLCommandText
    '            mDBObjectType = mDBObjecTypeVIEW
    '            mPrefix = "DbV_"
    '        Case Is = 2
    '            mDBObjectType = mDBObjecTypeSQL
    '            mPrefix = "DbQ_"
    '        Case = 3
    '            mySQL = SQLCommandText
    '            mDBObjectType = mDBObjecTypeStoredProcedure
    '            CommandType = CommandType.StoredProcedure
    '            mPrefix = "DbSP_"

    '        Case = 4
    '            mySQL = "select * from " & SQLCommandText
    '            mDBObjectType = mDBObjecTypeTableFunction
    '            CommandType = CommandType.Text
    '            mPrefix = "DbTFN_"

    '        Case = 5
    '            mySQL = "SELECT " & SQLCommandText
    '            mDBObjectType = mDBObjecTypeScalarFunction
    '            CommandType = CommandType.Text
    '            mPrefix = "DbSFN_"
    '        Case Else
    '            mySQL = SQLCommandText
    '    End Select


    '    Try
    '        myConnection = New SqlClient.SqlConnection(ConnectionString)
    '    Catch ex As Exception
    '        MsgBox("Error on SQLCLientClassBuilder.NewSqlConnection" & vbCrLf & ex.Message)
    '        Exit Sub
    '    End Try

    '    With myCommand

    '        .Connection = myConnection
    '        .CommandText = mySQL
    '        .CommandType = CommandType
    '        .CommandTimeout = 0
    '    End With

    '    With MyDataAdapter
    '        .SelectCommand = myCommand
    '    End With

    '    Try
    '        myConnection.Open()
    '        Me.ConnectionString = myConnection.ConnectionString
    '    Catch ex As Exception
    '        MsgBox("Error on SQLClientClassBuilder.ConnectionOpen" & vbCrLf & ex.Message)
    '        Exit Sub
    '    End Try



    '    Select Case mDBObjectType

    '        Case = mDBObjecTypeStoredProcedure
    '            Try
    '                SqlCommandBuilder.DeriveParameters(myCommand)
    '                myParameters = myCommand.Parameters
    '            Catch ex As Exception
    '                MsgBox("StoredProcedure " & mySQL & vbCrLf & "non esistente!")
    '                Return
    '            End Try

    '            Try
    '                myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly)
    '                mySchemaTable = myDataReader.GetSchemaTable()
    '            Catch ex As Exception
    '                MsgBox("StoredProcedure " & ex.Message)
    '            End Try

    '        Case = mDBObjecTypeTableFunction, mDBObjecTypeScalarFunction

    '            Dim DTF As DataTable = Nothing
    '            Dim _schema As String = Nothing
    '            Dim _function As String = SQLCommandText
    '            Dim _ss() As String = Split(SQLCommandText, ".")

    '            If _ss.Length > 1 Then
    '                _schema = _ss(0)
    '                Dim __function() = _ss(1).Split("(")
    '                _function = __function(0)
    '            End If

    '            DTF = myConnection.GetSchema("ProcedureParameters", New String() {Nothing, _schema, _function, Nothing})
    '            Dim _pList As String = ""
    '            For Each _p As DataRow In DTF.Rows
    '                _myParameter = New sSQLParameter

    '                If _p(5) <> "YES" Then

    '                    _myParameter.Name = _p(7)
    '                    _myParameter.DbType = _p(8)
    '                    _myParameter.Direction = _p(4)
    '                    _myParameter.Size = 1
    '                    myCommand.Parameters.AddWithValue(_myParameter.Name.ToString, Nothing)
    '                End If
    '            Next

    '            myParameters = myCommand.Parameters
    '            Try
    '                myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly)
    '                myDataReader.Read()
    '            Catch ex As Exception
    '                MsgBox("Error on SQLClientClassBuilder.ExecuteReader" & vbCrLf & ex.Message)
    '                Exit Sub
    '            End Try


    '            Try
    '                mySchemaTable = myDataReader.GetSchemaTable
    '            Catch ex As Exception
    '                MsgBox("Error on SQLClientClassBuilder.GetSchemaTable" & vbCrLf & ex.Message)
    '                Exit Sub
    '            End Try


    '        Case Else

    '            Try
    '                myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly Or CommandBehavior.KeyInfo)
    '                myDataReader.Read()
    '            Catch ex As Exception
    '                MsgBox("Error on SQLClientClassBuilder.ExecuteReader" & vbCrLf & ex.Message)
    '                Exit Sub
    '            End Try


    '            Try
    '                mySchemaTable = myDataReader.GetSchemaTable
    '            Catch ex As Exception
    '                MsgBox("Error on SQLClientClassBuilder.GetSchemaTable" & vbCrLf & ex.Message)
    '                Exit Sub
    '            End Try
    '    End Select


    '    Me.ConnectionString = myConnection.ConnectionString



    '    '0 - Public with DbColumns properties in a single line
    '    '1 - Private with DbColumns properties in a single line
    '    '2 - Public DbColumns properties Get - Set
    '    '3 - Public Properties Get - Set with private DbColumns
    '    '4 - POCO Class

    '    s = s & CommonClassBuilderHeader(DbObjectName, SQLCommandText, Me.cmbBuildOption.SelectedIndex, mPrefix)
    '    s = s & CommonClassBuilderColumns2(mySchemaTable, Me.cmbBuildOption.SelectedIndex)
    '    If (myParameters IsNot Nothing) Then
    '        s = s & CommonClassBuilderParameters(myParameters, Me.cmbBuildOption.SelectedIndex)
    '    End If

    '    s = s & CommonClassBuilderConstructor(DbObjectName, SQLCommandText, mDBObjectType, Me.cmbBuildOption.SelectedIndex, mPrefix)



    '    Me.SQLClientResult.Text = s
    'End Sub

    Sub CommonClientClassBuilderOLD(ByVal DbProvider As DbProviders, ByVal ConnectionString As String, ByVal DbObjectName As String, ByVal DbObjectType As Integer, ByVal SQLCommandText As String, ByRef DbObjectResult As TextBox, ByVal DbParamenterPrefix As String)

        If DbObjectName.Trim = "" Then Exit Sub

        Dim _SQLCommand As String = ""
        Dim CommandType As CommandType = CommandType.Text
        Dim a As String = Chr(34)
        Dim s As String = ""
        Dim ss As String = ""
        Dim TableName As String = SQLCommandText
        Dim isPKey As String = "false"
        Dim myConnection As System.Data.Common.DbConnection = Nothing
        Dim myDataset As New DataSet
        Dim myDataAdapter As System.Data.Common.DbDataAdapter = Nothing
        Dim myDataReader As System.Data.Common.DbDataReader = Nothing
        Dim myCommand As System.Data.Common.DbCommand = Nothing
        Dim mySchemaTable As New DataTable
        Dim MetadataCollectionName As String = ""
        Dim myParameters As System.Data.Common.DbParameterCollection = Nothing
        Dim SchemaSeparator As String = "."
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim mDBObjectType As String = mDBObjecTypeSQL
        Dim mPrefix As String = "DbT_"
        Dim SupportBrackets = Utilities.GetDbProviderBrackets(DbProvider, LeftBracket, RightBracket)

        _SQLCommand = SQLCommandText
        Select Case DbObjectType
            Case Is = 0
                _SQLCommand = "SELECT * FROM " & SQLCommandText & " WHERE 1<>1 "
                mPrefix = "DbT_"
                mDBObjectType = mDBObjecTypeTABLE
                CommandType = CommandType.Text
            Case Is = 1
                _SQLCommand = "SELECT * FROM " & SQLCommandText & " WHERE 1<>1 "
                mPrefix = "DbV_"
                mDBObjectType = mDBObjecTypeVIEW
                CommandType = CommandType.Text
            Case Is = 2
                mDBObjectType = mDBObjecTypeSQL
                mPrefix = "DbQ_"
                CommandType = CommandType.Text
            Case = 3
                _SQLCommand = SQLCommandText
                mDBObjectType = mDBObjecTypeStoredProcedure
                CommandType = CommandType.StoredProcedure
                mPrefix = "DbSP_"

            Case = 4


                _SQLCommand = "select * from " & SQLCommandText
                mDBObjectType = mDBObjecTypeTableFunction
                CommandType = CommandType.Text
                mPrefix = "DbTFN_"

            Case = 5

                Select Case DbProvider
                    Case DbProviders.DB2ISERIES
                        _SQLCommand = "VALUES " & SQLCommandText
                    Case DbProviders.MYSQL
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ODBC
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ODBCDB2
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.OLEDB
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.OLEDBDB2
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ORACLE
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.SQLSERVER
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case Else
                        _SQLCommand = "SELECT " & SQLCommandText

                End Select

                mDBObjectType = mDBObjecTypeScalarFunction
                CommandType = CommandType.Text
                mPrefix = "DbSFN_"
            Case Else
                _SQLCommand = SQLCommandText
        End Select



        Try
            Select Case DbProvider
                Case DbProviders.SQLSERVER
                    myConnection = New SqlClient.SqlConnection(ConnectionString)
                    myCommand = New SqlClient.SqlCommand()
                    myDataAdapter = New SqlClient.SqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.ORACLE
                    myConnection = New Oracle.ManagedDataAccess.Client.OracleConnection(ConnectionString)
                    myCommand = New Oracle.ManagedDataAccess.Client.OracleCommand()
                    myDataAdapter = New Oracle.ManagedDataAccess.Client.OracleDataAdapter
                    SupportBrackets = True
                Case DbProviders.OLEDB, DbProviders.OLEDBDB2
                    myConnection = New OleDb.OleDbConnection(ConnectionString)
                    myCommand = New OleDb.OleDbCommand()
                    myDataAdapter = New OleDb.OleDbDataAdapter
                    SupportBrackets = False
                Case DbProviders.MYSQL
                    myConnection = New MySql.Data.MySqlClient.MySqlConnection(ConnectionString)
                    myCommand = New MySql.Data.MySqlClient.MySqlCommand()
                    myDataAdapter = New MySql.Data.MySqlClient.MySqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.DB2ISERIES
                    myConnection = New IBM.Data.DB2.iSeries.iDB2Connection(ConnectionString)
                    myCommand = New IBM.Data.DB2.iSeries.iDB2Command()
                    myDataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter
                    SupportBrackets = True
                    SchemaSeparator = "/"
                Case DbProviders.ODBC, DbProviders.ODBCDB2
                    myConnection = New System.Data.Odbc.OdbcConnection(ConnectionString)
                    myCommand = New System.Data.Odbc.OdbcCommand()
                    myDataAdapter = New System.Data.Odbc.OdbcDataAdapter
                    SupportBrackets = True
                Case Else
            End Select
        Catch ex As Exception
            MsgBox("Error on CommonCLientClassBuilder.NewSqlConnection" & vbCrLf & "DBProvider=" + DbProvider.ToString + vbCrLf + ex.Message)
            Exit Sub
        End Try

        With myCommand

            .Connection = myConnection
            .CommandText = _SQLCommand
            .CommandType = CommandType
            .CommandTimeout = 0
        End With

        With myDataAdapter
            .SelectCommand = myCommand
        End With

        Try
            myConnection.Open()
            Me.ConnectionString = myConnection.ConnectionString
        Catch ex As Exception
            MsgBox("Error On CommonCLientClassBuilder.ConnectionOpen" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try

        Select Case mDBObjectType

            Case = mDBObjecTypeStoredProcedure
                Try
                    Select Case DbProvider
                        Case DbProviders.SQLSERVER
                            SqlCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.ORACLE
                            Oracle.ManagedDataAccess.Client.OracleCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                            OleDb.OleDbCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.MYSQL
                            MySql.Data.MySqlClient.MySqlCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.DB2ISERIES
                            IBM.Data.DB2.iSeries.iDB2CommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.ODBC, DbProviders.ODBCDB2
                            System.Data.Odbc.OdbcCommandBuilder.DeriveParameters(myCommand)
                        Case Else
                    End Select
                    myParameters = myCommand.Parameters
                Catch ex As Exception
                    MsgBox("StoredProcedure " & _SQLCommand & vbCrLf & "non esistente!")
                    Return
                End Try

                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly)
                    mySchemaTable = myDataReader.GetSchemaTable()
                Catch ex As Exception
                    MsgBox("StoredProcedure " & ex.Message)
                End Try

            Case = mDBObjecTypeTableFunction, mDBObjecTypeScalarFunction

                Dim DTF As DataTable = Nothing
                Dim _schema As String = Nothing
                Dim _function As String = SQLCommandText
                Dim _ss() As String = Split(SQLCommandText, SchemaSeparator)

                If _ss.Length > 1 Then
                    _schema = _ss(0)
                    Dim __function() = _ss(1).Split("(")
                    _function = __function(0)
                End If

                myParameters = myCommand.Parameters
                MetadataCollectionName = "ProcedureParameters"

                Select Case DbProvider
                    Case DbProviders.SQLSERVER
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.ORACLE
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.MYSQL
                        MetadataCollectionName = "Procedure Parameters"
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.DB2ISERIES

                        Dim DB2SQL As String = "SELECT * FROM QSYS2.SYSPARMS WHERE SPECIFIC_SCHEMA='" + _schema + "' AND SPECIFIC_NAME='" + _function + "' ORDER BY ORDINAL_POSITION"
                        Dim DB2Command As IBM.Data.DB2.iSeries.iDB2Command = New IBM.Data.DB2.iSeries.iDB2Command()
                        DB2Command.CommandType = CommandType.Text
                        DB2Command.CommandText = DB2SQL
                        DB2Command.Connection = myConnection
                        Dim DA As IBM.Data.DB2.iSeries.iDB2DataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter(DB2Command)
                        DTF = New DataTable
                        DTF.TableName = "QSYS2.SYSPARMS"
                        DA.Fill(DTF)


                    Case DbProviders.ODBC, DbProviders.ODBCDB2
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case Else
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                End Select


                Dim _pList As String = ""

                For Each _p As DataRow In DTF.Rows
                    Dim _myParameter = New sSQLParameter
                    Dim myParameter As System.Data.Common.DbParameter = Nothing
                    Dim myParameterDirection As ParameterDirection = Nothing
                    Dim myParameterName As String = ""
                    Dim myParameterPrefix As String = ""
                    myParameterName = Utilities.GetParameterName(DbProvider, _p)
                    myParameterDirection = Utilities.GetDbParameterDirection(DbProvider, _p)
                    Select Case DbProvider
                        Case DbProviders.SQLSERVER
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.SqlClient.SqlParameter
                            myParameterPrefix = ""
                            'End If

                        Case DbProviders.ORACLE
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New Oracle.ManagedDataAccess.Client.OracleParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.OleDb.OleDbParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case DbProviders.MYSQL
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New MySql.Data.MySqlClient.MySqlParameter
                            myParameterPrefix = "" ' DbParamenterPrefix
                            'End If

                        Case DbProviders.DB2ISERIES

                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New IBM.Data.DB2.iSeries.iDB2Parameter
                            myParameterPrefix = "" 'DbParamenterPrefix
                            'End If

                        Case DbProviders.ODBC, DbProviders.ODBCDB2
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.Odbc.OdbcParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case Else
                    End Select
                    myParameter.ParameterName = myParameterPrefix & myParameterName
                    myParameter.DbType = Utilities.GetDbTypeFromDatabaseType(DbProvider, _p)
                    myParameter.Direction = myParameterDirection
                    myParameter.Size = 1
                    myCommand.Parameters.Add(myParameter)

                Next

                myParameters = myCommand.Parameters
                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly)
                    myDataReader.Read()
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.ExecuteReader" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


                Try
                    mySchemaTable = myDataReader.GetSchemaTable
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.GetSchemaTable" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


            Case Else

                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly Or CommandBehavior.KeyInfo)
                    myDataReader.Read()
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.ExecuteReader" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


                Try
                    mySchemaTable = myDataReader.GetSchemaTable
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.GetSchemaTable" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try
        End Select


        Me.ConnectionString = myConnection.ConnectionString



        '0 - Public with DbColumns properties in a single line
        '1 - Private with DbColumns properties in a single line
        '2 - Public DbColumns properties Get - Set
        '3 - Public Properties Get - Set with private DbColumns
        '4 - POCO Class

        s = s & CommonClassBuilderHeader(DbObjectName, SQLCommandText, Me.cmbBuildOption.SelectedIndex, mPrefix)
        s = s & CommonClassBuilderColumns2(DbProvider, mySchemaTable, Me.cmbBuildOption.SelectedIndex, DbObjectType, DbObjectName)
        If (myParameters IsNot Nothing) Then
            s = s & CommonClassBuilderParameters(myParameters, Me.cmbBuildOption.SelectedIndex, DbParamenterPrefix)
        End If
        s = s & CommonClassBuilderConstructor(DbObjectName, SQLCommandText, mDBObjectType, Me.cmbBuildOption.SelectedIndex, mPrefix)



        DbObjectResult.Text = s
    End Sub
    Sub CommonClientTableClassBuilder(ByVal DbProvider As DbProviders, ByVal ConnectionString As String, ByVal DbObjectName As String, ByVal DbObjectType As Integer, ByVal SQLCommandText As String, ByRef DbObjectResult As TextBox, ByVal DbParamenterPrefix As String)

        If DbObjectName.Trim = "" Then Exit Sub

        Dim _SQLCommand As String = ""
        Dim CommandType As CommandType = CommandType.Text
        Dim a As String = Chr(34)
        Dim s As String = ""
        Dim ss As String = ""
        Dim TableName As String = SQLCommandText
        Dim isPKey As String = "false"
        Dim myConnection As System.Data.Common.DbConnection = Nothing
        Dim myDataset As New DataSet
        Dim myDataAdapter As System.Data.Common.DbDataAdapter = Nothing
        Dim myDataReader As System.Data.Common.DbDataReader = Nothing
        Dim myCommand As System.Data.Common.DbCommand = Nothing
        Dim mySchemaTable As New DataTable
        Dim MetadataCollectionName As String = ""
        Dim myParameters As System.Data.Common.DbParameterCollection = Nothing
        Dim SchemaSeparator As String = "."
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim mDBObjectType As String = mDBObjecTypeSQL
        Dim mPrefix As String = "DbT_"
        Dim SupportBrackets = Utilities.GetDbProviderBrackets(DbProvider, LeftBracket, RightBracket)
        Dim ErrorContext As String = "Error on CommonCLientTableClassBuilder."
        _SQLCommand = SQLCommandText

        _SQLCommand = "SELECT * FROM " & SQLCommandText & " WHERE 1<>1 "
        mPrefix = "DbT_"
        mDBObjectType = mDBObjecTypeTABLE
        CommandType = CommandType.Text


        Try
            Select Case DbProvider
                Case DbProviders.SQLSERVER
                    myConnection = New SqlClient.SqlConnection(ConnectionString)
                    myCommand = New SqlClient.SqlCommand()
                    myDataAdapter = New SqlClient.SqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.ORACLE
                    myConnection = New Oracle.ManagedDataAccess.Client.OracleConnection(ConnectionString)
                    myCommand = New Oracle.ManagedDataAccess.Client.OracleCommand()
                    myDataAdapter = New Oracle.ManagedDataAccess.Client.OracleDataAdapter
                    SupportBrackets = True
                Case DbProviders.OLEDB, DbProviders.OLEDBDB2
                    myConnection = New OleDb.OleDbConnection(ConnectionString)
                    myCommand = New OleDb.OleDbCommand()
                    myDataAdapter = New OleDb.OleDbDataAdapter
                    SupportBrackets = False
                Case DbProviders.MYSQL
                    myConnection = New MySql.Data.MySqlClient.MySqlConnection(ConnectionString)
                    myCommand = New MySql.Data.MySqlClient.MySqlCommand()
                    myDataAdapter = New MySql.Data.MySqlClient.MySqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.DB2ISERIES
                    myConnection = New IBM.Data.DB2.iSeries.iDB2Connection(ConnectionString)
                    myCommand = New IBM.Data.DB2.iSeries.iDB2Command()
                    myDataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter
                    SupportBrackets = True
                    SchemaSeparator = "/"
                Case DbProviders.ODBC, DbProviders.ODBCDB2
                    myConnection = New System.Data.Odbc.OdbcConnection(ConnectionString)
                    myCommand = New System.Data.Odbc.OdbcCommand()
                    myDataAdapter = New System.Data.Odbc.OdbcDataAdapter
                    SupportBrackets = True
                Case Else
            End Select
        Catch ex As Exception
            MsgBox(ErrorContext & "NewSqlConnection" & vbCrLf & "DBProvider=" + DbProvider.ToString + vbCrLf + ex.Message)
            Exit Sub
        End Try

        With myCommand
            .Connection = myConnection
            .CommandText = _SQLCommand
            .CommandType = CommandType
            .CommandTimeout = 0
        End With

        With myDataAdapter
            .SelectCommand = myCommand
        End With

        Try
            myConnection.Open()
            Me.ConnectionString = myConnection.ConnectionString
        Catch ex As Exception
            MsgBox(ErrorContext & "ConnectionOpen" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try

        Try
            myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly Or CommandBehavior.KeyInfo)
            myDataReader.Read()
        Catch ex As Exception
            MsgBox(ErrorContext & "ExecuteReader" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try


        Try
            mySchemaTable = myDataReader.GetSchemaTable
        Catch ex As Exception
            MsgBox(ErrorContext & "GetSchemaTable" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try

        Me.ConnectionString = myConnection.ConnectionString



        '0 - Public with DbColumns properties in a single line
        '1 - Private with DbColumns properties in a single line
        '2 - Public DbColumns properties Get - Set
        '3 - Public Properties Get - Set with private DbColumns
        '4 - POCO Class

        s = s & CommonClassBuilderHeader(DbObjectName, SQLCommandText, Me.cmbBuildOption.SelectedIndex, mPrefix)
        s = s & CommonClassBuilderColumns2(DbProvider, mySchemaTable, Me.cmbBuildOption.SelectedIndex, DbObjectType, DbObjectName)
        If (myParameters IsNot Nothing) Then
            s = s & CommonClassBuilderParameters(myParameters, Me.cmbBuildOption.SelectedIndex, DbParamenterPrefix)
        End If
        s = s & CommonClassBuilderConstructor(DbObjectName, SQLCommandText, mDBObjectType, Me.cmbBuildOption.SelectedIndex, mPrefix)



        DbObjectResult.Text = s
    End Sub

    Sub CommonClientScalarFunctionClassBuilder(ByVal DbProvider As DbProviders, ByVal ConnectionString As String, ByVal DbObjectName As String, ByVal DbObjectType As Integer, ByVal SQLCommandText As String, ByRef DbObjectResult As TextBox, ByVal DbParamenterPrefix As String)

        If DbObjectName.Trim = "" Then Exit Sub

        Dim _SQLCommand As String = ""
        Dim CommandType As CommandType = CommandType.Text
        Dim a As String = Chr(34)
        Dim s As String = ""
        Dim ss As String = ""
        Dim TableName As String = SQLCommandText
        Dim isPKey As String = "false"
        Dim myConnection As System.Data.Common.DbConnection = Nothing
        Dim myDataset As New DataSet
        Dim myDataAdapter As System.Data.Common.DbDataAdapter = Nothing
        Dim myDataReader As System.Data.Common.DbDataReader = Nothing
        Dim myCommand As System.Data.Common.DbCommand = Nothing
        Dim mySchemaTable As New DataTable
        Dim MetadataCollectionName As String = ""
        Dim myParameters As System.Data.Common.DbParameterCollection = Nothing
        Dim SchemaSeparator As String = "."
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim mDBObjectType As String = mDBObjecTypeSQL
        Dim mPrefix As String = "DbT_"
        Dim SupportBrackets = Utilities.GetDbProviderBrackets(DbProvider, LeftBracket, RightBracket)

        _SQLCommand = SQLCommandText


        Select Case DbProvider
            Case DbProviders.DB2ISERIES
                _SQLCommand = "VALUES " & SQLCommandText
            Case DbProviders.MYSQL
                _SQLCommand = "SELECT " & SQLCommandText
            Case DbProviders.ODBC
                _SQLCommand = "SELECT " & SQLCommandText
            Case DbProviders.ODBCDB2
                _SQLCommand = "SELECT " & SQLCommandText
            Case DbProviders.OLEDB
                _SQLCommand = "SELECT " & SQLCommandText
            Case DbProviders.OLEDBDB2
                _SQLCommand = "SELECT " & SQLCommandText
            Case DbProviders.ORACLE
                _SQLCommand = "SELECT " & SQLCommandText
            Case DbProviders.SQLSERVER
                _SQLCommand = "SELECT " & SQLCommandText
            Case Else
                _SQLCommand = "SELECT " & SQLCommandText
        End Select

        mDBObjectType = mDBObjecTypeScalarFunction
        CommandType = CommandType.Text
        mPrefix = "DbSFN_"

        Try
            Select Case DbProvider
                Case DbProviders.SQLSERVER
                    myConnection = New SqlClient.SqlConnection(ConnectionString)
                    myCommand = New SqlClient.SqlCommand()
                    myDataAdapter = New SqlClient.SqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.ORACLE
                    myConnection = New Oracle.ManagedDataAccess.Client.OracleConnection(ConnectionString)
                    myCommand = New Oracle.ManagedDataAccess.Client.OracleCommand()
                    myDataAdapter = New Oracle.ManagedDataAccess.Client.OracleDataAdapter
                    SupportBrackets = True
                Case DbProviders.OLEDB, DbProviders.OLEDBDB2
                    myConnection = New OleDb.OleDbConnection(ConnectionString)
                    myCommand = New OleDb.OleDbCommand()
                    myDataAdapter = New OleDb.OleDbDataAdapter
                    SupportBrackets = False
                Case DbProviders.MYSQL
                    myConnection = New MySql.Data.MySqlClient.MySqlConnection(ConnectionString)
                    myCommand = New MySql.Data.MySqlClient.MySqlCommand()
                    myDataAdapter = New MySql.Data.MySqlClient.MySqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.DB2ISERIES
                    myConnection = New IBM.Data.DB2.iSeries.iDB2Connection(ConnectionString)
                    myCommand = New IBM.Data.DB2.iSeries.iDB2Command()
                    myDataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter
                    SupportBrackets = True
                Case DbProviders.ODBC, DbProviders.ODBCDB2
                    myConnection = New System.Data.Odbc.OdbcConnection(ConnectionString)
                    myCommand = New System.Data.Odbc.OdbcCommand()
                    myDataAdapter = New System.Data.Odbc.OdbcDataAdapter
                    SupportBrackets = True
                Case Else
            End Select
        Catch ex As Exception
            MsgBox("Error on CommonCLientClassBuilder.NewSqlConnection" & vbCrLf & "DBProvider=" + DbProvider.ToString + vbCrLf + ex.Message)
            Exit Sub
        End Try

        With myCommand

            .Connection = myConnection
            .CommandText = _SQLCommand
            .CommandType = CommandType
            .CommandTimeout = 0
        End With

        With myDataAdapter
            .SelectCommand = myCommand
        End With

        Try
            myConnection.Open()
            Me.ConnectionString = myConnection.ConnectionString
        Catch ex As Exception
            MsgBox("Error On CommonCLientClassBuilder.ConnectionOpen" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try



        Dim DTF As DataTable = Nothing
        Dim _schema As String = Nothing
        Dim _function As String = SQLCommandText
        Dim _ss() As String = Split(SQLCommandText, SchemaSeparator)

        If _ss.Length > 1 Then
            _schema = _ss(0)
            Dim __function() = _ss(1).Split("(")
            _function = __function(0)
        End If

        myParameters = myCommand.Parameters
        MetadataCollectionName = "ProcedureParameters"

        Select Case DbProvider
            Case DbProviders.SQLSERVER
                DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
            Case DbProviders.ORACLE
                DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
            Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
            Case DbProviders.MYSQL
                MetadataCollectionName = "Procedure Parameters"
                DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
            Case DbProviders.DB2ISERIES
                Dim DB2SQL As String = "SELECT * FROM QSYS2.SYSPARMS WHERE SPECIFIC_SCHEMA='" + _schema + "' AND SPECIFIC_NAME='" + _function + "' ORDER BY ORDINAL_POSITION"
                Dim DB2Command As IBM.Data.DB2.iSeries.iDB2Command = New IBM.Data.DB2.iSeries.iDB2Command()
                DB2Command.CommandType = CommandType.Text
                DB2Command.CommandText = DB2SQL
                DB2Command.Connection = myConnection
                Dim DA As IBM.Data.DB2.iSeries.iDB2DataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter(DB2Command)
                DTF = New DataTable
                DTF.TableName = "QSYS2.SYSPARMS"
                DA.Fill(DTF)

            Case DbProviders.ODBC, DbProviders.ODBCDB2
                DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
            Case Else
                DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
        End Select

        Dim _pList As String = ""

        For Each _p As DataRow In DTF.Rows
            Dim _myParameter = New sSQLParameter
            Dim myParameter As System.Data.Common.DbParameter = Nothing
            Dim myParameterDirection As ParameterDirection = Nothing
            Dim myParameterName As String = ""
            Dim myParameterPrefix As String = ""


            myParameterName = Utilities.GetParameterName(DbProvider, _p)
            myParameterDirection = Utilities.GetDbParameterDirection(DbProvider, _p)


            Select Case DbProvider
                Case DbProviders.SQLSERVER
                    'If myParameterDirection = ParameterDirection.ReturnValue Then
                    '    myParameterName = "RETURN_VALUE"
                    'End If
                    myParameter = New System.Data.SqlClient.SqlParameter
                    myParameterPrefix = ""
                            'End If

                Case DbProviders.ORACLE
                    'If myParameterDirection <> ParameterDirection.ReturnValue Then
                    myParameter = New Oracle.ManagedDataAccess.Client.OracleParameter
                    myParameterPrefix = DbParamenterPrefix
                            'End If

                Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                    'If myParameterDirection <> ParameterDirection.ReturnValue Then
                    myParameter = New System.Data.OleDb.OleDbParameter
                    myParameterPrefix = DbParamenterPrefix
                            'End If

                Case DbProviders.MYSQL
                    'If myParameterDirection <> ParameterDirection.ReturnValue Then
                    myParameter = New MySql.Data.MySqlClient.MySqlParameter
                    myParameterPrefix = "" ' DbParamenterPrefix
                            'End If

                Case DbProviders.DB2ISERIES

                    If myParameterName = "" And myParameterDirection = ParameterDirection.Output Then
                        myParameterName = "RETURN_VALUE"
                    End If
                    'If myParameterDirection <> ParameterDirection.ReturnValue Then
                    myParameter = New IBM.Data.DB2.iSeries.iDB2Parameter
                    myParameterPrefix = "" 'DbParamenterPrefix
                           'End If

                Case DbProviders.ODBC, DbProviders.ODBCDB2
                    'If myParameterDirection <> ParameterDirection.ReturnValue Then
                    myParameter = New System.Data.Odbc.OdbcParameter
                    myParameterPrefix = DbParamenterPrefix
                    'End If

                Case Else
            End Select

            If myParameterName <> "" Then
                myParameter.ParameterName = myParameterPrefix & myParameterName
                myParameter.DbType = Utilities.GetDbTypeFromDatabaseType(DbProvider, _p)
                myParameter.Direction = myParameterDirection
                myParameter.Size = 1
                myCommand.Parameters.Add(myParameter)
            End If

        Next

        myParameters = myCommand.Parameters
        Try
            myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly)
            myDataReader.Read()
        Catch ex As Exception
            MsgBox("Error On CommonClientClassBuilder.ExecuteReader" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try


        Try
            mySchemaTable = myDataReader.GetSchemaTable
        Catch ex As Exception
            MsgBox("Error On CommonClientClassBuilder.GetSchemaTable" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try

        Me.ConnectionString = myConnection.ConnectionString

        '0 - Public with DbColumns properties in a single line
        '1 - Private with DbColumns properties in a single line
        '2 - Public DbColumns properties Get - Set
        '3 - Public Properties Get - Set with private DbColumns
        '4 - POCO Class

        s = s & CommonClassBuilderHeader(DbObjectName, SQLCommandText, Me.cmbBuildOption.SelectedIndex, mPrefix)
        s = s & CommonClassBuilderColumns2(DbProvider, mySchemaTable, Me.cmbBuildOption.SelectedIndex, DbObjectType, DbObjectName)
        If (myParameters IsNot Nothing) Then
            s = s & CommonClassBuilderParameters(myParameters, Me.cmbBuildOption.SelectedIndex, DbParamenterPrefix)
        End If
        s = s & CommonClassBuilderConstructor(DbObjectName, SQLCommandText, mDBObjectType, Me.cmbBuildOption.SelectedIndex, mPrefix)

        DbObjectResult.Text = s
    End Sub

    Sub CommonClientTableFunctionClassBuilder(ByVal DbProvider As DbProviders, ByVal ConnectionString As String, ByVal DbObjectName As String, ByVal DbObjectType As Integer, ByVal SQLCommandText As String, ByRef DbObjectResult As TextBox, ByVal DbParamenterPrefix As String)

        If DbObjectName.Trim = "" Then Exit Sub

        Dim _SQLCommand As String = ""
        Dim CommandType As CommandType = CommandType.Text
        Dim a As String = Chr(34)
        Dim s As String = ""
        Dim ss As String = ""
        Dim TableName As String = SQLCommandText
        Dim isPKey As String = "false"
        Dim myConnection As System.Data.Common.DbConnection = Nothing
        Dim myDataset As New DataSet
        Dim myDataAdapter As System.Data.Common.DbDataAdapter = Nothing
        Dim myDataReader As System.Data.Common.DbDataReader = Nothing
        Dim myCommand As System.Data.Common.DbCommand = Nothing
        Dim mySchemaTable As New DataTable
        Dim MetadataCollectionName As String = ""
        Dim myParameters As System.Data.Common.DbParameterCollection = Nothing
        Dim SchemaSeparator As String = "."
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim mDBObjectType As String = mDBObjecTypeSQL
        Dim mPrefix As String = "DbT_"
        Dim SupportBrackets = Utilities.GetDbProviderBrackets(DbProvider, LeftBracket, RightBracket)

        _SQLCommand = SQLCommandText
        Select Case DbObjectType
            Case Is = 0
                _SQLCommand = "SELECT * FROM " & SQLCommandText & " WHERE 1<>1 "
                mPrefix = "DbT_"
                mDBObjectType = mDBObjecTypeTABLE
                CommandType = CommandType.Text
            Case Is = 1
                _SQLCommand = "SELECT * FROM " & SQLCommandText & " WHERE 1<>1 "
                mPrefix = "DbV_"
                mDBObjectType = mDBObjecTypeVIEW
                CommandType = CommandType.Text
            Case Is = 2
                mDBObjectType = mDBObjecTypeSQL
                mPrefix = "DbQ_"
                CommandType = CommandType.Text
            Case = 3
                _SQLCommand = SQLCommandText
                mDBObjectType = mDBObjecTypeStoredProcedure
                CommandType = CommandType.StoredProcedure
                mPrefix = "DbSP_"

            Case = 4


                _SQLCommand = "select * from " & SQLCommandText
                mDBObjectType = mDBObjecTypeTableFunction
                CommandType = CommandType.Text
                mPrefix = "DbTFN_"

            Case = 5

                Select Case DbProvider
                    Case DbProviders.DB2ISERIES
                        _SQLCommand = "VALUES " & SQLCommandText
                    Case DbProviders.MYSQL
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ODBC
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ODBCDB2
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.OLEDB
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.OLEDBDB2
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ORACLE
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.SQLSERVER
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case Else
                        _SQLCommand = "SELECT " & SQLCommandText

                End Select

                mDBObjectType = mDBObjecTypeScalarFunction
                CommandType = CommandType.Text
                mPrefix = "DbSFN_"
            Case Else
                _SQLCommand = SQLCommandText
        End Select



        Try
            Select Case DbProvider
                Case DbProviders.SQLSERVER
                    myConnection = New SqlClient.SqlConnection(ConnectionString)
                    myCommand = New SqlClient.SqlCommand()
                    myDataAdapter = New SqlClient.SqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.ORACLE
                    myConnection = New Oracle.ManagedDataAccess.Client.OracleConnection(ConnectionString)
                    myCommand = New Oracle.ManagedDataAccess.Client.OracleCommand()
                    myDataAdapter = New Oracle.ManagedDataAccess.Client.OracleDataAdapter
                    SupportBrackets = True
                Case DbProviders.OLEDB, DbProviders.OLEDBDB2
                    myConnection = New OleDb.OleDbConnection(ConnectionString)
                    myCommand = New OleDb.OleDbCommand()
                    myDataAdapter = New OleDb.OleDbDataAdapter
                    SupportBrackets = False
                Case DbProviders.MYSQL
                    myConnection = New MySql.Data.MySqlClient.MySqlConnection(ConnectionString)
                    myCommand = New MySql.Data.MySqlClient.MySqlCommand()
                    myDataAdapter = New MySql.Data.MySqlClient.MySqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.DB2ISERIES
                    myConnection = New IBM.Data.DB2.iSeries.iDB2Connection(ConnectionString)
                    myCommand = New IBM.Data.DB2.iSeries.iDB2Command()
                    myDataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter
                    SupportBrackets = True
                    SchemaSeparator = "/"
                Case DbProviders.ODBC, DbProviders.ODBCDB2
                    myConnection = New System.Data.Odbc.OdbcConnection(ConnectionString)
                    myCommand = New System.Data.Odbc.OdbcCommand()
                    myDataAdapter = New System.Data.Odbc.OdbcDataAdapter
                    SupportBrackets = True
                Case Else
            End Select
        Catch ex As Exception
            MsgBox("Error on CommonCLientClassBuilder.NewSqlConnection" & vbCrLf & "DBProvider=" + DbProvider.ToString + vbCrLf + ex.Message)
            Exit Sub
        End Try

        With myCommand

            .Connection = myConnection
            .CommandText = _SQLCommand
            .CommandType = CommandType
            .CommandTimeout = 0
        End With

        With myDataAdapter
            .SelectCommand = myCommand
        End With

        Try
            myConnection.Open()
            Me.ConnectionString = myConnection.ConnectionString
        Catch ex As Exception
            MsgBox("Error On CommonCLientClassBuilder.ConnectionOpen" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try

        Select Case mDBObjectType

            Case = mDBObjecTypeStoredProcedure
                Try
                    Select Case DbProvider
                        Case DbProviders.SQLSERVER
                            SqlCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.ORACLE
                            Oracle.ManagedDataAccess.Client.OracleCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                            OleDb.OleDbCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.MYSQL
                            MySql.Data.MySqlClient.MySqlCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.DB2ISERIES
                            IBM.Data.DB2.iSeries.iDB2CommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.ODBC, DbProviders.ODBCDB2
                            System.Data.Odbc.OdbcCommandBuilder.DeriveParameters(myCommand)
                        Case Else
                    End Select
                    myParameters = myCommand.Parameters
                Catch ex As Exception
                    MsgBox("StoredProcedure " & _SQLCommand & vbCrLf & "non esistente!")
                    Return
                End Try

                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly)
                    mySchemaTable = myDataReader.GetSchemaTable()
                Catch ex As Exception
                    MsgBox("StoredProcedure " & ex.Message)
                End Try

            Case = mDBObjecTypeTableFunction, mDBObjecTypeScalarFunction

                Dim DTF As DataTable = Nothing
                Dim _schema As String = Nothing
                Dim _function As String = SQLCommandText
                Dim _ss() As String = Split(SQLCommandText, SchemaSeparator)

                If _ss.Length > 1 Then
                    _schema = _ss(0)
                    Dim __function() = _ss(1).Split("(")
                    _function = __function(0)
                End If

                myParameters = myCommand.Parameters
                MetadataCollectionName = "ProcedureParameters"

                Select Case DbProvider
                    Case DbProviders.SQLSERVER
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.ORACLE
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.MYSQL
                        MetadataCollectionName = "Procedure Parameters"
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.DB2ISERIES

                        Dim DB2SQL As String = "SELECT * FROM QSYS2.SYSPARMS WHERE SPECIFIC_SCHEMA='" + _schema + "' AND SPECIFIC_NAME='" + _function + "' ORDER BY ORDINAL_POSITION"
                        Dim DB2Command As IBM.Data.DB2.iSeries.iDB2Command = New IBM.Data.DB2.iSeries.iDB2Command()
                        DB2Command.CommandType = CommandType.Text
                        DB2Command.CommandText = DB2SQL
                        DB2Command.Connection = myConnection
                        Dim DA As IBM.Data.DB2.iSeries.iDB2DataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter(DB2Command)
                        DTF = New DataTable
                        DTF.TableName = "QSYS2.SYSPARMS"
                        DA.Fill(DTF)


                    Case DbProviders.ODBC, DbProviders.ODBCDB2
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case Else
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                End Select


                Dim _pList As String = ""

                For Each _p As DataRow In DTF.Rows
                    Dim _myParameter = New sSQLParameter
                    Dim myParameter As System.Data.Common.DbParameter = Nothing
                    Dim myParameterDirection As ParameterDirection = Nothing
                    Dim myParameterName As String = ""
                    Dim myParameterPrefix As String = ""
                    myParameterName = Utilities.GetParameterName(DbProvider, _p)
                    myParameterDirection = Utilities.GetDbParameterDirection(DbProvider, _p)
                    Select Case DbProvider
                        Case DbProviders.SQLSERVER
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.SqlClient.SqlParameter
                            myParameterPrefix = ""
                            'End If

                        Case DbProviders.ORACLE
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New Oracle.ManagedDataAccess.Client.OracleParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.OleDb.OleDbParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case DbProviders.MYSQL
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New MySql.Data.MySqlClient.MySqlParameter
                            myParameterPrefix = "" ' DbParamenterPrefix
                            'End If

                        Case DbProviders.DB2ISERIES

                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New IBM.Data.DB2.iSeries.iDB2Parameter
                            myParameterPrefix = "" 'DbParamenterPrefix
                            'End If

                        Case DbProviders.ODBC, DbProviders.ODBCDB2
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.Odbc.OdbcParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case Else
                    End Select
                    myParameter.ParameterName = myParameterPrefix & myParameterName
                    myParameter.DbType = Utilities.GetDbTypeFromDatabaseType(DbProvider, _p)
                    myParameter.Direction = myParameterDirection
                    myParameter.Size = 1
                    myCommand.Parameters.Add(myParameter)

                Next

                myParameters = myCommand.Parameters
                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly)
                    myDataReader.Read()
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.ExecuteReader" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


                Try
                    mySchemaTable = myDataReader.GetSchemaTable
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.GetSchemaTable" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


            Case Else

                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly Or CommandBehavior.KeyInfo)
                    myDataReader.Read()
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.ExecuteReader" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


                Try
                    mySchemaTable = myDataReader.GetSchemaTable
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.GetSchemaTable" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try
        End Select


        Me.ConnectionString = myConnection.ConnectionString



        '0 - Public with DbColumns properties in a single line
        '1 - Private with DbColumns properties in a single line
        '2 - Public DbColumns properties Get - Set
        '3 - Public Properties Get - Set with private DbColumns
        '4 - POCO Class

        s = s & CommonClassBuilderHeader(DbObjectName, SQLCommandText, Me.cmbBuildOption.SelectedIndex, mPrefix)
        s = s & CommonClassBuilderColumns2(DbProvider, mySchemaTable, Me.cmbBuildOption.SelectedIndex, DbObjectType, DbObjectName)
        If (myParameters IsNot Nothing) Then
            s = s & CommonClassBuilderParameters(myParameters, Me.cmbBuildOption.SelectedIndex, DbParamenterPrefix)
        End If
        s = s & CommonClassBuilderConstructor(DbObjectName, SQLCommandText, mDBObjectType, Me.cmbBuildOption.SelectedIndex, mPrefix)



        DbObjectResult.Text = s
    End Sub


    Sub CommonClientStoredProcedureClassBuilder(ByVal DbProvider As DbProviders, ByVal ConnectionString As String, ByVal DbObjectName As String, ByVal DbObjectType As Integer, ByVal SQLCommandText As String, ByRef DbObjectResult As TextBox, ByVal DbParamenterPrefix As String)

        If DbObjectName.Trim = "" Then Exit Sub

        Dim _SQLCommand As String = ""
        Dim CommandType As CommandType = CommandType.Text
        Dim a As String = Chr(34)
        Dim s As String = ""
        Dim ss As String = ""
        Dim TableName As String = SQLCommandText
        Dim isPKey As String = "false"
        Dim myConnection As System.Data.Common.DbConnection = Nothing
        Dim myDataset As New DataSet
        Dim myDataAdapter As System.Data.Common.DbDataAdapter = Nothing
        Dim myDataReader As System.Data.Common.DbDataReader = Nothing
        Dim myCommand As System.Data.Common.DbCommand = Nothing
        Dim mySchemaTable As New DataTable
        Dim MetadataCollectionName As String = ""
        Dim myParameters As System.Data.Common.DbParameterCollection = Nothing
        Dim SchemaSeparator As String = "."
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim mDBObjectType As String = mDBObjecTypeSQL
        Dim mPrefix As String = "DbT_"
        Dim SupportBrackets = Utilities.GetDbProviderBrackets(DbProvider, LeftBracket, RightBracket)

        _SQLCommand = SQLCommandText
        Select Case DbObjectType
            Case Is = 0
                _SQLCommand = "SELECT * FROM " & SQLCommandText & " WHERE 1<>1 "
                mPrefix = "DbT_"
                mDBObjectType = mDBObjecTypeTABLE
                CommandType = CommandType.Text
            Case Is = 1
                _SQLCommand = "SELECT * FROM " & SQLCommandText & " WHERE 1<>1 "
                mPrefix = "DbV_"
                mDBObjectType = mDBObjecTypeVIEW
                CommandType = CommandType.Text
            Case Is = 2
                mDBObjectType = mDBObjecTypeSQL
                mPrefix = "DbQ_"
                CommandType = CommandType.Text
            Case = 3
                _SQLCommand = SQLCommandText
                mDBObjectType = mDBObjecTypeStoredProcedure
                CommandType = CommandType.StoredProcedure
                mPrefix = "DbSP_"

            Case = 4


                _SQLCommand = "select * from " & SQLCommandText
                mDBObjectType = mDBObjecTypeTableFunction
                CommandType = CommandType.Text
                mPrefix = "DbTFN_"

            Case = 5

                Select Case DbProvider
                    Case DbProviders.DB2ISERIES
                        _SQLCommand = "VALUES " & SQLCommandText
                    Case DbProviders.MYSQL
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ODBC
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ODBCDB2
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.OLEDB
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.OLEDBDB2
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ORACLE
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.SQLSERVER
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case Else
                        _SQLCommand = "SELECT " & SQLCommandText

                End Select

                mDBObjectType = mDBObjecTypeScalarFunction
                CommandType = CommandType.Text
                mPrefix = "DbSFN_"
            Case Else
                _SQLCommand = SQLCommandText
        End Select



        Try
            Select Case DbProvider
                Case DbProviders.SQLSERVER
                    myConnection = New SqlClient.SqlConnection(ConnectionString)
                    myCommand = New SqlClient.SqlCommand()
                    myDataAdapter = New SqlClient.SqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.ORACLE
                    myConnection = New Oracle.ManagedDataAccess.Client.OracleConnection(ConnectionString)
                    myCommand = New Oracle.ManagedDataAccess.Client.OracleCommand()
                    myDataAdapter = New Oracle.ManagedDataAccess.Client.OracleDataAdapter
                    SupportBrackets = True
                Case DbProviders.OLEDB, DbProviders.OLEDBDB2
                    myConnection = New OleDb.OleDbConnection(ConnectionString)
                    myCommand = New OleDb.OleDbCommand()
                    myDataAdapter = New OleDb.OleDbDataAdapter
                    SupportBrackets = False
                Case DbProviders.MYSQL
                    myConnection = New MySql.Data.MySqlClient.MySqlConnection(ConnectionString)
                    myCommand = New MySql.Data.MySqlClient.MySqlCommand()
                    myDataAdapter = New MySql.Data.MySqlClient.MySqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.DB2ISERIES
                    myConnection = New IBM.Data.DB2.iSeries.iDB2Connection(ConnectionString)
                    myCommand = New IBM.Data.DB2.iSeries.iDB2Command()
                    myDataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter
                    SupportBrackets = True
                    SchemaSeparator = "/"
                Case DbProviders.ODBC, DbProviders.ODBCDB2
                    myConnection = New System.Data.Odbc.OdbcConnection(ConnectionString)
                    myCommand = New System.Data.Odbc.OdbcCommand()
                    myDataAdapter = New System.Data.Odbc.OdbcDataAdapter
                    SupportBrackets = True
                Case Else
            End Select
        Catch ex As Exception
            MsgBox("Error on CommonCLientClassBuilder.NewSqlConnection" & vbCrLf & "DBProvider=" + DbProvider.ToString + vbCrLf + ex.Message)
            Exit Sub
        End Try

        With myCommand

            .Connection = myConnection
            .CommandText = _SQLCommand
            .CommandType = CommandType
            .CommandTimeout = 0
        End With

        With myDataAdapter
            .SelectCommand = myCommand
        End With

        Try
            myConnection.Open()
            Me.ConnectionString = myConnection.ConnectionString
        Catch ex As Exception
            MsgBox("Error On CommonCLientClassBuilder.ConnectionOpen" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try

        Select Case mDBObjectType

            Case = mDBObjecTypeStoredProcedure
                Try
                    Select Case DbProvider
                        Case DbProviders.SQLSERVER
                            SqlCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.ORACLE
                            Oracle.ManagedDataAccess.Client.OracleCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                            OleDb.OleDbCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.MYSQL
                            MySql.Data.MySqlClient.MySqlCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.DB2ISERIES
                            IBM.Data.DB2.iSeries.iDB2CommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.ODBC, DbProviders.ODBCDB2
                            System.Data.Odbc.OdbcCommandBuilder.DeriveParameters(myCommand)
                        Case Else
                    End Select
                    myParameters = myCommand.Parameters
                Catch ex As Exception
                    MsgBox("StoredProcedure " & _SQLCommand & vbCrLf & "non esistente!")
                    Return
                End Try

                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly)
                    mySchemaTable = myDataReader.GetSchemaTable()
                Catch ex As Exception
                    MsgBox("StoredProcedure " & ex.Message)
                End Try

            Case = mDBObjecTypeTableFunction, mDBObjecTypeScalarFunction

                Dim DTF As DataTable = Nothing
                Dim _schema As String = Nothing
                Dim _function As String = SQLCommandText
                Dim _ss() As String = Split(SQLCommandText, SchemaSeparator)

                If _ss.Length > 1 Then
                    _schema = _ss(0)
                    Dim __function() = _ss(1).Split("(")
                    _function = __function(0)
                End If

                myParameters = myCommand.Parameters
                MetadataCollectionName = "ProcedureParameters"

                Select Case DbProvider
                    Case DbProviders.SQLSERVER
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.ORACLE
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.MYSQL
                        MetadataCollectionName = "Procedure Parameters"
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.DB2ISERIES

                        Dim DB2SQL As String = "SELECT * FROM QSYS2.SYSPARMS WHERE SPECIFIC_SCHEMA='" + _schema + "' AND SPECIFIC_NAME='" + _function + "' ORDER BY ORDINAL_POSITION"
                        Dim DB2Command As IBM.Data.DB2.iSeries.iDB2Command = New IBM.Data.DB2.iSeries.iDB2Command()
                        DB2Command.CommandType = CommandType.Text
                        DB2Command.CommandText = DB2SQL
                        DB2Command.Connection = myConnection
                        Dim DA As IBM.Data.DB2.iSeries.iDB2DataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter(DB2Command)
                        DTF = New DataTable
                        DTF.TableName = "QSYS2.SYSPARMS"
                        DA.Fill(DTF)


                    Case DbProviders.ODBC, DbProviders.ODBCDB2
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case Else
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                End Select


                Dim _pList As String = ""

                For Each _p As DataRow In DTF.Rows
                    Dim _myParameter = New sSQLParameter
                    Dim myParameter As System.Data.Common.DbParameter = Nothing
                    Dim myParameterDirection As ParameterDirection = Nothing
                    Dim myParameterName As String = ""
                    Dim myParameterPrefix As String = ""
                    myParameterName = Utilities.GetParameterName(DbProvider, _p)
                    myParameterDirection = Utilities.GetDbParameterDirection(DbProvider, _p)
                    Select Case DbProvider
                        Case DbProviders.SQLSERVER
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.SqlClient.SqlParameter
                            myParameterPrefix = ""
                            'End If

                        Case DbProviders.ORACLE
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New Oracle.ManagedDataAccess.Client.OracleParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.OleDb.OleDbParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case DbProviders.MYSQL
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New MySql.Data.MySqlClient.MySqlParameter
                            myParameterPrefix = "" ' DbParamenterPrefix
                            'End If

                        Case DbProviders.DB2ISERIES

                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New IBM.Data.DB2.iSeries.iDB2Parameter
                            myParameterPrefix = "" 'DbParamenterPrefix
                            'End If

                        Case DbProviders.ODBC, DbProviders.ODBCDB2
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.Odbc.OdbcParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case Else
                    End Select
                    myParameter.ParameterName = myParameterPrefix & myParameterName
                    myParameter.DbType = Utilities.GetDbTypeFromDatabaseType(DbProvider, _p)
                    myParameter.Direction = myParameterDirection
                    myParameter.Size = 1
                    myCommand.Parameters.Add(myParameter)

                Next

                myParameters = myCommand.Parameters
                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly)
                    myDataReader.Read()
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.ExecuteReader" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


                Try
                    mySchemaTable = myDataReader.GetSchemaTable
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.GetSchemaTable" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


            Case Else

                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly Or CommandBehavior.KeyInfo)
                    myDataReader.Read()
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.ExecuteReader" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


                Try
                    mySchemaTable = myDataReader.GetSchemaTable
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.GetSchemaTable" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try
        End Select


        Me.ConnectionString = myConnection.ConnectionString



        '0 - Public with DbColumns properties in a single line
        '1 - Private with DbColumns properties in a single line
        '2 - Public DbColumns properties Get - Set
        '3 - Public Properties Get - Set with private DbColumns
        '4 - POCO Class

        s = s & CommonClassBuilderHeader(DbObjectName, SQLCommandText, Me.cmbBuildOption.SelectedIndex, mPrefix)
        s = s & CommonClassBuilderColumns2(DbProvider, mySchemaTable, Me.cmbBuildOption.SelectedIndex, DbObjectType, DbObjectName)
        If (myParameters IsNot Nothing) Then
            s = s & CommonClassBuilderParameters(myParameters, Me.cmbBuildOption.SelectedIndex, DbParamenterPrefix)
        End If
        s = s & CommonClassBuilderConstructor(DbObjectName, SQLCommandText, mDBObjectType, Me.cmbBuildOption.SelectedIndex, mPrefix)



        DbObjectResult.Text = s
    End Sub

    Sub CommonClientSQLCommandClassBuilder(ByVal DbProvider As DbProviders, ByVal ConnectionString As String, ByVal DbObjectName As String, ByVal DbObjectType As Integer, ByVal SQLCommandText As String, ByRef DbObjectResult As TextBox, ByVal DbParamenterPrefix As String)

        If DbObjectName.Trim = "" Then Exit Sub

        Dim _SQLCommand As String = ""
        Dim CommandType As CommandType = CommandType.Text
        Dim a As String = Chr(34)
        Dim s As String = ""
        Dim ss As String = ""
        Dim TableName As String = SQLCommandText
        Dim isPKey As String = "false"
        Dim myConnection As System.Data.Common.DbConnection = Nothing
        Dim myDataset As New DataSet
        Dim myDataAdapter As System.Data.Common.DbDataAdapter = Nothing
        Dim myDataReader As System.Data.Common.DbDataReader = Nothing
        Dim myCommand As System.Data.Common.DbCommand = Nothing
        Dim mySchemaTable As New DataTable
        Dim MetadataCollectionName As String = ""
        Dim myParameters As System.Data.Common.DbParameterCollection = Nothing
        Dim SchemaSeparator As String = "."
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim mDBObjectType As String = mDBObjecTypeSQL
        Dim mPrefix As String = "DbT_"
        Dim SupportBrackets = Utilities.GetDbProviderBrackets(DbProvider, LeftBracket, RightBracket)

        _SQLCommand = SQLCommandText
        Select Case DbObjectType
            Case Is = 0
                _SQLCommand = "SELECT * FROM " & SQLCommandText & " WHERE 1<>1 "
                mPrefix = "DbT_"
                mDBObjectType = mDBObjecTypeTABLE
                CommandType = CommandType.Text
            Case Is = 1
                _SQLCommand = "SELECT * FROM " & SQLCommandText & " WHERE 1<>1 "
                mPrefix = "DbV_"
                mDBObjectType = mDBObjecTypeVIEW
                CommandType = CommandType.Text
            Case Is = 2
                mDBObjectType = mDBObjecTypeSQL
                mPrefix = "DbQ_"
                CommandType = CommandType.Text
            Case = 3
                _SQLCommand = SQLCommandText
                mDBObjectType = mDBObjecTypeStoredProcedure
                CommandType = CommandType.StoredProcedure
                mPrefix = "DbSP_"

            Case = 4


                _SQLCommand = "select * from " & SQLCommandText
                mDBObjectType = mDBObjecTypeTableFunction
                CommandType = CommandType.Text
                mPrefix = "DbTFN_"

            Case = 5

                Select Case DbProvider
                    Case DbProviders.DB2ISERIES
                        _SQLCommand = "VALUES " & SQLCommandText
                    Case DbProviders.MYSQL
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ODBC
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ODBCDB2
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.OLEDB
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.OLEDBDB2
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.ORACLE
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case DbProviders.SQLSERVER
                        _SQLCommand = "SELECT " & SQLCommandText
                    Case Else
                        _SQLCommand = "SELECT " & SQLCommandText

                End Select

                mDBObjectType = mDBObjecTypeScalarFunction
                CommandType = CommandType.Text
                mPrefix = "DbSFN_"
            Case Else
                _SQLCommand = SQLCommandText
        End Select



        Try
            Select Case DbProvider
                Case DbProviders.SQLSERVER
                    myConnection = New SqlClient.SqlConnection(ConnectionString)
                    myCommand = New SqlClient.SqlCommand()
                    myDataAdapter = New SqlClient.SqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.ORACLE
                    myConnection = New Oracle.ManagedDataAccess.Client.OracleConnection(ConnectionString)
                    myCommand = New Oracle.ManagedDataAccess.Client.OracleCommand()
                    myDataAdapter = New Oracle.ManagedDataAccess.Client.OracleDataAdapter
                    SupportBrackets = True
                Case DbProviders.OLEDB, DbProviders.OLEDBDB2
                    myConnection = New OleDb.OleDbConnection(ConnectionString)
                    myCommand = New OleDb.OleDbCommand()
                    myDataAdapter = New OleDb.OleDbDataAdapter
                    SupportBrackets = False
                Case DbProviders.MYSQL
                    myConnection = New MySql.Data.MySqlClient.MySqlConnection(ConnectionString)
                    myCommand = New MySql.Data.MySqlClient.MySqlCommand()
                    myDataAdapter = New MySql.Data.MySqlClient.MySqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.DB2ISERIES
                    myConnection = New IBM.Data.DB2.iSeries.iDB2Connection(ConnectionString)
                    myCommand = New IBM.Data.DB2.iSeries.iDB2Command()
                    myDataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter
                    SupportBrackets = True
                    SchemaSeparator = "/"
                Case DbProviders.ODBC, DbProviders.ODBCDB2
                    myConnection = New System.Data.Odbc.OdbcConnection(ConnectionString)
                    myCommand = New System.Data.Odbc.OdbcCommand()
                    myDataAdapter = New System.Data.Odbc.OdbcDataAdapter
                    SupportBrackets = True
                Case Else
            End Select
        Catch ex As Exception
            MsgBox("Error on CommonCLientClassBuilder.NewSqlConnection" & vbCrLf & "DBProvider=" + DbProvider.ToString + vbCrLf + ex.Message)
            Exit Sub
        End Try

        With myCommand

            .Connection = myConnection
            .CommandText = _SQLCommand
            .CommandType = CommandType
            .CommandTimeout = 0
        End With

        With myDataAdapter
            .SelectCommand = myCommand
        End With

        Try
            myConnection.Open()
            Me.ConnectionString = myConnection.ConnectionString
        Catch ex As Exception
            MsgBox("Error On CommonCLientClassBuilder.ConnectionOpen" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try

        Select Case mDBObjectType

            Case = mDBObjecTypeStoredProcedure
                Try
                    Select Case DbProvider
                        Case DbProviders.SQLSERVER
                            SqlCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.ORACLE
                            Oracle.ManagedDataAccess.Client.OracleCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                            OleDb.OleDbCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.MYSQL
                            MySql.Data.MySqlClient.MySqlCommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.DB2ISERIES
                            IBM.Data.DB2.iSeries.iDB2CommandBuilder.DeriveParameters(myCommand)
                        Case DbProviders.ODBC, DbProviders.ODBCDB2
                            System.Data.Odbc.OdbcCommandBuilder.DeriveParameters(myCommand)
                        Case Else
                    End Select
                    myParameters = myCommand.Parameters
                Catch ex As Exception
                    MsgBox("StoredProcedure " & _SQLCommand & vbCrLf & "non esistente!")
                    Return
                End Try

                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly)
                    mySchemaTable = myDataReader.GetSchemaTable()
                Catch ex As Exception
                    MsgBox("StoredProcedure " & ex.Message)
                End Try

            Case = mDBObjecTypeTableFunction, mDBObjecTypeScalarFunction

                Dim DTF As DataTable = Nothing
                Dim _schema As String = Nothing
                Dim _function As String = SQLCommandText
                Dim _ss() As String = Split(SQLCommandText, SchemaSeparator)

                If _ss.Length > 1 Then
                    _schema = _ss(0)
                    Dim __function() = _ss(1).Split("(")
                    _function = __function(0)
                End If

                myParameters = myCommand.Parameters
                MetadataCollectionName = "ProcedureParameters"

                Select Case DbProvider
                    Case DbProviders.SQLSERVER
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.ORACLE
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.MYSQL
                        MetadataCollectionName = "Procedure Parameters"
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case DbProviders.DB2ISERIES

                        Dim DB2SQL As String = "SELECT * FROM QSYS2.SYSPARMS WHERE SPECIFIC_SCHEMA='" + _schema + "' AND SPECIFIC_NAME='" + _function + "' ORDER BY ORDINAL_POSITION"
                        Dim DB2Command As IBM.Data.DB2.iSeries.iDB2Command = New IBM.Data.DB2.iSeries.iDB2Command()
                        DB2Command.CommandType = CommandType.Text
                        DB2Command.CommandText = DB2SQL
                        DB2Command.Connection = myConnection
                        Dim DA As IBM.Data.DB2.iSeries.iDB2DataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter(DB2Command)
                        DTF = New DataTable
                        DTF.TableName = "QSYS2.SYSPARMS"
                        DA.Fill(DTF)


                    Case DbProviders.ODBC, DbProviders.ODBCDB2
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                    Case Else
                        DTF = myConnection.GetSchema(MetadataCollectionName, New String() {Nothing, _schema, _function, Nothing})
                End Select


                Dim _pList As String = ""

                For Each _p As DataRow In DTF.Rows
                    Dim _myParameter = New sSQLParameter
                    Dim myParameter As System.Data.Common.DbParameter = Nothing
                    Dim myParameterDirection As ParameterDirection = Nothing
                    Dim myParameterName As String = ""
                    Dim myParameterPrefix As String = ""
                    myParameterName = Utilities.GetParameterName(DbProvider, _p)
                    myParameterDirection = Utilities.GetDbParameterDirection(DbProvider, _p)
                    Select Case DbProvider
                        Case DbProviders.SQLSERVER
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.SqlClient.SqlParameter
                            myParameterPrefix = ""
                            'End If

                        Case DbProviders.ORACLE
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New Oracle.ManagedDataAccess.Client.OracleParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case DbProviders.OLEDBDB2, DbProviders.OLEDB
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.OleDb.OleDbParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case DbProviders.MYSQL
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New MySql.Data.MySqlClient.MySqlParameter
                            myParameterPrefix = "" ' DbParamenterPrefix
                            'End If

                        Case DbProviders.DB2ISERIES

                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New IBM.Data.DB2.iSeries.iDB2Parameter
                            myParameterPrefix = "" 'DbParamenterPrefix
                            'End If

                        Case DbProviders.ODBC, DbProviders.ODBCDB2
                            'If myParameterDirection <> ParameterDirection.ReturnValue Then
                            myParameter = New System.Data.Odbc.OdbcParameter
                            myParameterPrefix = DbParamenterPrefix
                            'End If

                        Case Else
                    End Select
                    myParameter.ParameterName = myParameterPrefix & myParameterName
                    myParameter.DbType = Utilities.GetDbTypeFromDatabaseType(DbProvider, _p)
                    myParameter.Direction = myParameterDirection
                    myParameter.Size = 1
                    myCommand.Parameters.Add(myParameter)

                Next

                myParameters = myCommand.Parameters
                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly)
                    myDataReader.Read()
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.ExecuteReader" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


                Try
                    mySchemaTable = myDataReader.GetSchemaTable
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.GetSchemaTable" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


            Case Else

                Try
                    myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly Or CommandBehavior.KeyInfo)
                    myDataReader.Read()
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.ExecuteReader" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try


                Try
                    mySchemaTable = myDataReader.GetSchemaTable
                Catch ex As Exception
                    MsgBox("Error On CommonClientClassBuilder.GetSchemaTable" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
                    Exit Sub
                End Try
        End Select


        Me.ConnectionString = myConnection.ConnectionString



        '0 - Public with DbColumns properties in a single line
        '1 - Private with DbColumns properties in a single line
        '2 - Public DbColumns properties Get - Set
        '3 - Public Properties Get - Set with private DbColumns
        '4 - POCO Class

        s = s & CommonClassBuilderHeader(DbObjectName, SQLCommandText, Me.cmbBuildOption.SelectedIndex, mPrefix)
        s = s & CommonClassBuilderColumns2(DbProvider, mySchemaTable, Me.cmbBuildOption.SelectedIndex, DbObjectType, DbObjectName)
        If (myParameters IsNot Nothing) Then
            s = s & CommonClassBuilderParameters(myParameters, Me.cmbBuildOption.SelectedIndex, DbParamenterPrefix)
        End If
        s = s & CommonClassBuilderConstructor(DbObjectName, SQLCommandText, mDBObjectType, Me.cmbBuildOption.SelectedIndex, mPrefix)



        DbObjectResult.Text = s
    End Sub

    Sub CommonClientViewClassBuilder(ByVal DbProvider As DbProviders, ByVal ConnectionString As String, ByVal DbObjectName As String, ByVal DbObjectType As Integer, ByVal SQLCommandText As String, ByRef DbObjectResult As TextBox, ByVal DbParamenterPrefix As String)

        If DbObjectName.Trim = "" Then Exit Sub

        Dim _SQLCommand As String = ""
        Dim CommandType As CommandType = CommandType.Text
        Dim a As String = Chr(34)
        Dim s As String = ""
        Dim ss As String = ""
        Dim TableName As String = SQLCommandText
        Dim isPKey As String = "false"
        Dim myConnection As System.Data.Common.DbConnection = Nothing
        Dim myDataset As New DataSet
        Dim myDataAdapter As System.Data.Common.DbDataAdapter = Nothing
        Dim myDataReader As System.Data.Common.DbDataReader = Nothing
        Dim myCommand As System.Data.Common.DbCommand = Nothing
        Dim mySchemaTable As New DataTable
        Dim MetadataCollectionName As String = ""
        Dim myParameters As System.Data.Common.DbParameterCollection = Nothing
        Dim SchemaSeparator As String = "."
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim mDBObjectType As String = mDBObjecTypeSQL
        Dim mPrefix As String = "DbV_"
        Dim SupportBrackets = Utilities.GetDbProviderBrackets(DbProvider, LeftBracket, RightBracket)
        Dim ErrorContext As String = "Error On CommonClientViewClassBuilder."

        _SQLCommand = SQLCommandText
        _SQLCommand = "SELECT * FROM " & SQLCommandText & " WHERE 1<>1 "
        mPrefix = "DbV_"
        mDBObjectType = mDBObjecTypeVIEW
        CommandType = CommandType.Text



        Try
            Select Case DbProvider
                Case DbProviders.SQLSERVER
                    myConnection = New SqlClient.SqlConnection(ConnectionString)
                    myCommand = New SqlClient.SqlCommand()
                    myDataAdapter = New SqlClient.SqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.ORACLE
                    myConnection = New Oracle.ManagedDataAccess.Client.OracleConnection(ConnectionString)
                    myCommand = New Oracle.ManagedDataAccess.Client.OracleCommand()
                    myDataAdapter = New Oracle.ManagedDataAccess.Client.OracleDataAdapter
                    SupportBrackets = True
                Case DbProviders.OLEDB, DbProviders.OLEDBDB2
                    myConnection = New OleDb.OleDbConnection(ConnectionString)
                    myCommand = New OleDb.OleDbCommand()
                    myDataAdapter = New OleDb.OleDbDataAdapter
                    SupportBrackets = False
                Case DbProviders.MYSQL
                    myConnection = New MySql.Data.MySqlClient.MySqlConnection(ConnectionString)
                    myCommand = New MySql.Data.MySqlClient.MySqlCommand()
                    myDataAdapter = New MySql.Data.MySqlClient.MySqlDataAdapter
                    SupportBrackets = True
                Case DbProviders.DB2ISERIES
                    myConnection = New IBM.Data.DB2.iSeries.iDB2Connection(ConnectionString)
                    myCommand = New IBM.Data.DB2.iSeries.iDB2Command()
                    myDataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter
                    SupportBrackets = True
                    SchemaSeparator = "/"
                Case DbProviders.ODBC, DbProviders.ODBCDB2
                    myConnection = New System.Data.Odbc.OdbcConnection(ConnectionString)
                    myCommand = New System.Data.Odbc.OdbcCommand()
                    myDataAdapter = New System.Data.Odbc.OdbcDataAdapter
                    SupportBrackets = True
                Case Else
            End Select
        Catch ex As Exception
            MsgBox(ErrorContext & "NewSqlConnection" & vbCrLf & "DBProvider=" + DbProvider.ToString + vbCrLf + ex.Message)
            Exit Sub
        End Try

        With myCommand

            .Connection = myConnection
            .CommandText = _SQLCommand
            .CommandType = CommandType
            .CommandTimeout = 0
        End With

        With myDataAdapter
            .SelectCommand = myCommand
        End With

        Try
            myConnection.Open()
            Me.ConnectionString = myConnection.ConnectionString
        Catch ex As Exception
            MsgBox(ErrorContext & "ConnectionOpen" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try

        Try
            myDataReader = myCommand.ExecuteReader(CommandBehavior.SchemaOnly Or CommandBehavior.KeyInfo)
            myDataReader.Read()
        Catch ex As Exception
            MsgBox(ErrorContext & "ExecuteReader" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try


        Try
            mySchemaTable = myDataReader.GetSchemaTable
        Catch ex As Exception
            MsgBox(ErrorContext & "GetSchemaTable" & vbCrLf & "DBProvider=" & DbProvider.ToString & vbCrLf + ex.Message)
            Exit Sub
        End Try




        Me.ConnectionString = myConnection.ConnectionString



        '0 - Public with DbColumns properties in a single line
        '1 - Private with DbColumns properties in a single line
        '2 - Public DbColumns properties Get - Set
        '3 - Public Properties Get - Set with private DbColumns
        '4 - POCO Class

        s = s & CommonClassBuilderHeader(DbObjectName, SQLCommandText, Me.cmbBuildOption.SelectedIndex, mPrefix)
        s = s & CommonClassBuilderColumns2(DbProvider, mySchemaTable, Me.cmbBuildOption.SelectedIndex, DbObjectType, DbObjectName)
        If (myParameters IsNot Nothing) Then
            s = s & CommonClassBuilderParameters(myParameters, Me.cmbBuildOption.SelectedIndex, DbParamenterPrefix)
        End If
        s = s & CommonClassBuilderConstructor(DbObjectName, SQLCommandText, mDBObjectType, Me.cmbBuildOption.SelectedIndex, mPrefix)



        DbObjectResult.Text = s
    End Sub

    Sub CommonClientClassBuilder(ByVal DbProvider As DbProviders, ByVal ConnectionString As String, ByVal DbObjectName As String, ByVal DbObjectType As Integer, ByVal SQLCommandText As String, ByRef DbObjectResult As TextBox, ByVal DbParamenterPrefix As String)

        If DbObjectName.Trim = "" Then Exit Sub
        Select Case DbObjectType
            Case DbObjectTypes.Table
                CommonClientTableClassBuilder(DbProvider, ConnectionString, DbObjectName, DbObjectType, SQLCommandText, DbObjectResult, DbParamenterPrefix)

            Case DbObjectTypes.View
                CommonClientViewClassBuilder(DbProvider, ConnectionString, DbObjectName, DbObjectType, SQLCommandText, DbObjectResult, DbParamenterPrefix)

            Case DbObjectTypes.SQLCommand
                CommonClientSQLCommandClassBuilder(DbProvider, ConnectionString, DbObjectName, DbObjectType, SQLCommandText, DbObjectResult, DbParamenterPrefix)

            Case DbObjectTypes.StoredProcedure
                CommonClientStoredProcedureClassBuilder(DbProvider, ConnectionString, DbObjectName, DbObjectType, SQLCommandText, DbObjectResult, DbParamenterPrefix)

            Case DbObjectTypes.TableFunction
                CommonClientTableFunctionClassBuilder(DbProvider, ConnectionString, DbObjectName, DbObjectType, SQLCommandText, DbObjectResult, DbParamenterPrefix)

            Case DbObjectTypes.ScalarFunction
                CommonClientScalarFunctionClassBuilder(DbProvider, ConnectionString, DbObjectName, DbObjectType, SQLCommandText, DbObjectResult, DbParamenterPrefix)

        End Select


    End Sub


    Function CommonClassBuilderHeader(ByVal DbObjectName As String, ByVal SQLCommandText As String, ByVal ConstructorType As Integer, ByVal Prefix As String)

        Dim s As String = ""

        Select Case Language
            Case = VBNET
                s = s + "'------------------------------------------------------------------------------" & vbCrLf
                s = s + "' Class Definition for Table/View: " & Prefix & DbObjectName & vbCrLf
                s = s + "' Date   :" & Now.Date.ToShortDateString & vbCrLf
                s = s + "' Author :" & vbCrLf
                s = s + "'------------------------------------------------------------------------------" & vbCrLf
                s = s + "Public Class " & Prefix & DbObjectName & vbCrLf

                Select Case ConstructorType
                    Case 0, 1, 2, 3
                        s = s + "    Inherits BasicDAL.DbObject" & vbCrLf
                    Case Else
                End Select



            Case = CS
                s = s + "//------------------------------------------------------------------------------" & vbCrLf
                s = s + "// Class Definition for Table/View: " & Prefix & DbObjectName & vbCrLf
                s = s + "// Date   :" & Now.Date.ToShortDateString & vbCrLf
                s = s + "// Author :" & vbCrLf
                s = s + "//------------------------------------------------------------------------------" & vbCrLf

                Select Case ConstructorType
                    Case 0, 1, 2, 3
                        s = s + "public class " & Prefix & DbObjectName & ":BasicDAL.DbObject" & vbCrLf & "{"
                    Case Else
                        s = s + "public class " & Prefix & DbObjectName & vbCrLf & "{"
                End Select

        End Select


        Return s

    End Function
    Function CommonClassBuilderColumns(ByVal SchemaTable As DataTable, ByVal DataTable As DataTable, ByVal ConstructorType As Integer) As String

        Dim ColumnName As String = ""
        Dim ss As String = ""
        Dim s As String = ""
        Dim a As String = Chr(34)
        Dim dv As DataView
        Dim r As DataRow
        Dim DBType As String = ""
        Dim DefaultValue As String
        Dim Column As DataColumn
        Dim typename As String = "BasicDAL.DbColumn"

        For Each Column In DataTable.Columns

            dv = New DataView(SchemaTable, "ColumnName='" & Column.ColumnName & "'", "", DataViewRowState.CurrentRows)
            r = dv.Item(0).Row
            DBType = "System.Data." & Utilities.GetDBType(r("DataType"))
            DefaultValue = Utilities.DBTypeGetDefaultValue(DBType)
            ColumnName = Replace(Column.ColumnName.ToLower, " ", "_")
            Select Case ConstructorType
                Case = 0
                    Select Case Language
                        Case VBNET
                            ss = "  Public " & ColumnName & " as New " & typename & "(" & a & "[" & Column.ColumnName & "]" & a & "," & DBType & "," & r("isKey").ToString().ToLower & "," & DefaultValue & ")"
                        Case CS
                            ss = "  public " & typename & ColumnName & " = new " & typename & "(" & a & "[" & Column.ColumnName & "]" & a & "," & DBType & "," & r("isKey").ToString().ToLower & "," & DefaultValue.ToLower & ");"
                    End Select
                Case = 1

                    Select Case Language
                        Case VBNET
                            ss = "  Private " & ColumnName & " as New " & typename & "(" & a & "[" & Column.ColumnName & "]" & a & "," & DBType & "," & r("isKey").ToString().ToLower & "," & DefaultValue & ")"
                        Case CS
                            ss = "  private " & typename & " " & ColumnName & " = new " & typename & "(" & a & "[" & Column.ColumnName & "]" & a & "," & DBType & "," & r("isKey").ToString().ToLower & "," & DefaultValue.ToLower & ");"
                    End Select

                Case = 2

                    Select Case Language
                        Case VBNET
                            ss = "  Private _" & ColumnName & " as New " & typename & "(" & a & "[" & Column.ColumnName & "]" & a & "," & DBType & "," & r("isKey").ToString().ToLower & "," & DefaultValue & ")"

                        Case CS
                            ss = "  private " & typename & " " & ColumnName & " = new " & typename & " (" & a & "[" & Column.ColumnName & "]" & a & "," & DBType & "," & r("isKey").ToString().ToLower & "," & DefaultValue.ToLower & ");"

                    End Select
            End Select




            s = s & ss & vbCrLf
        Next
        ss = ""


        Select Case ConstructorType
            Case = 2

                For Each Column In DataTable.Columns

                    dv = New DataView(SchemaTable, "ColumnName='" & Column.ColumnName & "'", "", DataViewRowState.CurrentRows)
                    r = dv.Item(0).Row
                    DBType = Utilities.GetDBType(r("DataType"))
                    DefaultValue = Utilities.DBTypeGetDefaultValue(DBType)
                    Select Case Language
                        Case VBNET
                            ss = ss & "Property " & Column.ColumnName.ToLower & "() As " & typename & vbCrLf
                            ss = ss & "   Get" & vbCrLf
                            ss = ss & "       " & Column.ColumnName.ToLower & " = _" & Column.ColumnName.ToLower & vbCrLf
                            ss = ss & "   End Get" & vbCrLf
                            ss = ss & "   Set (Byval value as " & typename & ") " & vbCrLf
                            ss = ss & "       " & Column.ColumnName.ToLower & " = _" & Column.ColumnName.ToLower & vbCrLf
                            ss = ss & "   End Get" & vbCrLf
                            ss = ss & "End Property" & vbCrLf
                        Case CS
                            ss = ss & "public " & typename & " " & Column.ColumnName.ToLower & vbCrLf
                            ss = ss & "{" & vbCrLf
                            ss = ss & "    get" '& vbCrLf
                            ss = ss & "    {" '& vbCrLf
                            ss = ss & "       return  _" & Column.ColumnName.ToLower & ";" '& vbCrLf
                            ss = ss & "    }" & vbCrLf
                            ss = ss & "    set" '& vbCrLf
                            ss = ss & "    {" '& vbCrLf
                            ss = ss & "        _" & Column.ColumnName.ToLower & " = value;" ' & vbCrLf
                            ss = ss & "    }" & vbCrLf
                            ss = ss & "}" & vbCrLf
                    End Select
                    ss = ss + vbCrLf
                Next
                s = s + vbCrLf + ss
        End Select


        Return s


    End Function


    Function CommonClassBuilderColumns2(ByVal DbProvider As DbProviders, ByVal SchemaTable As DataTable, ByVal ConstructorType As Integer, ByVal DbObjectType As DbObjectTypes, ByVal DbObjectName As String) As String


        If SchemaTable Is Nothing Then
            Return "" + vbCrLf
        End If

        Dim ColumnName As String = ""
        Dim ss As String = ""
        Dim s As String = ""
        Dim a As String = Chr(34)

        Dim DBType As String = ""
        Dim DefaultValue As String = "2"
        Dim PrimaryKey As String = "false"
        Dim DBColumnName As String = ""
        Dim _DbColumnName As String = ""
        Dim typename As String = "BasicDAL.DbColumn"
        Dim SupportBrackets As Boolean = False
        Dim LeftBracket As String = "["
        Dim RightBracket As String = "]"

        SupportBrackets = Utilities.GetDbProviderBrackets(DbProvider, LeftBracket, RightBracket)

        Select Case Language
            Case VBNET
                s = vbCrLf & "#Region ""DbColumns""" & vbCrLf
            Case CS
                s = vbCrLf & "#region 'DbColumns'" & vbCrLf
        End Select

        For Each DataRow As DataRow In SchemaTable.Rows

            DbObjectName = DbObjectName.Trim()
            DefaultValue = Utilities.DBTypeGetDefaultValue("DbType." & DataRow("DataType").Name)
            DBType = "System.Data.DbType." & (DataRow("DataType").Name)
            ColumnName = DataRow("ColumnName").ToLower()
            ColumnName = ColumnName.Replace(" ", "_")
            ColumnName = ColumnName.Replace(".", "_")
            ColumnName = ColumnName.Replace(Chr(34), "")
            DBColumnName = DataRow("ColumnName").ToString().Trim()

            Select Case DbProvider
                Case DbProviders.MYSQL
                    If DbObjectType = DbObjectTypes.ScalarFunction Then
                        If DBColumnName.ToLower().StartsWith(DbObjectName.ToLower()) Then
                            ColumnName = "RETURN_VALUE"
                            DBColumnName = "RETURN_VALUE"
                        End If
                    End If
                Case Else
                    If DBColumnName = "" Then DBColumnName = "RETURN_VALUE"
                    If ColumnName = "" Then ColumnName = "RETURN_VALUE"
            End Select


            If (SupportBrackets = True) Then

                If DBColumnName.Contains(" ") Then
                    _DbColumnName = LeftBracket + DBColumnName + RightBracket
                Else
                    _DbColumnName = DBColumnName
                End If
            Else
                _DbColumnName = DBColumnName
            End If


            If _DbColumnName.StartsWith(Chr(34)) Then
                Select Case Language
                    Case VBNET
                        _DbColumnName = Chr(34) + _DbColumnName + Chr(34)
                    Case CS
                        _DbColumnName = "\" + Chr(34) + _DbColumnName.Replace(Chr(34), "") + "\" + Chr(34)
                End Select


            End If

            If IsDBNull(DataRow("IsKey")) = False Then
                PrimaryKey = DataRow("IsKey")
            End If

            If DBType = "TimeSpan" Then
                DBType = "Time"
            End If

            PrimaryKey.ToLower()

            Select Case ConstructorType
                Case = 0
                    Select Case Language
                        Case VBNET
                            ss = "  Public DbC_" & ColumnName & " As New " & typename & "(" & a & _DbColumnName & a & "," & DBType & "," & PrimaryKey & "," & DefaultValue & ")Then"
                        Case CS
                            ss = "  public " & typename & " DbC_" & ColumnName & " = new " & typename & "(" & a & _DbColumnName & a & "," & DBType & "," & PrimaryKey.ToLower & "," & DefaultValue & ");"
                    End Select

                Case = 1

                    Select Case Language
                        Case VBNET
                            ss = "  Private DbC_" & ColumnName & " As New " & typename & "(" & a & _DbColumnName & a & "," & DBType & "," & PrimaryKey & "," & DefaultValue & ")"
                        Case CS
                            ss = "  private " & typename & " DbC_" & ColumnName & " = new " & typename & "(" & a & _DbColumnName & a & "," & DBType & "," & PrimaryKey.ToLower & "," & DefaultValue & ");"
                    End Select

                Case = 2, 3

                    Select Case Language
                        Case VBNET
                            ss = "  Private _DbC_" & ColumnName & " As New " & typename & "(" & a & _DbColumnName & a & "," & DBType & "," & PrimaryKey & "," & DefaultValue & ")"

                        Case CS
                            ss = "  private " & typename & " _DbC_" & ColumnName & " = new " & typename & "( " & a & _DbColumnName & a & "," & DBType & "," & PrimaryKey.ToLower & "," & DefaultValue & ");"

                    End Select

                Case = 4

                    Dim _typename = Utilities.DBTypeToSystemType(DataRow("DataType").Name)
                    Select Case Language
                        Case VBNET
                            ss = "  Private _DbC_" & ColumnName & " As New " & _typename & ";"

                        Case CS
                            ss = "  private " & _typename & " _DbC_" & ColumnName & " = new " & _typename & "();"
                    End Select
            End Select

            s = s & ss & vbCrLf
        Next
        ss = ""


        Select Case ConstructorType
            Case = 2

                For Each DataRow As DataRow In SchemaTable.Rows

                    'DBType = "System.Data." & SQLCLientGetDBType(DataRow("DataType"))
                    'DefaultValue = Me.SQLClientGetDefaultValue(DBType)
                    'DBColumnName = DataRow("ColumnName")
                    ColumnName = Replace(DataRow("ColumnName").ToLower, " ", "_")

                    Select Case Language
                        Case VBNET
                            ss = ss & "Property DbC_" & ColumnName & "() As " & typename & vbCrLf
                            ss = ss & "   Get" & vbCrLf
                            ss = ss & "       DbC_" & ColumnName & " = _DbC_" & ColumnName.ToLower & vbCrLf
                            ss = ss & "   End Get" & vbCrLf
                            ss = ss & "   Set (ByVal value As " & typename & ") " & vbCrLf
                            ss = ss & "       _DbC_" & ColumnName & " = _DbC_" & ColumnName.ToLower & vbCrLf
                            ss = ss & "   End Set" & vbCrLf
                            ss = ss & "End Property" & vbCrLf
                        Case CS
                            ss = ss & "public " & typename & " DbC_" & ColumnName & vbCrLf
                            ss = ss & "{" & vbCrLf
                            ss = ss & "    get" '& vbCrLf
                            ss = ss & "    {" '& vbCrLf
                            ss = ss & "       return  _DbC_" & ColumnName & ";" '& vbCrLf
                            ss = ss & "    }" & vbCrLf
                            ss = ss & "    set" '& vbCrLf
                            ss = ss & "    {" '& vbCrLf
                            ss = ss & "        _DbC_" & ColumnName & " = value;" ' & vbCrLf
                            ss = ss & "    }" & vbCrLf
                            ss = ss & "}" & vbCrLf
                    End Select
                    ss = ss + vbCrLf
                Next
                s = s + vbCrLf + ss


            Case = 3
                For Each DataRow As DataRow In SchemaTable.Rows

                    ColumnName = Replace(DataRow("ColumnName").ToLower, " ", "_")
                    Dim _typename As String = Utilities.DBTypeToSystemType(DataRow("DataType").Name)
                    Dim _shorttypename As String = _typename.Replace("System.", "")
                    Select Case Language
                        Case VBNET
                            ss = ss & "Property DbC_" & ColumnName & "() As " & _typename & vbCrLf
                            ss = ss & "   Get" & vbCrLf
                            ss = ss & "       DbC_" & ColumnName & " = Convert.To" & _shorttypename & "(_DbC_" & ColumnName.ToLower & ".Value)" & vbCrLf
                            ss = ss & "   End Get" & vbCrLf
                            ss = ss & "   Set (ByVal Value As " & _typename & ") " & vbCrLf
                            ss = ss & "       _DbC_" & ColumnName & ".Value = Value" & vbCrLf
                            ss = ss & "   End Set" & vbCrLf
                            ss = ss & "End Property" & vbCrLf
                        Case CS
                            ss = ss & "public " & _typename & " DbC_" & ColumnName & vbCrLf
                            ss = ss & "{" & vbCrLf
                            ss = ss & "    get" '& vbCrLf
                            ss = ss & "    {" '& vbCrLf
                            ss = ss & "       return  Convert.To" & _shorttypename & "(_DbC_" & ColumnName & ".Value);" '& vbCrLf
                            ss = ss & "    }" & vbCrLf
                            ss = ss & "    set" '& vbCrLf
                            ss = ss & "    {" '& vbCrLf
                            ss = ss & "        _DbC_" & ColumnName & ".Value = value;" ' & vbCrLf
                            ss = ss & "    }" & vbCrLf
                            ss = ss & "}" & vbCrLf
                    End Select
                    ss = ss + vbCrLf
                Next
                s = s + vbCrLf + ss

            Case = 4
                For Each DataRow As DataRow In SchemaTable.Rows
                    ColumnName = Replace(DataRow("ColumnName").ToLower, " ", "_")
                    Dim _typename = Utilities.DBTypeToSystemType(DataRow("DataType").Name)
                    Select Case Language
                        Case VBNET
                            ss = ss & "Property DbC_" & ColumnName & "() As " & _typename & vbCrLf
                            ss = ss & "   Get" & vbCrLf
                            ss = ss & "       DbC_" & ColumnName & " = _DbC_" & ColumnName.ToLower & vbCrLf
                            ss = ss & "   End Get" & vbCrLf
                            ss = ss & "   Set (ByVal Value As " & typename & ") " & vbCrLf
                            ss = ss & "       _DbC_" & ColumnName & "= Value" & vbCrLf
                            ss = ss & "   End Set" & vbCrLf
                            ss = ss & "End Property" & vbCrLf
                        Case CS
                            ss = ss & "public " & _typename & " DbC_" & ColumnName & vbCrLf
                            ss = ss & "{" & vbCrLf
                            ss = ss & "    get" '& vbCrLf
                            ss = ss & "    {" '& vbCrLf
                            ss = ss & "       return _DbC_" & ColumnName & ";" '& vbCrLf
                            ss = ss & "    }" & vbCrLf
                            ss = ss & "    set" '& vbCrLf
                            ss = ss & "    {" '& vbCrLf
                            ss = ss & "        _DbC_" & ColumnName & "= value;" ' & vbCrLf
                            ss = ss & "    }" & vbCrLf
                            ss = ss & "}" & vbCrLf
                    End Select
                    ss = ss + vbCrLf
                Next
                s = s + vbCrLf + ss
        End Select

        Select Case Language
            Case VBNET
                s = s & "#End Region" & vbCrLf
            Case CS
                s = s & "#endregion" & vbCrLf
        End Select


        Return s


    End Function


    Function CommonClassBuilderParametersOLD(ByVal MyParameters As System.Data.SqlClient.SqlParameterCollection, ByVal ConstructorType As String) As String


        If MyParameters.Count = 0 Then Return vbCrLf


        Dim ColumnName As String = ""
        Dim ss As String = ""
        Dim s As String = ""
        Dim a As String = Chr(34)

        Dim DBType As String = ""
        Dim DefaultValue As String

        Dim typename As String = "BasicDAL.DbParameter"

        Dim Direction As String


        Select Case Language
            Case VBNET
                s = vbCrLf & "#region ""DbParameters""" & vbCrLf
            Case CS
                s = s & "#region 'DbParameters'" & vbCrLf
        End Select




        For Each Parameter As SqlClient.SqlParameter In MyParameters


            DBType = "System.Data.DbType." & Parameter.DbType.ToString
            DefaultValue = Parameter.Value
            Direction = "System.Data.ParameterDirection." & Parameter.Direction.ToString()
            Dim pname As String = ""
            pname = Replace(Parameter.ParameterName.ToLower, " ", "_")
            pname = Replace(Parameter.ParameterName.ToLower, "@", "sp_")

            Select Case ConstructorType
                Case = "0"
                    Select Case Language
                        Case VBNET
                            ss = "  Public " & pname & " As New " & typename & "(" & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ")"
                        Case CS
                            ss = "  public " & typename & " " & pname & " = new " & typename & "(" & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ");"
                    End Select
                Case = "1"

                    Select Case Language
                        Case VBNET
                            ss = "  Private " & pname & " As New " & typename & " " & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ")"
                        Case CS
                            ss = "  private " & typename & " " & pname & " = new " & typename & "(" & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ");"
                    End Select

                Case = "2"

                    Select Case Language
                        Case VBNET
                            ss = "  Public " & pname & " As New " & typename & "(" & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ")"

                        Case CS
                            ss = "  public " & typename & " " & pname & " = new " & typename & "(" & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ");"


                    End Select
            End Select




            s = s & ss & vbCrLf
        Next
        ss = ""


        Select Case ConstructorType
            'Case = "2"

            '    For Each Column In DataTable.Columns

            '        dv = New DataView(SchemaTable, "ColumnName='" & Column.ColumnName & "'", "", DataViewRowState.CurrentRows)
            '        r = dv.Item(0).Row
            '        DBType = SQLCLientGetDBType(r("DataType"))
            '        DefaultValue = Me.SQLClientGetDefaultValue(DBType)
            '        Select Case Language
            '            Case VBNET
            '                ss = ss & "Property " & Column.ColumnName.ToLower & "() As BasicDAL.DbColumn" & vbCrLf
            '                ss = ss & "   Get" & vbCrLf
            '                ss = ss & "       " & Column.ColumnName.ToLower & " = _" & Column.ColumnName.ToLower & vbCrLf
            '                ss = ss & "   End Get" & vbCrLf
            '                ss = ss & "   Set (Byval value as BasicDAL.DbColumn) " & vbCrLf
            '                ss = ss & "       " & Column.ColumnName.ToLower & " = _" & Column.ColumnName.ToLower & vbCrLf
            '                ss = ss & "   End Get" & vbCrLf
            '                ss = ss & "End Property" & vbCrLf
            '            Case CS
            '                ss = ss & "public BasicDAL.DbColumn " & Column.ColumnName.ToLower & vbCrLf
            '                ss = ss & "{" & vbCrLf
            '                ss = ss & "    get" '& vbCrLf
            '                ss = ss & "    {" '& vbCrLf
            '                ss = ss & "       return  _" & Column.ColumnName.ToLower & ";" '& vbCrLf
            '                ss = ss & "    }" & vbCrLf
            '                ss = ss & "    set" '& vbCrLf
            '                ss = ss & "    {" '& vbCrLf
            '                ss = ss & "        _" & Column.ColumnName.ToLower & " = value;" ' & vbCrLf
            '                ss = ss & "    }" & vbCrLf
            '                ss = ss & "}" & vbCrLf
            '        End Select
            '        ss = ss + vbCrLf
            '    Next
            '    s = s + vbCrLf + ss
        End Select



        Select Case Language
            Case VBNET
                s = s & "#End Region" & vbCrLf
            Case CS
                s = s & "#endregion" & vbCrLf
        End Select


        Return s


    End Function

    Function CommonClassBuilderParameters(ByVal MyParameters As System.Data.Common.DbParameterCollection, ByVal ConstructorType As String, ByVal DbParameterPrefix As String) As String


        If MyParameters.Count = 0 Then Return vbCrLf


        Dim ColumnName As String = ""
        Dim ss As String = ""
        Dim s As String = ""
        Dim a As String = Chr(34)

        Dim DBType As String = ""
        Dim DefaultValue As Object = vbNull

        Dim typename As String = "BasicDAL.DbParameter"

        Dim Direction As String


        Select Case Language
            Case VBNET
                s = vbCrLf & "#region ""DbParameters""" & vbCrLf
            Case CS
                s = s & "#region 'DbParameters'" & vbCrLf
        End Select




        For Each Parameter As System.Data.Common.DbParameter In MyParameters


            DBType = "System.Data.DbType." & Parameter.DbType.ToString

            DefaultValue = Parameter.Value
            Direction = "System.Data.ParameterDirection." & Parameter.Direction.ToString()
            Dim pname As String = ""
            pname = Replace(Parameter.ParameterName.ToLower, " ", "_")
            'pname = Replace(Parameter.ParameterName.ToLower, DbParameterPrefix, "DbP_")

            If pname.StartsWith(DbParameterPrefix) Then
                pname = pname.Substring(1)
            End If
            pname = "DbP_" & pname

            Select Case ConstructorType
                Case = "0"
                    Select Case Language
                        Case VBNET
                            ss = "  Public " & pname & " As New " & typename & "(" & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ")"
                        Case CS
                            ss = "  public " & typename & " " & pname & " = new " & typename & "(" & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ");"
                    End Select
                Case = "1"

                    Select Case Language
                        Case VBNET
                            ss = "  Private " & pname & " As New " & typename & " " & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ")"
                        Case CS
                            ss = "  private " & typename & " " & pname & " = new " & typename & "(" & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ");"
                    End Select

                Case = "2"

                    Select Case Language
                        Case VBNET
                            ss = "  Public " & pname & " As New " & typename & "(" & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ")"

                        Case CS
                            ss = "  public " & typename & " " & pname & " = new " & typename & "(" & a & "" & Parameter.ParameterName & "" & a & "," & DBType & "," & Direction & "," & Parameter.Size & ");"


                    End Select
            End Select




            s = s & ss & vbCrLf
        Next
        ss = ""


        Select Case ConstructorType
            'Case = "2"

            '    For Each Column In DataTable.Columns

            '        dv = New DataView(SchemaTable, "ColumnName='" & Column.ColumnName & "'", "", DataViewRowState.CurrentRows)
            '        r = dv.Item(0).Row
            '        DBType = SQLCLientGetDBType(r("DataType"))
            '        DefaultValue = Me.SQLClientGetDefaultValue(DBType)
            '        Select Case Language
            '            Case VBNET
            '                ss = ss & "Property " & Column.ColumnName.ToLower & "() As BasicDAL.DbColumn" & vbCrLf
            '                ss = ss & "   Get" & vbCrLf
            '                ss = ss & "       " & Column.ColumnName.ToLower & " = _" & Column.ColumnName.ToLower & vbCrLf
            '                ss = ss & "   End Get" & vbCrLf
            '                ss = ss & "   Set (Byval value as BasicDAL.DbColumn) " & vbCrLf
            '                ss = ss & "       " & Column.ColumnName.ToLower & " = _" & Column.ColumnName.ToLower & vbCrLf
            '                ss = ss & "   End Get" & vbCrLf
            '                ss = ss & "End Property" & vbCrLf
            '            Case CS
            '                ss = ss & "public BasicDAL.DbColumn " & Column.ColumnName.ToLower & vbCrLf
            '                ss = ss & "{" & vbCrLf
            '                ss = ss & "    get" '& vbCrLf
            '                ss = ss & "    {" '& vbCrLf
            '                ss = ss & "       return  _" & Column.ColumnName.ToLower & ";" '& vbCrLf
            '                ss = ss & "    }" & vbCrLf
            '                ss = ss & "    set" '& vbCrLf
            '                ss = ss & "    {" '& vbCrLf
            '                ss = ss & "        _" & Column.ColumnName.ToLower & " = value;" ' & vbCrLf
            '                ss = ss & "    }" & vbCrLf
            '                ss = ss & "}" & vbCrLf
            '        End Select
            '        ss = ss + vbCrLf
            '    Next
            '    s = s + vbCrLf + ss
        End Select



        Select Case Language
            Case VBNET
                s = s & "#End Region" & vbCrLf
            Case CS
                s = s & "#endregion" & vbCrLf
        End Select


        Return s


    End Function


    Function CommonClassBuilderConstructor(ByVal DbObject As String, ByVal SQLCommandText As String, ByVal DBobjectType As String, ByVal InterfaceModeType As Integer, ByVal Prefix As String)

        Dim s As String = ""
        Dim a As String = Chr(34)
        Dim _InterfaceModeType As String = ""

        Select Case InterfaceModeType
            Case = 0
                _InterfaceModeType = "BasicDAL.InterfaceModeEnum.Public"
            Case = 1
                _InterfaceModeType = "BasicDAL.InterfaceModeEnum.Private"
            Case = 2
                _InterfaceModeType = "BasicDAL.InterfaceModeEnum.Private"
            Case = 3
                _InterfaceModeType = "BasicDAL.InterfaceModeEnum.Private"

        End Select



        Select Case Language
            Case VBNET

                Select Case InterfaceModeType
                    Case 4
                        s = s & "Sub New()" & vbCrLf
                        s = s & "End Sub" & vbCrLf

                    Case Else

                        s = s & "Sub New()" & vbCrLf
                        Dim _sql As String = ""
                        _sql = Replace(DbObject, Chr(34), "'")
                        _sql = Replace(_sql, Chr(13), "")
                        s = s & "   Me.InterfaceMode =  " & _InterfaceModeType & vbCrLf
                        s = s & "   Me.DbObjectType=" & DBobjectType & vbCrLf
                        Select Case DBobjectType
                            Case mDBObjecTypeTABLE, mDBObjecTypeVIEW
                                s = s & "   Me.DbTableName=" & a & SQLCommandText & a & vbCrLf
                            Case mDBObjecTypeStoredProcedure
                                s = s & "   Me.DbStoredProcedureName=" & a & SQLCommandText & a & vbCrLf
                            Case mDBObjecTypeTableFunction
                                s = s & "   Me.DbFunctionName=" & a & SQLCommandText & a & vbCrLf
                            Case mDBObjecTypeScalarFunction
                                s = s & "   Me.DbFunctionName=" & a & SQLCommandText & a & vbCrLf
                            Case = mDBObjecTypeSQL
                                s = s & "   Me.DbTableName=" & a & DbObject & a & vbCrLf
                                s = s & "   Me.SQLQuery=" & a & _sql & a & vbCrLf
                        End Select

                        s = s & "End Sub" & vbCrLf


                End Select

                s = s & "End Class" & vbCrLf
                s = s & "'------------------------------------------------------------------------------" & vbCrLf


            Case CS
                Select Case InterfaceModeType
                    Case 4
                        s = s & vbCrLf
                        s = s & "   public " + Prefix & DbObject & "()" & vbCrLf
                        s = s + "   {" + vbCrLf + "}"

                    Case Else

                        s = s & vbCrLf
                        s = s & "   public " + Prefix & DbObject & "()" & vbCrLf


                        Dim _sql As String = ""
                        _sql = Replace(SQLCommandText, Chr(34), "'")
                        _sql = Replace(_sql, Chr(13), "")

                        s = s + "   {" + vbCrLf
                        s = s & "   this.InterfaceMode =  " & _InterfaceModeType & ";" & vbCrLf
                        s = s & "   this.DbObjectType = " & DBobjectType & ";" & vbCrLf
                        Select Case DBobjectType
                            Case mDBObjecTypeTABLE, mDBObjecTypeVIEW
                                s = s & "   this.DbTableName=" & a & SQLCommandText & a & ";" & vbCrLf
                            Case mDBObjecTypeStoredProcedure
                                s = s & "   this.DbStoredProcedureName=" & a & SQLCommandText & a & ";" & vbCrLf
                            Case mDBObjecTypeTableFunction, mDBObjecTypeScalarFunction
                                s = s & "   this.DbFunctionName=" & a & SQLCommandText & a & ";" & vbCrLf
                            Case = mDBObjecTypeSQL
                                s = s & "   this.DbTableName=" & a & DbObject & a & ";" & vbCrLf
                                s = s & "   this.SQLQuery=" & a & _sql & a & ";" & vbCrLf
                        End Select
                        s = s & "   }" & vbCrLf

                End Select
                s = s & "}" & vbCrLf
                s = s & "//------------------------------------------------------------------------------" & vbCrLf

        End Select



        Return s

    End Function







    Function SQLCreateTable(ByVal SchemaTable As DataTable, ByVal DataTable As DataTable) As String

        Dim ColumnName As String = ""
        Dim ss As String = ""
        Dim s As String = ""
        Dim a As String = Chr(34)
        Dim i As Integer = 0
        Dim dv As DataView
        Dim DBType As String = ""
        Dim Column As DataColumn

        Dim SQL As String = "CREATE TABLE " & DataTable.TableName & " ("



        For Each Column In DataTable.Columns

            'Dim _Name As String
            'Dim _DataType As String
            'Dim _OrdinalPosition As Integer
            'Dim _isNullable As String
            'Dim _MaxLength As String
            'Dim _MaxLengthFormatted As String


            dv = New DataView(SchemaTable, "ColumnName='" & Column.ColumnName & "'", "", DataViewRowState.CurrentRows)
            Dim x As String = ""
            Dim xx As Integer = 0
            For xx = 0 To dv.Table.Columns.Count - 1
                Dim c As DataColumn
                c = dv.Table.Columns(xx)
                x = x & c.ColumnName & " - " & xx & vbCrLf
            Next

            Me.OracleResult.Text = x

            'r = dv.Item(0).Row
            'DBType = SQLCLientGetDBType(r("DataType"))
            'DefaultValue = Me.SQLClientGetDefaultValue(DBType)

            '_Name = dv("COLUMN_NAME").ToString()
            '_DataType = dv("DATA_TYPE").ToString()
            '_OrdinalPosition = CInt(Fix(dv("ORDINAL_POSITION")))
            '_isNullable = dv("IS_NULLABLE").ToString = "YES"
            '_MaxLength = dv("CHARACTER_MAXIMUM_LENGTH").ToString

            '_MaxLengthFormatted = If(_MaxLength.Equals("-1"), "max", _MaxLength)

            ''ss = "  Public " & Replace(Column.ColumnName, " ", "_") & " as New BasicDAL.DBColumn(" & a & "" & Column.ColumnName & "" & a & "," & DBType & "," & r("isKey") & "," & DefaultValue & ")"
            'ss = String.Format("[{0}] {1}{2} {3}NULL", _Name, _DataType, If(_MaxLength = String.Empty, "", "(" & _MaxLengthFormatted & ")"), If(_isNullable, "", "NOT "))
            'SQL = SQL & ss



            's = s & ss & vbCrLf
        Next

        Return s
    End Function

    'Private Sub XXXX()
    '    Using connection = New SqlConnection(connectionString)
    '        Dim command = connection.CreateCommand()
    '        ' This will return the table schema information
    '        command.CommandText = "select * from information_schema.columns where table_name = @tableName"
    '        command.Parameters.Add("@tableName", SqlDbType.VarChar).Value = "MyTable"
    '        command.CommandType = CommandType.Text

    '        connection.Open()
    '        Dim columnList = New List(Of ColumnInfo)()
    '        ' Loop over the results and create a ColumnInfo object for each Column in the schema.
    '        Using reader As IDataReader = command.ExecuteReader(CommandBehavior.KeyInfo)
    '            Do While reader.Read()
    '                columnList.Add(New ColumnInfo().ReadFromReader(reader))
    '            Loop
    '        End Using

    '        Dim createTempCommand As String = "create table {0} ({1})"
    '        Dim sb As New StringBuilder()
    '        ' Loop over each column info object and construct the string needed for the SQL script.
    '        For Each column In columnList
    '            sb.Append(column.ToString())
    '        Next column

    '        ' create temp table
    '        command.CommandText = String.Format(createTempCommand, "#TempTable", String.Join(",", columnList.Select(Function(c) c.ToString()).ToArray()))
    '        command.ExecuteNonQuery()

    '        Using bulkCopy As New SqlBulkCopy(connection)
    '            bulkCopy.DestinationTableName("#TempTable")
    '            bulkCopy.WriteToServer(readerWithData)
    '        End Using
    '    End Using
    'End Sub




    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.cmbBuildOption.SelectedIndex = 0
        Me.cmbLanguage.SelectedIndex = 0

        Me.SQLDBObjectType.SelectedIndex = 0
        Me.OLEDBDBObjectType.SelectedIndex = 0
        Me.OLEDBDB2DbObjectType.SelectedIndex = 0
        Me.ODBCDBObjectType.SelectedIndex = 0
        Me.OracleDBObjectType.SelectedIndex = 0
        Me.cmd_DB2ISeries_DbObjectType.SelectedIndex = 0
        Me.MySQLDBObjectType.SelectedIndex = 0

        Me.SQLClientParameterStyle.SelectedIndex = 1
        Me.cmb_DB2iSeries_ParameterStyle.SelectedIndex = 1
        Me.cmb_MySQLParameterStyle.SelectedIndex = 1




    End Sub

    Private Sub OLEDBBuild_Click(sender As System.Object, e As System.EventArgs) Handles OLEDBBuild.Click
        OLEDBBuildClass()

    End Sub

    Private Sub ODBCBuild_Click(sender As System.Object, e As System.EventArgs) Handles ODBCBuild.Click
        Me.ConnectionString = ""
        ODBCBuildClass()

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        ShowCOnnectionStringDialog()


    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click

        ShowCOnnectionStringDialog()

    End Sub
    Public Sub ShowCOnnectionStringDialog()

        Dim x As String = ""
        Select Case Me.CurrentDbProvider
            Case DbProviders.DB2ISERIES
                x = Utilities.GetDB2iSeriesConnectionString(Me.txt_DB2ISeries_ConnectionString.Text, Me.txt_DB2ISeries_ServerName.Text, Me.txt_DB2ISeries_UserName.Text, Me.txt_DB2ISeries_Password.Text, Me.txt_DB2ISeries_LibraryList.Text)
            Case DbProviders.MYSQL
                x = Utilities.GetMySQLCLientConnectionString(Me.txt_MySQLConnectionString.Text, Me.txt_MySQLServerName.Text, Me.txt_MySQLDataBaseName.Text, Me.txt_MySQLPort.Text, Me.txt_MySQLUserName.Text, Me.txt_MySQLPassword.Text)
            Case DbProviders.ODBC
            Case DbProviders.ODBCDB2
            Case DbProviders.OLEDB
            Case DbProviders.OLEDBDB2
                x = Utilities.GetOLEDBDB2ConnectionString(Me.OLEDBConnectionString.Text, Me.OLEDBDB2ServerName.Text, Me.OLEDBDB2UserName.Text, Me.OLEDBDB2Password.Text, Me.OLEDBDB2InitialCatalog.Text, Me.OLEDBDB2LibraryList.Text)
            Case DbProviders.ORACLE
            Case DbProviders.SQLSERVER
                x = Utilities.GetSQLCLientConnectionString(Me.SQLClientConnectionString.Text, Me.SQLClientAuthenticationMode.Checked, Me.SQLClientDatabase.Text, Me.SQLCLientServer.Text, Me.SQLClientUserName.Text, Me.SQLClientPassword.Text)
            Case Else



        End Select

        frmConnectionString.txtConnectionString.Text = x
        frmConnectionString.ShowDialog()


    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles OracleBuild.Click
        OracleBuildClass()
    End Sub



    Private Sub OLEDBDB2Build_Click(sender As System.Object, e As System.EventArgs) Handles OLEDBDB2Build.Click
        Me.OLEDBDB2BuildClass()

    End Sub

    'Public Sub GetCreateTableSQL() as string
    '    Using connection = New SqlConnection(connectionString)
    '        Dim command = connection.CreateCommand()
    '        ' This will return the table schema information

    '        connection.Open()
    '        Dim columnList = New List(Of ColumnInfo)()
    '        ' Loop over the results and create a ColumnInfo object for each Column in the schema.
    '        Using reader As IDataReader = command.ExecuteReader(CommandBehavior.KeyInfo)
    '            Do While reader.Read()
    '                columnList.Add(New ColumnInfo().ReadFromReader(reader))
    '            Loop
    '        End Using

    '        Dim createTempCommand As String = "create table {0} ({1})"
    '        Dim sb As New StringBuilder()
    '        ' Loop over each column info object and construct the string needed for the SQL script.
    '        For Each column In columnList
    '            sb.Append(column.ToString())
    '        Next column


    '    End Using
    'End Sub
    Private Sub OracleUsername_TextChanged(sender As System.Object, e As System.EventArgs) Handles OracleUsername.TextChanged

    End Sub


    Private Sub OracleShowConnectionString_Click(sender As System.Object, e As System.EventArgs) Handles OracleShowConnectionString.Click
        Me.ShowCOnnectionStringDialog()

    End Sub

    Private Sub cmbLanguage_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbLanguage.SelectedIndexChanged
        Me.Language = Me.cmbLanguage.SelectedItem
    End Sub

    Private Sub btnSQLServerSchema_Click(sender As Object, e As EventArgs) Handles btnSQLServerSchema.Click

        Dim SQLClientConnection As System.Data.SqlClient.SqlConnection
        Dim DbConnection As System.Data.Common.DbConnection

        Try
            Dim ConnectionString As String = Utilities.GetSQLCLientConnectionString(Me.SQLClientConnectionString.Text, Me.SQLClientAuthenticationMode.Checked, Me.SQLClientDatabase.Text, Me.SQLCLientServer.Text, Me.SQLClientUserName.Text, Me.SQLClientPassword.Text)
            SQLClientConnection = New SqlConnection(ConnectionString)
            DbConnection = SQLClientConnection
            frmSchema.ParameterPrefix = Me.SQLClientParameterPrefix.Text
            frmSchema.ParameterStyle = Me.SQLClientParameterStyle.SelectedIndex
            frmSchema.SchemaSeparator = Me.SQLClientSchemaSeparator.Text
            frmSchema.UseBrackets = True
            frmSchema.DbProvider = DbProviders.SQLSERVER
            frmSchema.DbObjectType = Me.SQLDBObjectType.SelectedIndex
            frmSchema.DbConnection = DbConnection
            frmSchema.DbObjectNameTextBox = Me.SQLClientObjectName
            frmSchema.DbObjectCommandTextBox = Me.SQLCLientCommandText
            frmSchema.LoadSchema()
            frmSchema.Show()
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try


    End Sub

    Private Sub btnOracle_Schema_Click(sender As Object, e As EventArgs) Handles btnOracle_Schema.Click

        Dim OracleConnection As Oracle.ManagedDataAccess.Client.OracleConnection
        Dim DbConnection As System.Data.Common.DbConnection

        Try
            OracleConnection = New Oracle.ManagedDataAccess.Client.OracleConnection(Utilities.GetOracleConnectionString(Me.OracleServerName.Text, Me.OracleUsername.Text, Me.OraclePassword.Text, Me.chkORACLEDEDICATEDSERVER.Checked, Me.chkORACLEUSESID.Checked, Me.OracleServiceName.Text, Me.OraclePort.Text))
            DbConnection = OracleConnection

            frmSchema.ParameterPrefix = "@"
            frmSchema.ParameterStyle = 1
            frmSchema.SchemaSeparator = "."
            frmSchema.UseBrackets = True
            frmSchema.DbProvider = DbProviders.ORACLE
            frmSchema.DbObjectType = Me.ODBCDBObjectType.SelectedIndex
            frmSchema.DbConnection = DbConnection
            frmSchema.DbObjectNameTextBox = Me.OracleObjectName
            frmSchema.DbObjectCommandTextBox = Me.OracleCommandText
            frmSchema.LoadSchema()

            frmSchema.Show()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub

    Private Sub btnOLEDB_Schema_Click(sender As Object, e As EventArgs) Handles btnOLEDB_Schema.Click
        Dim OleDbConnection As OleDb.OleDbConnection
        Dim DbConnection As System.Data.Common.DbConnection

        Try
            OleDbConnection = New OleDb.OleDbConnection(Me.OLEDBConnectionString.Text)
            DbConnection = OleDbConnection
            frmSchema.ParameterPrefix = Me.txt_DB2iSeries_ParameterPrefix.Text
            frmSchema.ParameterStyle = Me.cmb_DB2iSeries_ParameterStyle.SelectedIndex
            frmSchema.SchemaSeparator = Me.txt_DB2iSeries_SchemaSeparator.Text
            frmSchema.UseBrackets = False
            frmSchema.DbProvider = DbProviders.DB2ISERIES
            frmSchema.DbObjectType = Me.cmd_DB2ISeries_DbObjectType.SelectedIndex
            frmSchema.DbConnection = DbConnection
            frmSchema.DbObjectNameTextBox = Me.txt_DB2ISeries_ObjecName
            frmSchema.DbObjectCommandTextBox = Me.txt_DB2ISeries_CommandText
            frmSchema.LoadSchema()

            frmSchema.Show()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub

    Private Sub btn_OLEDBDB2_Schema_Click(sender As Object, e As EventArgs) Handles btn_OLEDBDB2_Schema.Click
        Dim OleDbConnection As OleDb.OleDbConnection
        Dim DbConnection As System.Data.Common.DbConnection
        Dim ConnectionString As String = ""
        Try
            ConnectionString = Utilities.GetOLEDBDB2ConnectionString(Me.OLEDBDB2ConnectionString.Text, Me.OLEDBDB2ServerName.Text, Me.OLEDBDB2UserName.Text, Me.OLEDBDB2Password.Text, Me.OLEDBDB2InitialCatalog.Text, Me.OLEDBDB2LibraryList.Text)
            OleDbConnection = New OleDb.OleDbConnection(ConnectionString)
            DbConnection = OleDbConnection
            frmSchema.ParameterPrefix = Me.txt_DB2iSeries_ParameterPrefix.Text
            frmSchema.ParameterStyle = Me.cmb_DB2iSeries_ParameterStyle.SelectedIndex
            frmSchema.SchemaSeparator = Me.txt_DB2iSeries_SchemaSeparator.Text
            frmSchema.UseBrackets = False
            frmSchema.DbProvider = DbProviders.DB2ISERIES
            frmSchema.DbObjectType = Me.cmd_DB2ISeries_DbObjectType.SelectedIndex
            frmSchema.DbConnection = DbConnection
            frmSchema.DbObjectNameTextBox = Me.txt_DB2ISeries_ObjecName
            frmSchema.DbObjectCommandTextBox = Me.txt_DB2ISeries_CommandText
            frmSchema.LoadSchema()
            frmSchema.Show()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub


    Private Sub btn_IBMISERIES_Click(sender As Object, e As EventArgs) Handles btn_IBMISERIESSchema.Click

        Dim DB2Connection As IBM.Data.DB2.iSeries.iDB2Connection = Nothing
        Dim DbConnection As System.Data.Common.DbConnection
        Dim ConnectionString As String = ""
        Try

            ConnectionString = Utilities.GetDB2iSeriesConnectionString(Me.txt_DB2ISeries_ConnectionString.Text, Me.txt_DB2ISeries_ServerName.Text, Me.txt_DB2ISeries_UserName.Text, Me.txt_DB2ISeries_Password.Text, Me.txt_DB2ISeries_LibraryList.Text)
            DB2Connection = New IBM.Data.DB2.iSeries.iDB2Connection(ConnectionString)
            DB2Connection.Open()
            DbConnection = DB2Connection


            frmSchema.ParameterPrefix = Me.txt_DB2iSeries_ParameterPrefix.Text
            frmSchema.ParameterStyle = Me.cmb_DB2iSeries_ParameterStyle.SelectedIndex
            frmSchema.SchemaSeparator = Me.txt_DB2iSeries_SchemaSeparator.Text
            frmSchema.UseBrackets = False
            frmSchema.DbProvider = DbProviders.DB2ISERIES
            frmSchema.DbObjectType = Me.cmd_DB2ISeries_DbObjectType.SelectedIndex
            frmSchema.DbConnection = DbConnection
            frmSchema.DbObjectNameTextBox = Me.txt_DB2ISeries_ObjecName
            frmSchema.DbObjectCommandTextBox = Me.txt_DB2ISeries_CommandText
            frmSchema.DB2iSeriesLibraryList = Me.txt_DB2ISeries_LibraryList.Text
            frmSchema.LoadSchema()
            frmSchema.Show()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub

    Private Sub btn_MySQLSchema_Click(sender As Object, e As EventArgs) Handles btn_MySQLSchema.Click

        Dim MySQLClientConnection As MySql.Data.MySqlClient.MySqlConnection
        Dim DbConnection As System.Data.Common.DbConnection

        Try
            Dim ConnectionString As String = Utilities.GetMySQLCLientConnectionString(Me.txt_MySQLConnectionString.Text, Me.txt_MySQLServerName.Text, Me.txt_MySQLDataBaseName.Text, Me.txt_MySQLPort.Text, txt_MySQLUserName.Text, Me.txt_MySQLPassword.Text)
            MySQLClientConnection = New MySql.Data.MySqlClient.MySqlConnection(ConnectionString)
            DbConnection = MySQLClientConnection
            frmSchema.ParameterPrefix = Me.txt_MySQLParameterPrefix.Text
            frmSchema.ParameterStyle = Me.cmb_MySQLParameterStyle.SelectedIndex
            frmSchema.SchemaSeparator = Me.txt_MySQLSchemaSeparator.Text
            frmSchema.UseBrackets = False
            frmSchema.DbProvider = DbProviders.MYSQL
            frmSchema.DbObjectType = Me.MySQLDBObjectType.SelectedIndex
            frmSchema.DbConnection = DbConnection
            frmSchema.DbObjectNameTextBox = Me.txt_MySQLObjectName
            frmSchema.DbObjectCommandTextBox = Me.txt_MySQLCommandText
            frmSchema.LoadSchema()
            frmSchema.Show()
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub

    Private Sub btn_DB2ISeries_Build_Click(sender As Object, e As EventArgs) Handles btn_DB2ISeries_Build.Click
        DB2ISERIESBuildClass()
    End Sub

    Private Sub TabDBProvider_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabDBProvider.SelectedIndexChanged



        Select Case Me.TabDBProvider.SelectedTab.Name

            Case TabSQLServer.Name
                Me.CurrentDbProvider = DbProviders.SQLSERVER
            Case TabOLEDB.Name
                Me.CurrentDbProvider = DbProviders.OLEDB
            Case TabDB2ISERIES.Name
                Me.CurrentDbProvider = DbProviders.DB2ISERIES
            Case TabOLEDBDB2.Name
                Me.CurrentDbProvider = DbProviders.OLEDBDB2
            Case TabODBC.Name
                Me.CurrentDbProvider = DbProviders.ODBC
            Case TabORACLE.Name
                Me.CurrentDbProvider = DbProviders.ORACLE
            Case TabMySQL.Name
                Me.CurrentDbProvider = DbProviders.MYSQL
            Case Else
                Me.CurrentDbProvider = DbProviders.SQLSERVER
        End Select
    End Sub

    Private Sub bnt_DB2ISeries_ShowConnectionString_Click(sender As Object, e As EventArgs) Handles bnt_DB2ISeries_ShowConnectionString.Click
        ShowCOnnectionStringDialog()
    End Sub

    Private Sub btn_MySQLConnectionString_Click(sender As Object, e As EventArgs) Handles btn_MySQLConnectionString.Click
        ShowCOnnectionStringDialog()

    End Sub

    Private Sub btm_MySQLBuild_Click(sender As Object, e As EventArgs) Handles btm_MySQLBuild.Click
        MySQLBuildClass()
    End Sub
End Class




Public Class ColumnInfo
    Private privateName As String
    Public Property Name() As String
        Get
            Return privateName
        End Get
        Set(ByVal value As String)
            privateName = value
        End Set
    End Property
    Private privateDataType As String
    Public Property DataType() As String
        Get
            Return privateDataType
        End Get
        Set(ByVal value As String)
            privateDataType = value
        End Set
    End Property
    Private privateOrdinalPosition As Integer
    Public Property OrdinalPosition() As Integer
        Get
            Return privateOrdinalPosition
        End Get
        Set(ByVal value As Integer)
            privateOrdinalPosition = value
        End Set
    End Property
    Private privateIsNullable As Boolean
    Public Property IsNullable() As Boolean
        Get
            Return privateIsNullable
        End Get
        Set(ByVal value As Boolean)
            privateIsNullable = value
        End Set
    End Property
    Private privateMaxLength As String
    Public Property MaxLength() As String
        Get
            Return privateMaxLength
        End Get
        Set(ByVal value As String)
            privateMaxLength = value
        End Set
    End Property

    Protected ReadOnly Property MaxLengthFormatted() As String
        ' note that columns with a max length return �1.
        Get
            Return If(MaxLength.Equals("-1"), "max", MaxLength)
        End Get
    End Property

    Public Property Nullable As Boolean

    Public Function ReadFromReader(ByVal reader As IDataReader) As ColumnInfo
        ' get the necessary information from the datareader.
        ' run the SQL on your database to see all the other information available.
        Me.Name = reader("COLUMN_NAME").ToString()
        Me.DataType = reader("DATA_TYPE").ToString()
        Me.OrdinalPosition = CInt(Fix(reader("ORDINAL_POSITION")))
        Me.Nullable = (CStr(reader("IS_NULLABLE"))) = "YES"
        Me.MaxLength = reader("CHARACTER_MAXIMUM_LENGTH").ToString()
        Return Me
    End Function

    Public Overrides Function ToString() As String
        Return String.Format("[{0}] {1}{2} {3}NULL", Name, DataType, If(MaxLength = String.Empty, "", "(" & MaxLengthFormatted & ")"), If(IsNullable, "", "NOT "))
    End Function

End Class

Public Enum DbProviders
    SQLSERVER
    ORACLE
    OLEDB
    OLEDBDB2
    ODBC
    ODBCDB2
    DB2ISERIES
    MYSQL
End Enum

Public Enum DbObjectTypes
    Table = 0
    View = 1
    SQLCommand = 2
    StoredProcedure = 3
    TableFunction = 4
    ScalarFunction = 5
End Enum