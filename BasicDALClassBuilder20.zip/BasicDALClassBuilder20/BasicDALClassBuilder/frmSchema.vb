﻿Imports System.Data.SqlClient
Imports System.Reflection

Public Class frmSchema
    Public DB2iSeriesLibraryList As String = ""
    Public ParameterPrefix As String = "@"
    Public ParameterStyle As Integer = 0
    Public SchemaSeparator As String = "."
    Public UseBrackets As Boolean = False
    Public DbProvider As DbProviders
    Public DbObjectType As Integer
    Public DbConnection As System.Data.Common.DbConnection
    Public DbObjectCommandTextBox As TextBox
    Public DbObjectNameTextBox As TextBox

    Public Sub LoadSchema()

        Select Case DbObjectType
            Case 0
                LoadTableSchema()
            Case 1
                LoadViewSchema()
            Case 3
                LoadStoredProceduresSchema()
            Case 4
                LoadTableFunctionsSchema()
            Case 5
                LoadScalarFunctionsSchema()
        End Select

    End Sub
    Public Sub LoadTableFunctionsSchema()

        Dim DT As DataTable = Nothing
        Dim _par As String = ""
        Dim MetadataCollectionName As String = ""
        If DbConnection.State = ConnectionState.Closed Then
            DbConnection.Open()
        End If
        Dim FunctionParameters As New Dictionary(Of String, String)
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim UseBrackets As Boolean = False
        Dim SchemaNameColumn As String = ""
        Dim ObjectNameColumn As String = ""
        Dim ProcedureParamenterName As String = "PARAMETER_NAME"
        UseBrackets = Utilities.GetDbProviderBrackets(Me.DbProvider, LeftBracket, RightBracket)


        Me.txtObjectType.Text = "Table Functions"
        MetadataCollectionName = "Procedures"

        Select Case DbProvider
            Case DbProviders.SQLSERVER
                SchemaNameColumn = "SPECIFIC_SCHEMA"
                ObjectNameColumn = "SPECIFIC_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, Nothing, Nothing, "FUNCTION"})
            Case DbProviders.ORACLE
                DT = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, Nothing, Nothing, "FUNCTION"})
            Case DbProviders.MYSQL
                SchemaNameColumn = "ROUTINE_SCHEMA"
                ObjectNameColumn = "ROUTINE_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, Nothing, Nothing, "FUNCTION"})
            Case DbProviders.DB2ISERIES
                Dim LibraryList As String = Utilities.GetDB2LibraryListAsString(Me.DB2iSeriesLibraryList)
                Dim DB2SQL As String = "SELECT * FROM QSYS2.SYSFUNCS WHERE FUNCTION_TYPE ='T' AND SPECIFIC_SCHEMA IN(" + LibraryList + ")"
                Dim DB2Command As IBM.Data.DB2.iSeries.iDB2Command = New IBM.Data.DB2.iSeries.iDB2Command()
                DB2Command.CommandType = CommandType.Text
                DB2Command.CommandText = DB2SQL
                DB2Command.Connection = DbConnection

                Dim DA As IBM.Data.DB2.iSeries.iDB2DataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter(DB2Command)
                DT = New DataTable
                DT.TableName = "QSYS2.SYSFUNCS"
                DA.Fill(DT)
            Case DbProviders.OLEDBDB2
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.OLEDB
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.ODBC
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.ODBCDB2
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})

            Case Else
                DT = DbConnection.GetSchema(MetadataCollectionName)
        End Select

        Dim _DT As DataTable = DT.Clone
        MetadataCollectionName = "ProcedureParameters"

        For Each row As DataRow In DT.Rows
            Dim DTF As DataTable = Nothing
            _par = ""
            Select Case DbProvider
                Case DbProviders.SQLSERVER
                    ProcedureParamenterName = "PARAMETER_NAME"
                    DTF = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, row(SchemaNameColumn), row(ObjectNameColumn), Nothing})
                Case DbProviders.ORACLE
                    DTF = DbConnection.GetSchema(MetadataCollectionName)
                Case DbProviders.MYSQL
                    DTF = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, row(SchemaNameColumn), row(SchemaNameColumn)})
                Case DbProviders.DB2ISERIES
                    MetadataCollectionName = IBM.Data.DB2.iSeries.iDB2MetaDataCollectionNames.ProcedureParameters
                    DTF = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, row(1), row(2)})
                Case DbProviders.OLEDBDB2
                    DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
                Case DbProviders.OLEDB
                    DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
                Case DbProviders.ODBC
                    DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
                Case DbProviders.ODBCDB2
                    DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})

                Case Else
                    DTF = DbConnection.GetSchema(MetadataCollectionName)

            End Select
            If DTF.Rows.Count = 0 Then
                _DT.ImportRow(row)
            Else
                Dim isTable As Boolean = True

                For Each _Row As DataRow In DTF.Rows
                    _par = _par & "," & _Row(ProcedureParamenterName)
                    If _Row(5) = "YES" Then
                        isTable = False
                    End If

                Next
                If _par.EndsWith(",") Then
                    _par = Mid(_par, 1, _par.Length - 1)
                End If
                If isTable = True Then
                    _DT.ImportRow(row)
                End If
            End If
            If _par.EndsWith(",") Then
                _par = Mid(_par, 1, _par.Length - 1)
            End If
            Dim k As String = row(SchemaNameColumn) & Me.SchemaSeparator & row(ObjectNameColumn)
            FunctionParameters.Add(k, _par)
        Next
        DT = _DT



        If DT Is Nothing Then Return
        Me.DbObjectCommandTextBox = DbObjectCommandTextBox
        Me.DbObjectNameTextBox = DbObjectNameTextBox

        Me.lstObjects.Items.Clear()

        For Each Row As DataRow In DT.Rows

            Dim SchemaName As String = Row(SchemaNameColumn)
            Dim ObjectName As String = Row(ObjectNameColumn)
            Dim k As String = SchemaName & Me.SchemaSeparator & ObjectName
            Dim Params As String = ""
            If FunctionParameters.ContainsKey(k) Then
                Params = FunctionParameters(k)
                If Params.StartsWith(",") Then
                    Params = Mid(Params, 2, Params.Length)
                End If
                Params = "(" & Params & ")"
            End If



            If SchemaName.Contains(" ") = True Then
                SchemaName = LeftBracket & SchemaName & RightBracket
            End If

            If ObjectName.Contains(" ") = True Then
                ObjectName = LeftBracket & ObjectName & RightBracket
            End If


            Me.lstObjects.Items.Add(SchemaName & Me.SchemaSeparator & ObjectName & Params)


        Next

    End Sub
    Public Sub LoadScalarFunctionsSchema()

        Dim DT As DataTable = Nothing
        Dim _par As String = ""
        Dim MetadataCollectionName As String = ""
        If DbConnection.State = ConnectionState.Closed Then
            DbConnection.Open()
        End If
        Dim FunctionParameters As New Dictionary(Of String, String)
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim UseBrackets As Boolean = False
        Dim SchemaNameColumn As String = ""
        Dim ObjectNameColumn As String = ""
        Dim ProcedureParamenterName As String = "PARAMETER_NAME"
        UseBrackets = Utilities.GetDbProviderBrackets(Me.DbProvider, LeftBracket, RightBracket)

        Me.txtObjectType.Text = "Scalar Functions"
        MetadataCollectionName = "Procedures"
        Dim isScalar As Boolean = True

        Select Case DbProvider
            Case DbProviders.SQLSERVER
                SchemaNameColumn = "SPECIFIC_SCHEMA"
                ObjectNameColumn = "SPECIFIC_NAME"
                ProcedureParamenterName = "PARAMETER_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, Nothing, Nothing, "FUNCTION"})

            Case DbProviders.ORACLE
                SchemaNameColumn = "SPECIFIC_SCHEMA"
                ObjectNameColumn = "SPECIFIC_NAME"
                ProcedureParamenterName = "PARAMETER_NAME"

                DT = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, Nothing, Nothing, "FUNCTION"})
            Case DbProviders.MYSQL
                SchemaNameColumn = "ROUTINE_SCHEMA"
                ObjectNameColumn = "ROUTINE_NAME"
                ProcedureParamenterName = "PARAMETER_NAME"

                DT = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, Nothing, Nothing, "FUNCTION"})

            Case DbProviders.DB2ISERIES
                SchemaNameColumn = "SPECIFIC_SCHEMA"
                ObjectNameColumn = "SPECIFIC_NAME"
                Dim LibraryList As String = Utilities.GetDB2LibraryListAsString(Me.DB2iSeriesLibraryList)
                Dim DB2SQL As String = "Select * FROM QSYS2.SYSFUNCS WHERE FUNCTION_TYPE ='S' AND SPECIFIC_SCHEMA IN(" + LibraryList + ")"
                Dim DB2Command As IBM.Data.DB2.iSeries.iDB2Command = New IBM.Data.DB2.iSeries.iDB2Command()
                DB2Command.CommandType = CommandType.Text
                DB2Command.CommandText = DB2SQL
                DB2Command.Connection = DbConnection
                Dim DA As IBM.Data.DB2.iSeries.iDB2DataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter(DB2Command)
                DT = New DataTable
                DT.TableName = "QSYS2.SYSFUNCS"
                DA.Fill(DT)

            Case DbProviders.OLEDBDB2
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.OLEDB
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.ODBC
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.ODBCDB2
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case Else
                DT = DbConnection.GetSchema(MetadataCollectionName)
        End Select

        DataGridView1.DataSource = DT

                Dim _DT As DataTable = DT.Clone
                MetadataCollectionName = "ProcedureParameters"
                For Each row As DataRow In DT.Rows
                    _par = ""
                    Dim DTF As DataTable = Nothing

                    Select Case DbProvider
                        Case DbProviders.SQLSERVER
                            DTF = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, row(SchemaNameColumn), row(ObjectNameColumn), Nothing})
                        Case DbProviders.MYSQL
                            MetadataCollectionName = "Procedure Parameters"
                            DTF = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, row(SchemaNameColumn), row(ObjectNameColumn)})

                        Case DbProviders.ORACLE
                            DTF = DbConnection.GetSchema(MetadataCollectionName)
                        Case DbProviders.DB2ISERIES
                            'DTF = DbConnection.GetSchema("ProcedureParameters", New String() {Nothing, row(1), row(2)})

                            'Dim LibraryList As String = Utilities.GetDB2LibraryListAsString(Me.DB2iSeriesLibraryList)
                            Dim DB2SQL As String = "SELECT * FROM QSYS2.SYSPARMS WHERE SPECIFIC_SCHEMA='" + row("SPECIFIC_SCHEMA") + "' AND SPECIFIC_NAME='" + row("SPECIFIC_NAME") + "' ORDER BY ORDINAL_POSITION"
                            Dim DB2Command As IBM.Data.DB2.iSeries.iDB2Command = New IBM.Data.DB2.iSeries.iDB2Command()
                            DB2Command.CommandType = CommandType.Text
                            DB2Command.CommandText = DB2SQL
                            DB2Command.Connection = DbConnection
                            Dim DA As IBM.Data.DB2.iSeries.iDB2DataAdapter = New IBM.Data.DB2.iSeries.iDB2DataAdapter(DB2Command)
                            DTF = New DataTable
                            DTF.TableName = "QSYS2.SYSPARMS"
                            DA.Fill(DTF)
                        Case DbProviders.OLEDBDB2
                            DTF = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
                        Case DbProviders.OLEDB
                            DTF = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
                        Case DbProviders.ODBC
                            DTF = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
                        Case DbProviders.ODBCDB2
                            DTF = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
                        Case Else
                            DTF = DbConnection.GetSchema(MetadataCollectionName)
                    End Select



                    ' MODIFICA PER DBPROVIDER
                    For Each _Row As DataRow In DTF.Rows

                        Dim addParamenter As Boolean = True
                        Dim _ParameterPrefix As String = ""
                        Select Case DbProvider
                            Case DbProviders.DB2ISERIES
                                If _Row("PARAMETER_NAME") Is DBNull.Value And _Row("PARAMETER_MODE") = "OUT" Then
                                    _Row("PARAMETER_NAME") = "RETURN_VALUE"
                                    _DT.ImportRow(row)
                                    addParamenter = False
                                End If
                                _ParameterPrefix = ParameterPrefix
                            Case DbProviders.MYSQL
                                If _Row("PARAMETER_NAME") = "RETURN_VALUE" Then
                                    _DT.ImportRow(row)
                                    addParamenter = False
                                End If
                                _ParameterPrefix = ParameterPrefix
                            Case DbProviders.ODBC
                            Case DbProviders.ODBCDB2
                            Case DbProviders.OLEDB
                            Case DbProviders.OLEDBDB2
                            Case DbProviders.ORACLE
                            Case DbProviders.SQLSERVER
                                If _Row("IS_RESULT") = "YES" Then
                                    _DT.ImportRow(row)
                                    addParamenter = False
                                End If
                            Case Else

                        End Select

                        If (addParamenter) Then
                            _par = _par & "," & _ParameterPrefix & _Row(ProcedureParamenterName)
                            If _par.EndsWith(",") Then
                                _par = Mid(_par, 1, _par.Length - 1)
                            End If
                        End If

                    Next

                    'Select Case DbProvider
                    '    Case DbProviders.DB2ISERIES
                    '    Case DbProviders.MYSQL
                    '        _DT.ImportRow(row)
                    '    Case DbProviders.ODBC
                    '    Case DbProviders.ODBCDB2
                    '    Case DbProviders.OLEDB
                    '    Case DbProviders.OLEDBDB2
                    '    Case DbProviders.ORACLE
                    '    Case DbProviders.SQLSERVER
                    '    Case Else

                    'End Select


                    Dim k As String = row(SchemaNameColumn) & Me.SchemaSeparator & row(ObjectNameColumn)
                    FunctionParameters.Add(k, _par)
                Next
                DT = _DT


        If DT Is Nothing Then Return
        Me.DbObjectCommandTextBox = DbObjectCommandTextBox
        Me.DbObjectNameTextBox = DbObjectNameTextBox

        Me.lstObjects.Items.Clear()

        For Each Row As DataRow In DT.Rows

            Dim SchemaName As String = Row(SchemaNameColumn)
            Dim ObjectName As String = Row(ObjectNameColumn)
            Dim k As String = SchemaName & Me.SchemaSeparator & ObjectName
            Dim Params As String = ""
            If FunctionParameters.ContainsKey(k) Then
                Params = FunctionParameters(k)
                If Params.StartsWith(",") Then
                    Params = Mid(Params, 2, Params.Length)
                End If
                Params = "(" & Params & ")"
            End If



            If SchemaName.Contains(" ") = True Then
                SchemaName = LeftBracket & SchemaName & RightBracket
            End If

            If ObjectName.Contains(" ") = True Then
                ObjectName = LeftBracket & ObjectName & RightBracket
            End If


            Me.lstObjects.Items.Add(SchemaName & Me.SchemaSeparator & ObjectName & Params)


        Next

    End Sub

    Public Sub LoadStoredProceduresSchema()

        Dim DT As DataTable = Nothing
        Dim _par As String = ""
        Dim MetadataCollectionName As String = ""
        If DbConnection.State = ConnectionState.Closed Then
            DbConnection.Open()
        End If
        Dim FunctionParameters As New Dictionary(Of String, String)
        Dim nTableSchemaNameColumn As String = "TABLE_SCHEMA"
        Dim nTableNameColumn As String = "TABLE_NAME"
        Dim nViewSchemaNameColumn As String = "TABLE_SCHEMA"
        Dim nViewNameColumn As String = "TABLE_NAME"
        Dim nStoredProcedureSchemaNameColumn As String = "SPECIFIC_SCHEMA"
        Dim nStoredProcedureNameColumn As String = "SPECIFIC_NAME"
        Dim nFunctionSchemaNameColumn As String = "SPECIFIC_SCHEMA"
        Dim nFunctionNameColumn As String = "SPECIFIC_NAME"
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim UseBrackets As Boolean = False
        Dim SchemaNameColumn As String = ""
        Dim ObjectNameColumn As String = ""
        Dim ProcedureParamenterName As String = "PARAMETER_NAME"
        UseBrackets = Utilities.GetDbProviderBrackets(Me.DbProvider, LeftBracket, RightBracket)

        Me.txtObjectType.Text = "Stored Procedures"
        MetadataCollectionName = "Procedures"

        Select Case DbProvider
            Case DbProviders.SQLSERVER
                SchemaNameColumn = "SPECIFIC_SCHEMA"
                ObjectNameColumn = "SPECIFIC_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, Nothing, Nothing, "PROCEDURE"})
            Case DbProviders.ORACLE
                SchemaNameColumn = "SPECIFIC_SCHEMA"
                ObjectNameColumn = "SPECIFIC_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {"BASE TABLE"})
            Case DbProviders.MYSQL
                SchemaNameColumn = "ROUTINE_SCHEMA"
                ObjectNameColumn = "ROUTINE_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, Nothing, Nothing, "PROCEDURE"})
            Case DbProviders.DB2ISERIES
                SchemaNameColumn = "SPECIFICSCHEMA"
                ObjectNameColumn = "SPECIFICNAME"
                MetadataCollectionName = IBM.Data.DB2.iSeries.iDB2MetaDataCollectionNames.Procedures
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {"BASE TABLE"})
            Case DbProviders.OLEDBDB2
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.OLEDB
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.ODBC
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.ODBCDB2
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case Else
                DT = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, Nothing, Nothing, "PROCEDURE"})
        End Select


        If DT Is Nothing Then Return
        Me.DbObjectCommandTextBox = DbObjectCommandTextBox
        Me.DbObjectNameTextBox = DbObjectNameTextBox

        Me.lstObjects.Items.Clear()

        For Each Row As DataRow In DT.Rows

            Dim SchemaName As String = Row(SchemaNameColumn)
            Dim ObjectName As String = Row(ObjectNameColumn)
            Dim k As String = SchemaName & Me.SchemaSeparator & ObjectName
            Dim Params As String = ""
            If FunctionParameters.ContainsKey(k) Then
                Params = FunctionParameters(k)
                If Params.StartsWith(",") Then
                    Params = Mid(Params, 2, Params.Length)
                End If
                Params = "(" & Params & ")"
            End If



            If SchemaName.Contains(" ") = True Then
                SchemaName = LeftBracket & SchemaName & RightBracket
            End If

            If ObjectName.Contains(" ") = True Then
                ObjectName = LeftBracket & ObjectName & RightBracket
            End If


            Me.lstObjects.Items.Add(SchemaName & Me.SchemaSeparator & ObjectName & Params)


        Next

    End Sub


    Public Sub LoadViewSchema()

        Dim DT As DataTable = Nothing
        Dim _par As String = ""
        Dim MetadataCollectionName As String = ""
        If DbConnection.State = ConnectionState.Closed Then
            DbConnection.Open()
        End If
        Dim FunctionParameters As New Dictionary(Of String, String)
        Dim nTableSchemaNameColumn As String = "TABLE_SCHEMA"
        Dim nTableNameColumn As String = "TABLE_NAME"
        Dim nViewSchemaNameColumn As String = "TABLE_SCHEMA"
        Dim nViewNameColumn As String = "TABLE_NAME"
        Dim nStoredProcedureSchemaNameColumn As String = "SPECIFIC_SCHEMA"
        Dim nStoredProcedureNameColumn As String = "SPECIFIC_NAME"
        Dim nFunctionSchemaNameColumn As String = "SPECIFIC_SCHEMA"
        Dim nFunctionNameColumn As String = "SPECIFIC_NAME"
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim UseBrackets As Boolean = False
        Dim SchemaNameColumn As String = ""
        Dim ObjectNameColumn As String = ""
        Dim ProcedureParamenterName As String = "PARAMETER_NAME"
        UseBrackets = Utilities.GetDbProviderBrackets(Me.DbProvider, LeftBracket, RightBracket)

        MetadataCollectionName = "Views"
        Me.txtObjectType.Text = "Views"
                ' DT = DbConnection.GetSchema(MetadataCollectionName)
                Select Case DbProvider
                    Case DbProviders.SQLSERVER
                        SchemaNameColumn = "TABLE_SCHEMA"
                        ObjectNameColumn = "TABLE_NAME"
                        DT = DbConnection.GetSchema(MetadataCollectionName)', New String() {Nothing, Nothing, "VIEWS"})
                    Case DbProviders.MYSQL
                        SchemaNameColumn = "TABLE_SCHEMA"
                        ObjectNameColumn = "TABLE_NAME"
                        DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {"BASE TABLE"})
                    Case DbProviders.ORACLE
                        DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {"BASE TABLE"})
                    Case DbProviders.DB2ISERIES
                        SchemaNameColumn = "VIEWSCHEMA"
                        ObjectNameColumn = "VIEWNAME"
                        MetadataCollectionName = IBM.Data.DB2.iSeries.iDB2MetaDataCollectionNames.Views
                        DT = DbConnection.GetSchema(MetadataCollectionName)', New String() {Nothing, Nothing, "VIEWS"})
                    Case DbProviders.OLEDBDB2
                        DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
                    Case DbProviders.OLEDB
                        DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
                    Case DbProviders.ODBC
                        DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
                    Case DbProviders.ODBCDB2
                        DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})

                    Case Else
                        DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
                End Select


        If DT Is Nothing Then Return
        Me.DbObjectCommandTextBox = DbObjectCommandTextBox
        Me.DbObjectNameTextBox = DbObjectNameTextBox

        Me.lstObjects.Items.Clear()

        For Each Row As DataRow In DT.Rows

            Dim SchemaName As String = Row(SchemaNameColumn)
            Dim ObjectName As String = Row(ObjectNameColumn)
            Dim k As String = SchemaName & Me.SchemaSeparator & ObjectName
            Dim Params As String = ""
            If FunctionParameters.ContainsKey(k) Then
                Params = FunctionParameters(k)
                If Params.StartsWith(",") Then
                    Params = Mid(Params, 2, Params.Length)
                End If
                Params = "(" & Params & ")"
            End If



            If SchemaName.Contains(" ") = True Then
                SchemaName = LeftBracket & SchemaName & RightBracket
            End If

            If ObjectName.Contains(" ") = True Then
                ObjectName = LeftBracket & ObjectName & RightBracket
            End If


            Me.lstObjects.Items.Add(SchemaName & Me.SchemaSeparator & ObjectName & Params)


        Next

    End Sub
    Public Sub LoadTableSchema()

        Dim DT As DataTable = Nothing
        Dim _par As String = ""
        Dim MetadataCollectionName As String = ""
        Dim FunctionParameters As New Dictionary(Of String, String)
        Dim LeftBracket As String = ""
        Dim RightBracket As String = ""
        Dim UseBrackets As Boolean = False
        Dim SchemaNameColumn As String = ""
        Dim ObjectNameColumn As String = ""
        Dim ProcedureParamenterName As String = "PARAMETER_NAME"

        If DbConnection.State = ConnectionState.Closed Then
            DbConnection.Open()
        End If

        UseBrackets = Utilities.GetDbProviderBrackets(Me.DbProvider, LeftBracket, RightBracket)

        MetadataCollectionName = "Tables"
        Me.txtObjectType.Text = "Tables"

        Select Case DbProvider
            Case DbProviders.SQLSERVER
                SchemaNameColumn = "TABLE_SCHEMA"
                ObjectNameColumn = "TABLE_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.ORACLE
                SchemaNameColumn = "OWNER"
                ObjectNameColumn = "TABLE_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName, New String() {Nothing, Nothing})
            Case DbProviders.MYSQL
                SchemaNameColumn = "TABLE_SCHEMA"
                ObjectNameColumn = "TABLE_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {"BASE TABLE"})
            Case DbProviders.DB2ISERIES
                SchemaNameColumn = "SCHEMANAME"
                ObjectNameColumn = "TABLENAME"
                MetadataCollectionName = IBM.Data.DB2.iSeries.iDB2MetaDataCollectionNames.Tables
                DT = DbConnection.GetSchema(MetadataCollectionName)', New String() {Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.OLEDBDB2
                SchemaNameColumn = "TABLE_SCHEMA"
                ObjectNameColumn = "TABLE_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.OLEDB
                SchemaNameColumn = "TABLE_SCHEMA"
                ObjectNameColumn = "TABLE_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.ODBCDB2
                SchemaNameColumn = "TABLE_SCHEMA"
                ObjectNameColumn = "TABLE_NAME"
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
            Case DbProviders.ODBC
                SchemaNameColumn = "TABLE_SCHEMA"
                ObjectNameColumn = "TABLE_NAME"
            Case Else
                DT = DbConnection.GetSchema(MetadataCollectionName) ', New String() {Nothing, Nothing, Nothing, "BASE TABLE"})
        End Select



        If DT Is Nothing Then Return
        Me.DbObjectCommandTextBox = DbObjectCommandTextBox
        Me.DbObjectNameTextBox = DbObjectNameTextBox

        Me.lstObjects.Items.Clear()

        For Each Row As DataRow In DT.Rows

            Dim SchemaName As String = Row(SchemaNameColumn)
            Dim ObjectName As String = Row(ObjectNameColumn)
            Dim k As String = SchemaName & Me.SchemaSeparator & ObjectName
            Dim Params As String = ""
            If FunctionParameters.ContainsKey(k) Then
                Params = FunctionParameters(k)
                If Params.StartsWith(",") Then
                    Params = Mid(Params, 2, Params.Length)
                End If
                Params = "(" & Params & ")"
            End If

            If SchemaName.Contains(" ") = True Then
                SchemaName = LeftBracket & SchemaName & RightBracket
            End If

            If ObjectName.Contains(" ") = True Then
                ObjectName = LeftBracket & ObjectName & RightBracket
            End If
            Me.lstObjects.Items.Add(SchemaName & Me.SchemaSeparator & ObjectName & Params)

        Next

    End Sub



    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub SelectDbObject()


        Dim s As String = ""
        Dim _s() As String = Me.lstObjects.Items(Me.lstObjects.SelectedIndex).ToString.Split("(")

        s = _s(0)
        s = s.Replace(".", "_")
        s = s.Replace("/", "_")
        s = s.Replace(" ", "_")
        s = s.Replace("[", "")
        s = s.Replace("]", "")

        Me.DbObjectCommandTextBox.Text = Me.lstObjects.Items(Me.lstObjects.SelectedIndex)
        Me.DbObjectNameTextBox.Text = s

    End Sub

    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click
        SelectDbObject()
        Me.Close()
    End Sub

    Private Sub lstObjects_DoubleClick(sender As Object, e As EventArgs) Handles lstObjects.DoubleClick
        SelectDbObject()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.DataGridView1.DataSource = Me.DbConnection.GetSchema()
    End Sub
End Class